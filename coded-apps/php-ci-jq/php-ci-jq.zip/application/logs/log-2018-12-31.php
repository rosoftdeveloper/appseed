INFO - 2018-12-31 10:04:31 --> Config Class Initialized
INFO - 2018-12-31 10:04:31 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:04:31 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:04:31 --> Utf8 Class Initialized
INFO - 2018-12-31 10:04:31 --> URI Class Initialized
DEBUG - 2018-12-31 10:04:31 --> No URI present. Default controller set.
INFO - 2018-12-31 10:04:31 --> Router Class Initialized
INFO - 2018-12-31 10:04:31 --> Output Class Initialized
INFO - 2018-12-31 10:04:31 --> Security Class Initialized
DEBUG - 2018-12-31 10:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:04:31 --> CSRF cookie sent
INFO - 2018-12-31 10:04:31 --> Input Class Initialized
INFO - 2018-12-31 10:04:31 --> Language Class Initialized
ERROR - 2018-12-31 10:04:31 --> 404 Page Not Found: Cindex/index
INFO - 2018-12-31 10:05:05 --> Config Class Initialized
INFO - 2018-12-31 10:05:05 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:05:05 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:05:05 --> Utf8 Class Initialized
INFO - 2018-12-31 10:05:05 --> URI Class Initialized
DEBUG - 2018-12-31 10:05:05 --> No URI present. Default controller set.
INFO - 2018-12-31 10:05:05 --> Router Class Initialized
INFO - 2018-12-31 10:05:05 --> Output Class Initialized
INFO - 2018-12-31 10:05:05 --> Security Class Initialized
DEBUG - 2018-12-31 10:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:05:05 --> CSRF cookie sent
INFO - 2018-12-31 10:05:05 --> Input Class Initialized
INFO - 2018-12-31 10:05:05 --> Language Class Initialized
INFO - 2018-12-31 10:05:05 --> Loader Class Initialized
INFO - 2018-12-31 10:05:05 --> Controller Class Initialized
INFO - 2018-12-31 10:05:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\welcome_message.php
INFO - 2018-12-31 10:05:05 --> Final output sent to browser
DEBUG - 2018-12-31 10:05:05 --> Total execution time: 0.1400
INFO - 2018-12-31 10:05:18 --> Config Class Initialized
INFO - 2018-12-31 10:05:18 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:05:18 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:05:18 --> Utf8 Class Initialized
INFO - 2018-12-31 10:05:18 --> URI Class Initialized
INFO - 2018-12-31 10:05:18 --> Router Class Initialized
INFO - 2018-12-31 10:05:18 --> Output Class Initialized
INFO - 2018-12-31 10:05:18 --> Security Class Initialized
DEBUG - 2018-12-31 10:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:05:18 --> CSRF cookie sent
INFO - 2018-12-31 10:05:18 --> Input Class Initialized
INFO - 2018-12-31 10:05:18 --> Language Class Initialized
ERROR - 2018-12-31 10:05:18 --> 404 Page Not Found: Admin/index
INFO - 2018-12-31 10:05:22 --> Config Class Initialized
INFO - 2018-12-31 10:05:22 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:05:22 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:05:22 --> Utf8 Class Initialized
INFO - 2018-12-31 10:05:22 --> URI Class Initialized
INFO - 2018-12-31 10:05:22 --> Router Class Initialized
INFO - 2018-12-31 10:05:22 --> Output Class Initialized
INFO - 2018-12-31 10:05:22 --> Security Class Initialized
DEBUG - 2018-12-31 10:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:05:22 --> CSRF cookie sent
INFO - 2018-12-31 10:05:22 --> Input Class Initialized
INFO - 2018-12-31 10:05:22 --> Language Class Initialized
ERROR - 2018-12-31 10:05:22 --> 404 Page Not Found: Login/index
INFO - 2018-12-31 10:05:28 --> Config Class Initialized
INFO - 2018-12-31 10:05:28 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:05:28 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:05:28 --> Utf8 Class Initialized
INFO - 2018-12-31 10:05:28 --> URI Class Initialized
INFO - 2018-12-31 10:05:28 --> Router Class Initialized
INFO - 2018-12-31 10:05:28 --> Output Class Initialized
INFO - 2018-12-31 10:05:28 --> Security Class Initialized
DEBUG - 2018-12-31 10:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:05:28 --> CSRF cookie sent
INFO - 2018-12-31 10:05:28 --> Input Class Initialized
INFO - 2018-12-31 10:05:28 --> Language Class Initialized
INFO - 2018-12-31 10:05:28 --> Loader Class Initialized
INFO - 2018-12-31 10:05:28 --> Controller Class Initialized
INFO - 2018-12-31 10:05:28 --> Database Driver Class Initialized
DEBUG - 2018-12-31 10:05:28 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 10:05:28 --> Email Class Initialized
INFO - 2018-12-31 10:05:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 10:05:29 --> Helper loaded: cookie_helper
INFO - 2018-12-31 10:05:29 --> Helper loaded: language_helper
INFO - 2018-12-31 10:05:29 --> Helper loaded: url_helper
DEBUG - 2018-12-31 10:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 10:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 10:05:29 --> Helper loaded: date_helper
INFO - 2018-12-31 10:05:29 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 10:05:29 --> Helper loaded: form_helper
INFO - 2018-12-31 10:05:29 --> Form Validation Class Initialized
INFO - 2018-12-31 10:05:29 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 10:05:29 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 10:05:29 --> Final output sent to browser
DEBUG - 2018-12-31 10:05:29 --> Total execution time: 0.4162
INFO - 2018-12-31 10:13:49 --> Config Class Initialized
INFO - 2018-12-31 10:13:49 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:13:49 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:13:49 --> Utf8 Class Initialized
INFO - 2018-12-31 10:13:49 --> URI Class Initialized
DEBUG - 2018-12-31 10:13:49 --> No URI present. Default controller set.
INFO - 2018-12-31 10:13:49 --> Router Class Initialized
INFO - 2018-12-31 10:13:49 --> Output Class Initialized
INFO - 2018-12-31 10:13:49 --> Security Class Initialized
DEBUG - 2018-12-31 10:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:13:49 --> CSRF cookie sent
INFO - 2018-12-31 10:13:49 --> Input Class Initialized
INFO - 2018-12-31 10:13:49 --> Language Class Initialized
INFO - 2018-12-31 10:13:49 --> Loader Class Initialized
INFO - 2018-12-31 10:13:49 --> Controller Class Initialized
INFO - 2018-12-31 10:13:49 --> Database Driver Class Initialized
INFO - 2018-12-31 10:13:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.html
INFO - 2018-12-31 10:13:49 --> Final output sent to browser
DEBUG - 2018-12-31 10:13:50 --> Total execution time: 0.2347
INFO - 2018-12-31 10:15:21 --> Config Class Initialized
INFO - 2018-12-31 10:15:21 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:15:21 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:15:21 --> Utf8 Class Initialized
INFO - 2018-12-31 10:15:21 --> URI Class Initialized
DEBUG - 2018-12-31 10:15:21 --> No URI present. Default controller set.
INFO - 2018-12-31 10:15:21 --> Router Class Initialized
INFO - 2018-12-31 10:15:21 --> Output Class Initialized
INFO - 2018-12-31 10:15:21 --> Security Class Initialized
DEBUG - 2018-12-31 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:15:21 --> CSRF cookie sent
INFO - 2018-12-31 10:15:21 --> Input Class Initialized
INFO - 2018-12-31 10:15:21 --> Language Class Initialized
INFO - 2018-12-31 10:15:21 --> Loader Class Initialized
INFO - 2018-12-31 10:15:21 --> Controller Class Initialized
INFO - 2018-12-31 10:15:21 --> Database Driver Class Initialized
ERROR - 2018-12-31 10:15:21 --> Severity: Notice --> Undefined variable: theme C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes\argon-design-system\index.php 11
INFO - 2018-12-31 10:15:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 10:15:21 --> Final output sent to browser
DEBUG - 2018-12-31 10:15:21 --> Total execution time: 0.1941
INFO - 2018-12-31 10:16:31 --> Config Class Initialized
INFO - 2018-12-31 10:16:31 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:16:31 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:16:31 --> Utf8 Class Initialized
INFO - 2018-12-31 10:16:31 --> URI Class Initialized
DEBUG - 2018-12-31 10:16:31 --> No URI present. Default controller set.
INFO - 2018-12-31 10:16:31 --> Router Class Initialized
INFO - 2018-12-31 10:16:31 --> Output Class Initialized
INFO - 2018-12-31 10:16:31 --> Security Class Initialized
DEBUG - 2018-12-31 10:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:16:31 --> CSRF cookie sent
INFO - 2018-12-31 10:16:31 --> Input Class Initialized
INFO - 2018-12-31 10:16:31 --> Language Class Initialized
ERROR - 2018-12-31 10:16:31 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ',' or ';' C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\controllers\Cindex.php 7
INFO - 2018-12-31 10:17:00 --> Config Class Initialized
INFO - 2018-12-31 10:17:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:17:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:17:00 --> Utf8 Class Initialized
INFO - 2018-12-31 10:17:00 --> URI Class Initialized
DEBUG - 2018-12-31 10:17:00 --> No URI present. Default controller set.
INFO - 2018-12-31 10:17:00 --> Router Class Initialized
INFO - 2018-12-31 10:17:00 --> Output Class Initialized
INFO - 2018-12-31 10:17:00 --> Security Class Initialized
DEBUG - 2018-12-31 10:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:17:00 --> CSRF cookie sent
INFO - 2018-12-31 10:17:00 --> Input Class Initialized
INFO - 2018-12-31 10:17:00 --> Language Class Initialized
INFO - 2018-12-31 10:17:00 --> Loader Class Initialized
INFO - 2018-12-31 10:17:00 --> Controller Class Initialized
INFO - 2018-12-31 10:17:00 --> Database Driver Class Initialized
ERROR - 2018-12-31 10:17:00 --> Severity: Notice --> Undefined property: Cindex::$theme C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\controllers\Cindex.php 18
INFO - 2018-12-31 10:18:12 --> Config Class Initialized
INFO - 2018-12-31 10:18:12 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:18:12 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:18:12 --> Utf8 Class Initialized
INFO - 2018-12-31 10:18:12 --> URI Class Initialized
DEBUG - 2018-12-31 10:18:12 --> No URI present. Default controller set.
INFO - 2018-12-31 10:18:12 --> Router Class Initialized
INFO - 2018-12-31 10:18:12 --> Output Class Initialized
INFO - 2018-12-31 10:18:12 --> Security Class Initialized
DEBUG - 2018-12-31 10:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:18:12 --> CSRF cookie sent
INFO - 2018-12-31 10:18:12 --> Input Class Initialized
INFO - 2018-12-31 10:18:12 --> Language Class Initialized
INFO - 2018-12-31 10:18:12 --> Loader Class Initialized
INFO - 2018-12-31 10:18:12 --> Controller Class Initialized
INFO - 2018-12-31 10:18:12 --> Database Driver Class Initialized
ERROR - 2018-12-31 10:18:12 --> Severity: Notice --> Undefined variable: theme C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes\argon-design-system\index.php 11
INFO - 2018-12-31 10:18:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 10:18:12 --> Final output sent to browser
DEBUG - 2018-12-31 10:18:12 --> Total execution time: 0.2913
INFO - 2018-12-31 10:18:47 --> Config Class Initialized
INFO - 2018-12-31 10:18:47 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:18:47 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:18:47 --> Utf8 Class Initialized
INFO - 2018-12-31 10:18:47 --> URI Class Initialized
DEBUG - 2018-12-31 10:18:47 --> No URI present. Default controller set.
INFO - 2018-12-31 10:18:47 --> Router Class Initialized
INFO - 2018-12-31 10:18:47 --> Output Class Initialized
INFO - 2018-12-31 10:18:47 --> Security Class Initialized
DEBUG - 2018-12-31 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:18:47 --> CSRF cookie sent
INFO - 2018-12-31 10:18:47 --> Input Class Initialized
INFO - 2018-12-31 10:18:47 --> Language Class Initialized
INFO - 2018-12-31 10:18:47 --> Loader Class Initialized
INFO - 2018-12-31 10:18:47 --> Controller Class Initialized
INFO - 2018-12-31 10:18:47 --> Database Driver Class Initialized
INFO - 2018-12-31 10:18:47 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 10:18:47 --> Final output sent to browser
DEBUG - 2018-12-31 10:18:47 --> Total execution time: 0.3094
INFO - 2018-12-31 10:52:38 --> Config Class Initialized
INFO - 2018-12-31 10:52:38 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:52:38 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:52:38 --> Utf8 Class Initialized
INFO - 2018-12-31 10:52:38 --> URI Class Initialized
DEBUG - 2018-12-31 10:52:38 --> No URI present. Default controller set.
INFO - 2018-12-31 10:52:38 --> Router Class Initialized
INFO - 2018-12-31 10:52:38 --> Output Class Initialized
INFO - 2018-12-31 10:52:38 --> Security Class Initialized
DEBUG - 2018-12-31 10:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:52:38 --> CSRF cookie sent
INFO - 2018-12-31 10:52:38 --> Input Class Initialized
INFO - 2018-12-31 10:52:38 --> Language Class Initialized
INFO - 2018-12-31 10:52:38 --> Loader Class Initialized
INFO - 2018-12-31 10:52:38 --> Controller Class Initialized
INFO - 2018-12-31 10:52:38 --> Database Driver Class Initialized
ERROR - 2018-12-31 10:52:38 --> Severity: error --> Exception: Call to undefined function _cfg_theme() C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\controllers\Cindex.php 18
INFO - 2018-12-31 10:53:27 --> Config Class Initialized
INFO - 2018-12-31 10:53:27 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:53:27 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:53:27 --> Utf8 Class Initialized
INFO - 2018-12-31 10:53:27 --> URI Class Initialized
DEBUG - 2018-12-31 10:53:27 --> No URI present. Default controller set.
INFO - 2018-12-31 10:53:27 --> Router Class Initialized
INFO - 2018-12-31 10:53:27 --> Output Class Initialized
INFO - 2018-12-31 10:53:27 --> Security Class Initialized
DEBUG - 2018-12-31 10:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:53:27 --> CSRF cookie sent
INFO - 2018-12-31 10:53:27 --> Input Class Initialized
INFO - 2018-12-31 10:53:27 --> Language Class Initialized
INFO - 2018-12-31 10:53:27 --> Loader Class Initialized
INFO - 2018-12-31 10:53:27 --> Helper loaded: url_helper
INFO - 2018-12-31 10:53:27 --> Helper loaded: file_helper
INFO - 2018-12-31 10:53:27 --> Helper loaded: util_helper
INFO - 2018-12-31 10:53:27 --> Controller Class Initialized
INFO - 2018-12-31 10:53:27 --> Database Driver Class Initialized
ERROR - 2018-12-31 10:53:27 --> Severity: Notice --> Undefined property: Cindex::$theme C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\controllers\Cindex.php 20
INFO - 2018-12-31 10:54:06 --> Config Class Initialized
INFO - 2018-12-31 10:54:06 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:54:06 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:54:06 --> Utf8 Class Initialized
INFO - 2018-12-31 10:54:06 --> URI Class Initialized
DEBUG - 2018-12-31 10:54:06 --> No URI present. Default controller set.
INFO - 2018-12-31 10:54:06 --> Router Class Initialized
INFO - 2018-12-31 10:54:06 --> Output Class Initialized
INFO - 2018-12-31 10:54:06 --> Security Class Initialized
DEBUG - 2018-12-31 10:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:54:06 --> CSRF cookie sent
INFO - 2018-12-31 10:54:06 --> Input Class Initialized
INFO - 2018-12-31 10:54:06 --> Language Class Initialized
INFO - 2018-12-31 10:54:06 --> Loader Class Initialized
INFO - 2018-12-31 10:54:06 --> Helper loaded: url_helper
INFO - 2018-12-31 10:54:06 --> Helper loaded: file_helper
INFO - 2018-12-31 10:54:06 --> Helper loaded: util_helper
INFO - 2018-12-31 10:54:06 --> Controller Class Initialized
INFO - 2018-12-31 10:54:06 --> Database Driver Class Initialized
ERROR - 2018-12-31 10:54:06 --> Severity: Notice --> Use of undefined constant DS - assumed 'DS' C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\util_helper.php 85
ERROR - 2018-12-31 10:54:06 --> Severity: Notice --> Use of undefined constant DS - assumed 'DS' C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\util_helper.php 85
ERROR - 2018-12-31 10:54:06 --> Severity: Notice --> Use of undefined constant DS - assumed 'DS' C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\util_helper.php 85
ERROR - 2018-12-31 10:54:06 --> Severity: Notice --> Use of undefined constant DS - assumed 'DS' C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\util_helper.php 85
ERROR - 2018-12-31 10:54:06 --> Severity: Notice --> Use of undefined constant DS - assumed 'DS' C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\util_helper.php 85
INFO - 2018-12-31 10:54:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 10:54:06 --> Final output sent to browser
DEBUG - 2018-12-31 10:54:06 --> Total execution time: 0.2380
INFO - 2018-12-31 10:54:30 --> Config Class Initialized
INFO - 2018-12-31 10:54:30 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:54:30 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:54:30 --> Utf8 Class Initialized
INFO - 2018-12-31 10:54:30 --> URI Class Initialized
DEBUG - 2018-12-31 10:54:30 --> No URI present. Default controller set.
INFO - 2018-12-31 10:54:31 --> Router Class Initialized
INFO - 2018-12-31 10:54:31 --> Output Class Initialized
INFO - 2018-12-31 10:54:31 --> Security Class Initialized
DEBUG - 2018-12-31 10:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:54:31 --> CSRF cookie sent
INFO - 2018-12-31 10:54:31 --> Input Class Initialized
INFO - 2018-12-31 10:54:31 --> Language Class Initialized
INFO - 2018-12-31 10:54:31 --> Loader Class Initialized
INFO - 2018-12-31 10:54:31 --> Helper loaded: url_helper
INFO - 2018-12-31 10:54:31 --> Helper loaded: file_helper
INFO - 2018-12-31 10:54:31 --> Helper loaded: util_helper
INFO - 2018-12-31 10:54:31 --> Controller Class Initialized
INFO - 2018-12-31 10:54:31 --> Database Driver Class Initialized
INFO - 2018-12-31 10:54:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 10:54:31 --> Final output sent to browser
DEBUG - 2018-12-31 10:54:31 --> Total execution time: 0.1841
INFO - 2018-12-31 10:58:32 --> Config Class Initialized
INFO - 2018-12-31 10:58:32 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:58:32 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:58:32 --> Utf8 Class Initialized
INFO - 2018-12-31 10:58:32 --> URI Class Initialized
DEBUG - 2018-12-31 10:58:32 --> No URI present. Default controller set.
INFO - 2018-12-31 10:58:32 --> Router Class Initialized
INFO - 2018-12-31 10:58:32 --> Output Class Initialized
INFO - 2018-12-31 10:58:32 --> Security Class Initialized
DEBUG - 2018-12-31 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:58:32 --> CSRF cookie sent
INFO - 2018-12-31 10:58:32 --> Input Class Initialized
INFO - 2018-12-31 10:58:32 --> Language Class Initialized
INFO - 2018-12-31 10:58:32 --> Loader Class Initialized
INFO - 2018-12-31 10:58:32 --> Helper loaded: url_helper
INFO - 2018-12-31 10:58:32 --> Helper loaded: file_helper
INFO - 2018-12-31 10:58:32 --> Helper loaded: util_helper
INFO - 2018-12-31 10:58:32 --> Controller Class Initialized
INFO - 2018-12-31 10:58:32 --> Database Driver Class Initialized
INFO - 2018-12-31 10:58:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 10:58:32 --> Final output sent to browser
DEBUG - 2018-12-31 10:58:32 --> Total execution time: 0.1882
INFO - 2018-12-31 10:58:55 --> Config Class Initialized
INFO - 2018-12-31 10:58:55 --> Hooks Class Initialized
DEBUG - 2018-12-31 10:58:55 --> UTF-8 Support Enabled
INFO - 2018-12-31 10:58:55 --> Utf8 Class Initialized
INFO - 2018-12-31 10:58:55 --> URI Class Initialized
DEBUG - 2018-12-31 10:58:55 --> No URI present. Default controller set.
INFO - 2018-12-31 10:58:55 --> Router Class Initialized
INFO - 2018-12-31 10:58:55 --> Output Class Initialized
INFO - 2018-12-31 10:58:55 --> Security Class Initialized
DEBUG - 2018-12-31 10:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 10:58:55 --> CSRF cookie sent
INFO - 2018-12-31 10:58:55 --> Input Class Initialized
INFO - 2018-12-31 10:58:55 --> Language Class Initialized
INFO - 2018-12-31 10:58:55 --> Loader Class Initialized
INFO - 2018-12-31 10:58:55 --> Helper loaded: url_helper
INFO - 2018-12-31 10:58:55 --> Helper loaded: file_helper
INFO - 2018-12-31 10:58:55 --> Helper loaded: util_helper
INFO - 2018-12-31 10:58:55 --> Controller Class Initialized
INFO - 2018-12-31 10:58:55 --> Database Driver Class Initialized
INFO - 2018-12-31 10:58:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 10:58:55 --> Final output sent to browser
DEBUG - 2018-12-31 10:58:55 --> Total execution time: 0.1944
INFO - 2018-12-31 11:01:26 --> Config Class Initialized
INFO - 2018-12-31 11:01:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:01:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:01:26 --> Utf8 Class Initialized
INFO - 2018-12-31 11:01:26 --> URI Class Initialized
INFO - 2018-12-31 11:01:26 --> Router Class Initialized
INFO - 2018-12-31 11:01:26 --> Output Class Initialized
INFO - 2018-12-31 11:01:26 --> Security Class Initialized
DEBUG - 2018-12-31 11:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:01:26 --> CSRF cookie sent
INFO - 2018-12-31 11:01:26 --> Input Class Initialized
INFO - 2018-12-31 11:01:26 --> Language Class Initialized
ERROR - 2018-12-31 11:01:26 --> 404 Page Not Found: Index/index
INFO - 2018-12-31 11:01:30 --> Config Class Initialized
INFO - 2018-12-31 11:01:30 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:01:30 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:01:30 --> Utf8 Class Initialized
INFO - 2018-12-31 11:01:30 --> URI Class Initialized
DEBUG - 2018-12-31 11:01:30 --> No URI present. Default controller set.
INFO - 2018-12-31 11:01:30 --> Router Class Initialized
INFO - 2018-12-31 11:01:30 --> Output Class Initialized
INFO - 2018-12-31 11:01:30 --> Security Class Initialized
DEBUG - 2018-12-31 11:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:01:30 --> CSRF cookie sent
INFO - 2018-12-31 11:01:30 --> Input Class Initialized
INFO - 2018-12-31 11:01:30 --> Language Class Initialized
INFO - 2018-12-31 11:01:30 --> Loader Class Initialized
INFO - 2018-12-31 11:01:30 --> Helper loaded: url_helper
INFO - 2018-12-31 11:01:30 --> Helper loaded: file_helper
INFO - 2018-12-31 11:01:30 --> Helper loaded: util_helper
INFO - 2018-12-31 11:01:30 --> Controller Class Initialized
INFO - 2018-12-31 11:01:30 --> Database Driver Class Initialized
INFO - 2018-12-31 11:01:30 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 11:01:30 --> Final output sent to browser
DEBUG - 2018-12-31 11:01:30 --> Total execution time: 0.1855
INFO - 2018-12-31 11:01:52 --> Config Class Initialized
INFO - 2018-12-31 11:01:52 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:01:52 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:01:52 --> Utf8 Class Initialized
INFO - 2018-12-31 11:01:52 --> URI Class Initialized
INFO - 2018-12-31 11:01:52 --> Router Class Initialized
INFO - 2018-12-31 11:01:52 --> Output Class Initialized
INFO - 2018-12-31 11:01:52 --> Security Class Initialized
DEBUG - 2018-12-31 11:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:01:52 --> CSRF cookie sent
INFO - 2018-12-31 11:01:52 --> Input Class Initialized
INFO - 2018-12-31 11:01:52 --> Language Class Initialized
INFO - 2018-12-31 11:01:52 --> Loader Class Initialized
INFO - 2018-12-31 11:01:52 --> Helper loaded: url_helper
INFO - 2018-12-31 11:01:52 --> Helper loaded: file_helper
INFO - 2018-12-31 11:01:52 --> Helper loaded: util_helper
INFO - 2018-12-31 11:01:52 --> Controller Class Initialized
INFO - 2018-12-31 11:01:52 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:01:53 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:01:53 --> Email Class Initialized
INFO - 2018-12-31 11:01:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:01:53 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:01:53 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:01:53 --> Helper loaded: date_helper
INFO - 2018-12-31 11:01:53 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:01:53 --> Helper loaded: form_helper
INFO - 2018-12-31 11:01:53 --> Form Validation Class Initialized
INFO - 2018-12-31 11:01:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:01:53 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:01:53 --> Final output sent to browser
DEBUG - 2018-12-31 11:01:53 --> Total execution time: 0.3199
INFO - 2018-12-31 11:01:53 --> Config Class Initialized
INFO - 2018-12-31 11:01:53 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:01:53 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:01:53 --> Utf8 Class Initialized
INFO - 2018-12-31 11:01:53 --> URI Class Initialized
INFO - 2018-12-31 11:01:53 --> Router Class Initialized
INFO - 2018-12-31 11:01:53 --> Output Class Initialized
INFO - 2018-12-31 11:01:53 --> Security Class Initialized
DEBUG - 2018-12-31 11:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:01:53 --> CSRF cookie sent
INFO - 2018-12-31 11:01:53 --> Input Class Initialized
INFO - 2018-12-31 11:01:53 --> Language Class Initialized
INFO - 2018-12-31 11:01:53 --> Loader Class Initialized
INFO - 2018-12-31 11:01:53 --> Helper loaded: url_helper
INFO - 2018-12-31 11:01:53 --> Helper loaded: file_helper
INFO - 2018-12-31 11:01:53 --> Helper loaded: util_helper
INFO - 2018-12-31 11:01:53 --> Controller Class Initialized
INFO - 2018-12-31 11:01:53 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:01:53 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:01:53 --> Email Class Initialized
INFO - 2018-12-31 11:01:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:01:53 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:01:53 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:01:53 --> Helper loaded: date_helper
INFO - 2018-12-31 11:01:53 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:01:53 --> Helper loaded: form_helper
INFO - 2018-12-31 11:01:53 --> Form Validation Class Initialized
INFO - 2018-12-31 11:01:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:01:53 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:01:53 --> Final output sent to browser
DEBUG - 2018-12-31 11:01:53 --> Total execution time: 0.2731
INFO - 2018-12-31 11:02:09 --> Config Class Initialized
INFO - 2018-12-31 11:02:09 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:02:09 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:02:09 --> Utf8 Class Initialized
INFO - 2018-12-31 11:02:09 --> URI Class Initialized
INFO - 2018-12-31 11:02:09 --> Router Class Initialized
INFO - 2018-12-31 11:02:09 --> Output Class Initialized
INFO - 2018-12-31 11:02:09 --> Security Class Initialized
DEBUG - 2018-12-31 11:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:02:09 --> CSRF cookie sent
INFO - 2018-12-31 11:02:09 --> Input Class Initialized
INFO - 2018-12-31 11:02:09 --> Language Class Initialized
INFO - 2018-12-31 11:02:09 --> Loader Class Initialized
INFO - 2018-12-31 11:02:09 --> Helper loaded: url_helper
INFO - 2018-12-31 11:02:09 --> Helper loaded: file_helper
INFO - 2018-12-31 11:02:09 --> Helper loaded: util_helper
INFO - 2018-12-31 11:02:09 --> Controller Class Initialized
INFO - 2018-12-31 11:02:09 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:02:09 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:02:09 --> Email Class Initialized
INFO - 2018-12-31 11:02:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:02:09 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:02:09 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:02:09 --> Helper loaded: date_helper
INFO - 2018-12-31 11:02:09 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:02:09 --> Helper loaded: form_helper
INFO - 2018-12-31 11:02:09 --> Form Validation Class Initialized
INFO - 2018-12-31 11:02:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:02:09 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\forgot_password.php
INFO - 2018-12-31 11:02:09 --> Final output sent to browser
DEBUG - 2018-12-31 11:02:09 --> Total execution time: 0.3372
INFO - 2018-12-31 11:02:13 --> Config Class Initialized
INFO - 2018-12-31 11:02:13 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:02:13 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:02:13 --> Utf8 Class Initialized
INFO - 2018-12-31 11:02:13 --> URI Class Initialized
INFO - 2018-12-31 11:02:13 --> Router Class Initialized
INFO - 2018-12-31 11:02:13 --> Output Class Initialized
INFO - 2018-12-31 11:02:13 --> Security Class Initialized
DEBUG - 2018-12-31 11:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:02:13 --> CSRF cookie sent
INFO - 2018-12-31 11:02:13 --> Input Class Initialized
INFO - 2018-12-31 11:02:13 --> Language Class Initialized
INFO - 2018-12-31 11:02:13 --> Loader Class Initialized
INFO - 2018-12-31 11:02:13 --> Helper loaded: url_helper
INFO - 2018-12-31 11:02:13 --> Helper loaded: file_helper
INFO - 2018-12-31 11:02:13 --> Helper loaded: util_helper
INFO - 2018-12-31 11:02:13 --> Controller Class Initialized
INFO - 2018-12-31 11:02:13 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:02:13 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:02:13 --> Email Class Initialized
INFO - 2018-12-31 11:02:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:02:13 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:02:13 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:02:13 --> Helper loaded: date_helper
INFO - 2018-12-31 11:02:13 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:02:13 --> Helper loaded: form_helper
INFO - 2018-12-31 11:02:13 --> Form Validation Class Initialized
INFO - 2018-12-31 11:02:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:02:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:02:13 --> Final output sent to browser
DEBUG - 2018-12-31 11:02:13 --> Total execution time: 0.2804
INFO - 2018-12-31 11:02:19 --> Config Class Initialized
INFO - 2018-12-31 11:02:19 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:02:19 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:02:19 --> Utf8 Class Initialized
INFO - 2018-12-31 11:02:19 --> URI Class Initialized
INFO - 2018-12-31 11:02:19 --> Router Class Initialized
INFO - 2018-12-31 11:02:19 --> Output Class Initialized
INFO - 2018-12-31 11:02:19 --> Security Class Initialized
DEBUG - 2018-12-31 11:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:02:19 --> CSRF cookie sent
INFO - 2018-12-31 11:02:19 --> Input Class Initialized
INFO - 2018-12-31 11:02:19 --> Language Class Initialized
INFO - 2018-12-31 11:02:19 --> Loader Class Initialized
INFO - 2018-12-31 11:02:19 --> Helper loaded: url_helper
INFO - 2018-12-31 11:02:19 --> Helper loaded: file_helper
INFO - 2018-12-31 11:02:19 --> Helper loaded: util_helper
INFO - 2018-12-31 11:02:19 --> Controller Class Initialized
INFO - 2018-12-31 11:02:19 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:02:19 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:02:19 --> Email Class Initialized
INFO - 2018-12-31 11:02:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:02:19 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:02:19 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:02:19 --> Helper loaded: date_helper
INFO - 2018-12-31 11:02:19 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:02:19 --> Helper loaded: form_helper
INFO - 2018-12-31 11:02:19 --> Form Validation Class Initialized
INFO - 2018-12-31 11:02:19 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:02:19 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 11:02:19 --> Final output sent to browser
DEBUG - 2018-12-31 11:02:19 --> Total execution time: 0.2819
INFO - 2018-12-31 11:04:25 --> Config Class Initialized
INFO - 2018-12-31 11:04:25 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:04:25 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:04:25 --> Utf8 Class Initialized
INFO - 2018-12-31 11:04:26 --> URI Class Initialized
DEBUG - 2018-12-31 11:04:26 --> No URI present. Default controller set.
INFO - 2018-12-31 11:04:26 --> Router Class Initialized
INFO - 2018-12-31 11:04:26 --> Output Class Initialized
INFO - 2018-12-31 11:04:26 --> Security Class Initialized
DEBUG - 2018-12-31 11:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:04:26 --> CSRF cookie sent
INFO - 2018-12-31 11:04:26 --> Input Class Initialized
INFO - 2018-12-31 11:04:26 --> Language Class Initialized
INFO - 2018-12-31 11:04:26 --> Loader Class Initialized
INFO - 2018-12-31 11:04:26 --> Helper loaded: url_helper
INFO - 2018-12-31 11:04:26 --> Helper loaded: file_helper
INFO - 2018-12-31 11:04:26 --> Helper loaded: util_helper
INFO - 2018-12-31 11:04:26 --> Controller Class Initialized
INFO - 2018-12-31 11:04:26 --> Database Driver Class Initialized
INFO - 2018-12-31 11:04:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 11:04:26 --> Final output sent to browser
DEBUG - 2018-12-31 11:04:26 --> Total execution time: 0.2552
INFO - 2018-12-31 11:20:34 --> Config Class Initialized
INFO - 2018-12-31 11:20:34 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:20:34 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:20:34 --> Utf8 Class Initialized
INFO - 2018-12-31 11:20:34 --> URI Class Initialized
DEBUG - 2018-12-31 11:20:34 --> No URI present. Default controller set.
INFO - 2018-12-31 11:20:34 --> Router Class Initialized
INFO - 2018-12-31 11:20:34 --> Output Class Initialized
INFO - 2018-12-31 11:20:34 --> Security Class Initialized
DEBUG - 2018-12-31 11:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:20:34 --> CSRF cookie sent
INFO - 2018-12-31 11:20:34 --> Input Class Initialized
INFO - 2018-12-31 11:20:34 --> Language Class Initialized
INFO - 2018-12-31 11:20:34 --> Loader Class Initialized
INFO - 2018-12-31 11:20:34 --> Helper loaded: url_helper
INFO - 2018-12-31 11:20:34 --> Helper loaded: file_helper
INFO - 2018-12-31 11:20:34 --> Helper loaded: util_helper
INFO - 2018-12-31 11:20:34 --> Controller Class Initialized
INFO - 2018-12-31 11:20:34 --> Database Driver Class Initialized
INFO - 2018-12-31 11:20:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 11:20:34 --> Final output sent to browser
DEBUG - 2018-12-31 11:20:34 --> Total execution time: 0.1752
INFO - 2018-12-31 11:20:39 --> Config Class Initialized
INFO - 2018-12-31 11:20:39 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:20:39 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:20:39 --> Utf8 Class Initialized
INFO - 2018-12-31 11:20:39 --> URI Class Initialized
INFO - 2018-12-31 11:20:39 --> Router Class Initialized
INFO - 2018-12-31 11:20:39 --> Output Class Initialized
INFO - 2018-12-31 11:20:39 --> Security Class Initialized
DEBUG - 2018-12-31 11:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:20:39 --> CSRF cookie sent
INFO - 2018-12-31 11:20:39 --> Input Class Initialized
INFO - 2018-12-31 11:20:39 --> Language Class Initialized
INFO - 2018-12-31 11:20:39 --> Loader Class Initialized
INFO - 2018-12-31 11:20:39 --> Helper loaded: url_helper
INFO - 2018-12-31 11:20:39 --> Helper loaded: file_helper
INFO - 2018-12-31 11:20:39 --> Helper loaded: util_helper
INFO - 2018-12-31 11:20:39 --> Controller Class Initialized
INFO - 2018-12-31 11:20:39 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:20:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:20:39 --> Email Class Initialized
INFO - 2018-12-31 11:20:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:20:39 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:20:39 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:20:39 --> Helper loaded: date_helper
INFO - 2018-12-31 11:20:39 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:20:39 --> Helper loaded: form_helper
INFO - 2018-12-31 11:20:39 --> Form Validation Class Initialized
INFO - 2018-12-31 11:20:39 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:20:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:20:39 --> Final output sent to browser
DEBUG - 2018-12-31 11:20:39 --> Total execution time: 0.2788
INFO - 2018-12-31 11:21:09 --> Config Class Initialized
INFO - 2018-12-31 11:21:09 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:21:09 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:21:09 --> Utf8 Class Initialized
INFO - 2018-12-31 11:21:09 --> URI Class Initialized
INFO - 2018-12-31 11:21:09 --> Router Class Initialized
INFO - 2018-12-31 11:21:09 --> Output Class Initialized
INFO - 2018-12-31 11:21:09 --> Security Class Initialized
DEBUG - 2018-12-31 11:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:21:09 --> CSRF cookie sent
INFO - 2018-12-31 11:21:09 --> Input Class Initialized
INFO - 2018-12-31 11:21:09 --> Language Class Initialized
INFO - 2018-12-31 11:21:09 --> Loader Class Initialized
INFO - 2018-12-31 11:21:09 --> Helper loaded: url_helper
INFO - 2018-12-31 11:21:09 --> Helper loaded: file_helper
INFO - 2018-12-31 11:21:09 --> Helper loaded: util_helper
INFO - 2018-12-31 11:21:09 --> Controller Class Initialized
INFO - 2018-12-31 11:21:10 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:21:10 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:21:10 --> Email Class Initialized
INFO - 2018-12-31 11:21:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:21:10 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:21:10 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:21:10 --> Helper loaded: date_helper
INFO - 2018-12-31 11:21:10 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:21:10 --> Helper loaded: form_helper
INFO - 2018-12-31 11:21:10 --> Form Validation Class Initialized
INFO - 2018-12-31 11:21:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:21:10 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:21:10 --> Final output sent to browser
DEBUG - 2018-12-31 11:21:10 --> Total execution time: 0.3021
INFO - 2018-12-31 11:21:20 --> Config Class Initialized
INFO - 2018-12-31 11:21:20 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:21:20 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:21:20 --> Utf8 Class Initialized
INFO - 2018-12-31 11:21:20 --> URI Class Initialized
INFO - 2018-12-31 11:21:20 --> Router Class Initialized
INFO - 2018-12-31 11:21:20 --> Output Class Initialized
INFO - 2018-12-31 11:21:20 --> Security Class Initialized
DEBUG - 2018-12-31 11:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:21:20 --> CSRF cookie sent
INFO - 2018-12-31 11:21:20 --> Input Class Initialized
INFO - 2018-12-31 11:21:20 --> Language Class Initialized
INFO - 2018-12-31 11:21:20 --> Loader Class Initialized
INFO - 2018-12-31 11:21:20 --> Helper loaded: url_helper
INFO - 2018-12-31 11:21:20 --> Helper loaded: file_helper
INFO - 2018-12-31 11:21:20 --> Helper loaded: util_helper
INFO - 2018-12-31 11:21:20 --> Controller Class Initialized
INFO - 2018-12-31 11:21:20 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:21:20 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:21:20 --> Email Class Initialized
INFO - 2018-12-31 11:21:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:21:20 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:21:20 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:21:20 --> Helper loaded: date_helper
INFO - 2018-12-31 11:21:20 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:21:20 --> Helper loaded: form_helper
INFO - 2018-12-31 11:21:20 --> Form Validation Class Initialized
INFO - 2018-12-31 11:21:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:21:20 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:21:20 --> Final output sent to browser
DEBUG - 2018-12-31 11:21:20 --> Total execution time: 0.2790
INFO - 2018-12-31 11:21:41 --> Config Class Initialized
INFO - 2018-12-31 11:21:41 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:21:41 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:21:41 --> Utf8 Class Initialized
INFO - 2018-12-31 11:21:41 --> URI Class Initialized
INFO - 2018-12-31 11:21:41 --> Router Class Initialized
INFO - 2018-12-31 11:21:41 --> Output Class Initialized
INFO - 2018-12-31 11:21:41 --> Security Class Initialized
DEBUG - 2018-12-31 11:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:21:41 --> CSRF cookie sent
INFO - 2018-12-31 11:21:41 --> Input Class Initialized
INFO - 2018-12-31 11:21:41 --> Language Class Initialized
INFO - 2018-12-31 11:21:41 --> Loader Class Initialized
INFO - 2018-12-31 11:21:41 --> Helper loaded: url_helper
INFO - 2018-12-31 11:21:41 --> Helper loaded: file_helper
INFO - 2018-12-31 11:21:41 --> Helper loaded: util_helper
INFO - 2018-12-31 11:21:41 --> Controller Class Initialized
INFO - 2018-12-31 11:21:41 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:21:41 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:21:41 --> Email Class Initialized
INFO - 2018-12-31 11:21:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:21:41 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:21:41 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:21:41 --> Helper loaded: date_helper
INFO - 2018-12-31 11:21:41 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:21:41 --> Helper loaded: form_helper
INFO - 2018-12-31 11:21:41 --> Form Validation Class Initialized
INFO - 2018-12-31 11:21:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:21:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:21:41 --> Final output sent to browser
DEBUG - 2018-12-31 11:21:41 --> Total execution time: 0.2763
INFO - 2018-12-31 11:24:16 --> Config Class Initialized
INFO - 2018-12-31 11:24:16 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:24:16 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:24:16 --> Utf8 Class Initialized
INFO - 2018-12-31 11:24:16 --> URI Class Initialized
INFO - 2018-12-31 11:24:16 --> Router Class Initialized
INFO - 2018-12-31 11:24:16 --> Output Class Initialized
INFO - 2018-12-31 11:24:16 --> Security Class Initialized
DEBUG - 2018-12-31 11:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:24:16 --> CSRF cookie sent
INFO - 2018-12-31 11:24:16 --> Input Class Initialized
INFO - 2018-12-31 11:24:16 --> Language Class Initialized
INFO - 2018-12-31 11:24:16 --> Loader Class Initialized
INFO - 2018-12-31 11:24:16 --> Helper loaded: url_helper
INFO - 2018-12-31 11:24:16 --> Helper loaded: file_helper
INFO - 2018-12-31 11:24:16 --> Helper loaded: util_helper
INFO - 2018-12-31 11:24:16 --> Controller Class Initialized
INFO - 2018-12-31 11:24:16 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:24:16 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:24:16 --> Email Class Initialized
INFO - 2018-12-31 11:24:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:24:16 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:24:16 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:24:16 --> Helper loaded: date_helper
INFO - 2018-12-31 11:24:16 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:24:16 --> Helper loaded: form_helper
INFO - 2018-12-31 11:24:16 --> Form Validation Class Initialized
INFO - 2018-12-31 11:24:16 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:24:16 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:24:16 --> Final output sent to browser
DEBUG - 2018-12-31 11:24:16 --> Total execution time: 0.2799
INFO - 2018-12-31 11:28:27 --> Config Class Initialized
INFO - 2018-12-31 11:28:27 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:28:27 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:28:27 --> Utf8 Class Initialized
INFO - 2018-12-31 11:28:27 --> URI Class Initialized
INFO - 2018-12-31 11:28:27 --> Router Class Initialized
INFO - 2018-12-31 11:28:27 --> Output Class Initialized
INFO - 2018-12-31 11:28:27 --> Security Class Initialized
DEBUG - 2018-12-31 11:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:28:27 --> CSRF cookie sent
INFO - 2018-12-31 11:28:27 --> Input Class Initialized
INFO - 2018-12-31 11:28:27 --> Language Class Initialized
INFO - 2018-12-31 11:28:27 --> Loader Class Initialized
INFO - 2018-12-31 11:28:27 --> Helper loaded: url_helper
INFO - 2018-12-31 11:28:27 --> Helper loaded: file_helper
INFO - 2018-12-31 11:28:27 --> Helper loaded: util_helper
INFO - 2018-12-31 11:28:27 --> Controller Class Initialized
INFO - 2018-12-31 11:28:27 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:28:27 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:28:27 --> Email Class Initialized
INFO - 2018-12-31 11:28:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:28:27 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:28:27 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:28:27 --> Helper loaded: date_helper
INFO - 2018-12-31 11:28:27 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:28:27 --> Helper loaded: form_helper
INFO - 2018-12-31 11:28:27 --> Form Validation Class Initialized
INFO - 2018-12-31 11:28:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:28:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:28:27 --> Final output sent to browser
DEBUG - 2018-12-31 11:28:27 --> Total execution time: 0.2945
INFO - 2018-12-31 11:31:56 --> Config Class Initialized
INFO - 2018-12-31 11:31:56 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:31:56 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:31:56 --> Utf8 Class Initialized
INFO - 2018-12-31 11:31:56 --> URI Class Initialized
INFO - 2018-12-31 11:31:56 --> Router Class Initialized
INFO - 2018-12-31 11:31:56 --> Output Class Initialized
INFO - 2018-12-31 11:31:56 --> Security Class Initialized
DEBUG - 2018-12-31 11:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:31:56 --> CSRF cookie sent
INFO - 2018-12-31 11:31:56 --> Input Class Initialized
INFO - 2018-12-31 11:31:56 --> Language Class Initialized
INFO - 2018-12-31 11:31:56 --> Loader Class Initialized
INFO - 2018-12-31 11:31:56 --> Helper loaded: url_helper
INFO - 2018-12-31 11:31:56 --> Helper loaded: file_helper
INFO - 2018-12-31 11:31:56 --> Helper loaded: util_helper
INFO - 2018-12-31 11:31:56 --> Controller Class Initialized
INFO - 2018-12-31 11:31:56 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:31:56 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:31:56 --> Email Class Initialized
INFO - 2018-12-31 11:31:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:31:56 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:31:56 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:31:56 --> Helper loaded: date_helper
INFO - 2018-12-31 11:31:56 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:31:56 --> Helper loaded: form_helper
INFO - 2018-12-31 11:31:56 --> Form Validation Class Initialized
INFO - 2018-12-31 11:31:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:31:56 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:31:56 --> Final output sent to browser
DEBUG - 2018-12-31 11:31:56 --> Total execution time: 0.2922
INFO - 2018-12-31 11:32:30 --> Config Class Initialized
INFO - 2018-12-31 11:32:30 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:32:30 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:32:30 --> Utf8 Class Initialized
INFO - 2018-12-31 11:32:30 --> URI Class Initialized
INFO - 2018-12-31 11:32:30 --> Router Class Initialized
INFO - 2018-12-31 11:32:30 --> Output Class Initialized
INFO - 2018-12-31 11:32:30 --> Security Class Initialized
DEBUG - 2018-12-31 11:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:32:30 --> CSRF cookie sent
INFO - 2018-12-31 11:32:30 --> Input Class Initialized
INFO - 2018-12-31 11:32:30 --> Language Class Initialized
INFO - 2018-12-31 11:32:30 --> Loader Class Initialized
INFO - 2018-12-31 11:32:30 --> Helper loaded: url_helper
INFO - 2018-12-31 11:32:30 --> Helper loaded: file_helper
INFO - 2018-12-31 11:32:30 --> Helper loaded: util_helper
INFO - 2018-12-31 11:32:30 --> Controller Class Initialized
INFO - 2018-12-31 11:32:30 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:32:30 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:32:30 --> Email Class Initialized
INFO - 2018-12-31 11:32:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:32:30 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:32:30 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:32:30 --> Helper loaded: date_helper
INFO - 2018-12-31 11:32:30 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:32:30 --> Helper loaded: form_helper
INFO - 2018-12-31 11:32:30 --> Form Validation Class Initialized
INFO - 2018-12-31 11:32:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:32:30 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:32:30 --> Final output sent to browser
DEBUG - 2018-12-31 11:32:30 --> Total execution time: 0.2956
INFO - 2018-12-31 11:34:26 --> Config Class Initialized
INFO - 2018-12-31 11:34:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:34:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:34:26 --> Utf8 Class Initialized
INFO - 2018-12-31 11:34:26 --> URI Class Initialized
INFO - 2018-12-31 11:34:26 --> Router Class Initialized
INFO - 2018-12-31 11:34:26 --> Output Class Initialized
INFO - 2018-12-31 11:34:26 --> Security Class Initialized
DEBUG - 2018-12-31 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:34:26 --> CSRF cookie sent
INFO - 2018-12-31 11:34:26 --> Input Class Initialized
INFO - 2018-12-31 11:34:26 --> Language Class Initialized
INFO - 2018-12-31 11:34:26 --> Loader Class Initialized
INFO - 2018-12-31 11:34:26 --> Helper loaded: url_helper
INFO - 2018-12-31 11:34:26 --> Helper loaded: file_helper
INFO - 2018-12-31 11:34:26 --> Helper loaded: util_helper
INFO - 2018-12-31 11:34:26 --> Controller Class Initialized
INFO - 2018-12-31 11:34:26 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:34:26 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:34:26 --> Email Class Initialized
INFO - 2018-12-31 11:34:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:34:26 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:34:26 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:34:26 --> Helper loaded: date_helper
INFO - 2018-12-31 11:34:26 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:34:26 --> Helper loaded: form_helper
INFO - 2018-12-31 11:34:26 --> Form Validation Class Initialized
INFO - 2018-12-31 11:34:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:34:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:34:26 --> Final output sent to browser
DEBUG - 2018-12-31 11:34:26 --> Total execution time: 0.3189
INFO - 2018-12-31 11:36:22 --> Config Class Initialized
INFO - 2018-12-31 11:36:22 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:36:22 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:36:22 --> Utf8 Class Initialized
INFO - 2018-12-31 11:36:22 --> URI Class Initialized
INFO - 2018-12-31 11:36:22 --> Router Class Initialized
INFO - 2018-12-31 11:36:22 --> Output Class Initialized
INFO - 2018-12-31 11:36:22 --> Security Class Initialized
DEBUG - 2018-12-31 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:36:22 --> CSRF cookie sent
INFO - 2018-12-31 11:36:22 --> Input Class Initialized
INFO - 2018-12-31 11:36:22 --> Language Class Initialized
INFO - 2018-12-31 11:36:22 --> Loader Class Initialized
INFO - 2018-12-31 11:36:22 --> Helper loaded: url_helper
INFO - 2018-12-31 11:36:22 --> Helper loaded: file_helper
INFO - 2018-12-31 11:36:22 --> Helper loaded: util_helper
INFO - 2018-12-31 11:36:22 --> Controller Class Initialized
INFO - 2018-12-31 11:36:22 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:36:22 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:36:22 --> Email Class Initialized
INFO - 2018-12-31 11:36:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:36:22 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:36:22 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:36:22 --> Helper loaded: date_helper
INFO - 2018-12-31 11:36:22 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:36:22 --> Helper loaded: form_helper
INFO - 2018-12-31 11:36:22 --> Form Validation Class Initialized
INFO - 2018-12-31 11:36:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:36:22 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:36:22 --> Final output sent to browser
DEBUG - 2018-12-31 11:36:22 --> Total execution time: 0.2778
INFO - 2018-12-31 11:37:34 --> Config Class Initialized
INFO - 2018-12-31 11:37:34 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:37:34 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:37:34 --> Utf8 Class Initialized
INFO - 2018-12-31 11:37:34 --> URI Class Initialized
INFO - 2018-12-31 11:37:34 --> Router Class Initialized
INFO - 2018-12-31 11:37:34 --> Output Class Initialized
INFO - 2018-12-31 11:37:35 --> Security Class Initialized
DEBUG - 2018-12-31 11:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:37:35 --> CSRF cookie sent
INFO - 2018-12-31 11:37:35 --> Input Class Initialized
INFO - 2018-12-31 11:37:35 --> Language Class Initialized
INFO - 2018-12-31 11:37:35 --> Loader Class Initialized
INFO - 2018-12-31 11:37:35 --> Helper loaded: url_helper
INFO - 2018-12-31 11:37:35 --> Helper loaded: file_helper
INFO - 2018-12-31 11:37:35 --> Helper loaded: util_helper
INFO - 2018-12-31 11:37:35 --> Controller Class Initialized
INFO - 2018-12-31 11:37:35 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:37:35 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:37:35 --> Email Class Initialized
INFO - 2018-12-31 11:37:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:37:35 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:37:35 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:37:35 --> Helper loaded: date_helper
INFO - 2018-12-31 11:37:35 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:37:35 --> Helper loaded: form_helper
INFO - 2018-12-31 11:37:35 --> Form Validation Class Initialized
INFO - 2018-12-31 11:37:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:37:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:37:35 --> Final output sent to browser
DEBUG - 2018-12-31 11:37:35 --> Total execution time: 0.2883
INFO - 2018-12-31 11:37:52 --> Config Class Initialized
INFO - 2018-12-31 11:37:52 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:37:52 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:37:52 --> Utf8 Class Initialized
INFO - 2018-12-31 11:37:52 --> URI Class Initialized
INFO - 2018-12-31 11:37:52 --> Router Class Initialized
INFO - 2018-12-31 11:37:52 --> Output Class Initialized
INFO - 2018-12-31 11:37:52 --> Security Class Initialized
DEBUG - 2018-12-31 11:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:37:52 --> CSRF cookie sent
INFO - 2018-12-31 11:37:52 --> Input Class Initialized
INFO - 2018-12-31 11:37:52 --> Language Class Initialized
INFO - 2018-12-31 11:37:52 --> Loader Class Initialized
INFO - 2018-12-31 11:37:52 --> Helper loaded: url_helper
INFO - 2018-12-31 11:37:52 --> Helper loaded: file_helper
INFO - 2018-12-31 11:37:52 --> Helper loaded: util_helper
INFO - 2018-12-31 11:37:52 --> Controller Class Initialized
INFO - 2018-12-31 11:37:52 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:37:52 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:37:52 --> Email Class Initialized
INFO - 2018-12-31 11:37:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:37:52 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:37:52 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:37:52 --> Helper loaded: date_helper
INFO - 2018-12-31 11:37:52 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:37:52 --> Helper loaded: form_helper
INFO - 2018-12-31 11:37:52 --> Form Validation Class Initialized
INFO - 2018-12-31 11:37:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:37:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:37:52 --> Final output sent to browser
DEBUG - 2018-12-31 11:37:52 --> Total execution time: 0.2806
INFO - 2018-12-31 11:41:12 --> Config Class Initialized
INFO - 2018-12-31 11:41:12 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:41:12 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:41:12 --> Utf8 Class Initialized
INFO - 2018-12-31 11:41:12 --> URI Class Initialized
INFO - 2018-12-31 11:41:12 --> Router Class Initialized
INFO - 2018-12-31 11:41:12 --> Output Class Initialized
INFO - 2018-12-31 11:41:12 --> Security Class Initialized
DEBUG - 2018-12-31 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:41:12 --> CSRF cookie sent
INFO - 2018-12-31 11:41:12 --> Input Class Initialized
INFO - 2018-12-31 11:41:12 --> Language Class Initialized
INFO - 2018-12-31 11:41:12 --> Loader Class Initialized
INFO - 2018-12-31 11:41:12 --> Helper loaded: url_helper
INFO - 2018-12-31 11:41:12 --> Helper loaded: file_helper
INFO - 2018-12-31 11:41:12 --> Helper loaded: util_helper
INFO - 2018-12-31 11:41:12 --> Controller Class Initialized
INFO - 2018-12-31 11:41:12 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:41:12 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:41:12 --> Email Class Initialized
INFO - 2018-12-31 11:41:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:41:12 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:41:12 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:41:13 --> Helper loaded: date_helper
INFO - 2018-12-31 11:41:13 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:41:13 --> Helper loaded: form_helper
INFO - 2018-12-31 11:41:13 --> Form Validation Class Initialized
INFO - 2018-12-31 11:41:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:41:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:41:13 --> Final output sent to browser
DEBUG - 2018-12-31 11:41:13 --> Total execution time: 0.2705
INFO - 2018-12-31 11:47:15 --> Config Class Initialized
INFO - 2018-12-31 11:47:15 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:47:15 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:47:15 --> Utf8 Class Initialized
INFO - 2018-12-31 11:47:15 --> URI Class Initialized
INFO - 2018-12-31 11:47:15 --> Router Class Initialized
INFO - 2018-12-31 11:47:15 --> Output Class Initialized
INFO - 2018-12-31 11:47:15 --> Security Class Initialized
DEBUG - 2018-12-31 11:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:47:15 --> CSRF cookie sent
INFO - 2018-12-31 11:47:15 --> Input Class Initialized
INFO - 2018-12-31 11:47:15 --> Language Class Initialized
INFO - 2018-12-31 11:47:15 --> Loader Class Initialized
INFO - 2018-12-31 11:47:15 --> Helper loaded: url_helper
INFO - 2018-12-31 11:47:15 --> Helper loaded: file_helper
INFO - 2018-12-31 11:47:15 --> Helper loaded: util_helper
INFO - 2018-12-31 11:47:15 --> Controller Class Initialized
INFO - 2018-12-31 11:47:15 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:47:15 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:47:15 --> Email Class Initialized
INFO - 2018-12-31 11:47:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:47:15 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:47:15 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:47:15 --> Helper loaded: date_helper
INFO - 2018-12-31 11:47:15 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:47:15 --> Helper loaded: form_helper
INFO - 2018-12-31 11:47:15 --> Form Validation Class Initialized
INFO - 2018-12-31 11:47:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:47:15 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:47:15 --> Final output sent to browser
DEBUG - 2018-12-31 11:47:15 --> Total execution time: 0.3021
INFO - 2018-12-31 11:50:00 --> Config Class Initialized
INFO - 2018-12-31 11:50:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:50:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:50:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:50:00 --> URI Class Initialized
INFO - 2018-12-31 11:50:00 --> Router Class Initialized
INFO - 2018-12-31 11:50:00 --> Output Class Initialized
INFO - 2018-12-31 11:50:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:50:00 --> CSRF cookie sent
INFO - 2018-12-31 11:50:00 --> Input Class Initialized
INFO - 2018-12-31 11:50:00 --> Language Class Initialized
INFO - 2018-12-31 11:50:00 --> Loader Class Initialized
INFO - 2018-12-31 11:50:00 --> Helper loaded: url_helper
INFO - 2018-12-31 11:50:00 --> Helper loaded: file_helper
INFO - 2018-12-31 11:50:00 --> Helper loaded: util_helper
INFO - 2018-12-31 11:50:00 --> Controller Class Initialized
INFO - 2018-12-31 11:50:00 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:50:00 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:50:00 --> Email Class Initialized
INFO - 2018-12-31 11:50:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:50:00 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:50:00 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:50:00 --> Helper loaded: date_helper
INFO - 2018-12-31 11:50:00 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:50:00 --> Helper loaded: form_helper
INFO - 2018-12-31 11:50:00 --> Form Validation Class Initialized
INFO - 2018-12-31 11:50:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:50:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:50:00 --> Final output sent to browser
DEBUG - 2018-12-31 11:50:00 --> Total execution time: 0.2795
INFO - 2018-12-31 11:52:31 --> Config Class Initialized
INFO - 2018-12-31 11:52:32 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:52:32 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:52:32 --> Utf8 Class Initialized
INFO - 2018-12-31 11:52:32 --> URI Class Initialized
INFO - 2018-12-31 11:52:32 --> Router Class Initialized
INFO - 2018-12-31 11:52:32 --> Output Class Initialized
INFO - 2018-12-31 11:52:32 --> Security Class Initialized
DEBUG - 2018-12-31 11:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:52:32 --> CSRF cookie sent
INFO - 2018-12-31 11:52:32 --> Input Class Initialized
INFO - 2018-12-31 11:52:32 --> Language Class Initialized
INFO - 2018-12-31 11:52:32 --> Loader Class Initialized
INFO - 2018-12-31 11:52:32 --> Helper loaded: url_helper
INFO - 2018-12-31 11:52:32 --> Helper loaded: file_helper
INFO - 2018-12-31 11:52:32 --> Helper loaded: util_helper
INFO - 2018-12-31 11:52:32 --> Controller Class Initialized
INFO - 2018-12-31 11:52:32 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:52:32 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:52:32 --> Email Class Initialized
INFO - 2018-12-31 11:52:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:52:32 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:52:32 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:52:32 --> Helper loaded: date_helper
INFO - 2018-12-31 11:52:32 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:52:32 --> Helper loaded: form_helper
INFO - 2018-12-31 11:52:32 --> Form Validation Class Initialized
INFO - 2018-12-31 11:52:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:52:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:52:32 --> Final output sent to browser
DEBUG - 2018-12-31 11:52:32 --> Total execution time: 0.2769
INFO - 2018-12-31 11:52:44 --> Config Class Initialized
INFO - 2018-12-31 11:52:44 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:52:44 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:52:44 --> Utf8 Class Initialized
INFO - 2018-12-31 11:52:44 --> URI Class Initialized
INFO - 2018-12-31 11:52:44 --> Router Class Initialized
INFO - 2018-12-31 11:52:44 --> Output Class Initialized
INFO - 2018-12-31 11:52:44 --> Security Class Initialized
DEBUG - 2018-12-31 11:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:52:44 --> CSRF cookie sent
INFO - 2018-12-31 11:52:44 --> Input Class Initialized
INFO - 2018-12-31 11:52:44 --> Language Class Initialized
INFO - 2018-12-31 11:52:44 --> Loader Class Initialized
INFO - 2018-12-31 11:52:44 --> Helper loaded: url_helper
INFO - 2018-12-31 11:52:44 --> Helper loaded: file_helper
INFO - 2018-12-31 11:52:44 --> Helper loaded: util_helper
INFO - 2018-12-31 11:52:44 --> Controller Class Initialized
INFO - 2018-12-31 11:52:44 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:52:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:52:44 --> Email Class Initialized
INFO - 2018-12-31 11:52:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:52:44 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:52:45 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:52:45 --> Helper loaded: date_helper
INFO - 2018-12-31 11:52:45 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:52:45 --> Helper loaded: form_helper
INFO - 2018-12-31 11:52:45 --> Form Validation Class Initialized
INFO - 2018-12-31 11:52:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:52:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:52:45 --> Final output sent to browser
DEBUG - 2018-12-31 11:52:45 --> Total execution time: 0.3060
INFO - 2018-12-31 11:53:49 --> Config Class Initialized
INFO - 2018-12-31 11:53:49 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:53:49 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:53:49 --> Utf8 Class Initialized
INFO - 2018-12-31 11:53:49 --> URI Class Initialized
INFO - 2018-12-31 11:53:49 --> Router Class Initialized
INFO - 2018-12-31 11:53:49 --> Output Class Initialized
INFO - 2018-12-31 11:53:49 --> Security Class Initialized
DEBUG - 2018-12-31 11:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:53:49 --> CSRF cookie sent
INFO - 2018-12-31 11:53:49 --> Input Class Initialized
INFO - 2018-12-31 11:53:49 --> Language Class Initialized
INFO - 2018-12-31 11:53:49 --> Loader Class Initialized
INFO - 2018-12-31 11:53:50 --> Helper loaded: url_helper
INFO - 2018-12-31 11:53:50 --> Helper loaded: file_helper
INFO - 2018-12-31 11:53:50 --> Helper loaded: util_helper
INFO - 2018-12-31 11:53:50 --> Controller Class Initialized
INFO - 2018-12-31 11:53:50 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:53:50 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:53:50 --> Email Class Initialized
INFO - 2018-12-31 11:53:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:53:50 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:53:50 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:53:50 --> Helper loaded: date_helper
INFO - 2018-12-31 11:53:50 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:53:50 --> Helper loaded: form_helper
INFO - 2018-12-31 11:53:50 --> Form Validation Class Initialized
INFO - 2018-12-31 11:53:50 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:53:50 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:53:50 --> Final output sent to browser
DEBUG - 2018-12-31 11:53:50 --> Total execution time: 0.2944
INFO - 2018-12-31 11:54:31 --> Config Class Initialized
INFO - 2018-12-31 11:54:31 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:31 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:31 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:31 --> URI Class Initialized
INFO - 2018-12-31 11:54:31 --> Router Class Initialized
INFO - 2018-12-31 11:54:31 --> Output Class Initialized
INFO - 2018-12-31 11:54:31 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:31 --> CSRF cookie sent
INFO - 2018-12-31 11:54:31 --> Input Class Initialized
INFO - 2018-12-31 11:54:31 --> Language Class Initialized
INFO - 2018-12-31 11:54:31 --> Loader Class Initialized
INFO - 2018-12-31 11:54:31 --> Helper loaded: url_helper
INFO - 2018-12-31 11:54:31 --> Helper loaded: file_helper
INFO - 2018-12-31 11:54:31 --> Helper loaded: util_helper
INFO - 2018-12-31 11:54:31 --> Controller Class Initialized
INFO - 2018-12-31 11:54:31 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:54:31 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:54:31 --> Email Class Initialized
INFO - 2018-12-31 11:54:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:54:31 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:54:31 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:54:31 --> Helper loaded: date_helper
INFO - 2018-12-31 11:54:31 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:54:31 --> Helper loaded: form_helper
INFO - 2018-12-31 11:54:31 --> Form Validation Class Initialized
INFO - 2018-12-31 11:54:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:54:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:54:31 --> Final output sent to browser
DEBUG - 2018-12-31 11:54:31 --> Total execution time: 0.2756
INFO - 2018-12-31 11:54:56 --> Config Class Initialized
INFO - 2018-12-31 11:54:56 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:56 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:56 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:56 --> URI Class Initialized
INFO - 2018-12-31 11:54:56 --> Router Class Initialized
INFO - 2018-12-31 11:54:56 --> Output Class Initialized
INFO - 2018-12-31 11:54:56 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:56 --> CSRF cookie sent
INFO - 2018-12-31 11:54:56 --> CSRF token verified
INFO - 2018-12-31 11:54:56 --> Input Class Initialized
INFO - 2018-12-31 11:54:56 --> Language Class Initialized
INFO - 2018-12-31 11:54:56 --> Loader Class Initialized
INFO - 2018-12-31 11:54:56 --> Helper loaded: url_helper
INFO - 2018-12-31 11:54:56 --> Helper loaded: file_helper
INFO - 2018-12-31 11:54:56 --> Helper loaded: util_helper
INFO - 2018-12-31 11:54:56 --> Controller Class Initialized
INFO - 2018-12-31 11:54:56 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:54:56 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:54:56 --> Email Class Initialized
INFO - 2018-12-31 11:54:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:54:56 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:54:56 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:54:56 --> Helper loaded: date_helper
INFO - 2018-12-31 11:54:56 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:54:56 --> Helper loaded: form_helper
INFO - 2018-12-31 11:54:56 --> Form Validation Class Initialized
INFO - 2018-12-31 11:54:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:54:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 11:54:57 --> Config Class Initialized
INFO - 2018-12-31 11:54:57 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:57 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:57 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:57 --> URI Class Initialized
DEBUG - 2018-12-31 11:54:57 --> No URI present. Default controller set.
INFO - 2018-12-31 11:54:57 --> Router Class Initialized
INFO - 2018-12-31 11:54:57 --> Output Class Initialized
INFO - 2018-12-31 11:54:57 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:57 --> CSRF cookie sent
INFO - 2018-12-31 11:54:57 --> Input Class Initialized
INFO - 2018-12-31 11:54:57 --> Language Class Initialized
INFO - 2018-12-31 11:54:57 --> Loader Class Initialized
INFO - 2018-12-31 11:54:57 --> Helper loaded: url_helper
INFO - 2018-12-31 11:54:57 --> Helper loaded: file_helper
INFO - 2018-12-31 11:54:57 --> Helper loaded: util_helper
INFO - 2018-12-31 11:54:57 --> Controller Class Initialized
INFO - 2018-12-31 11:54:57 --> Database Driver Class Initialized
INFO - 2018-12-31 11:54:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 11:54:57 --> Final output sent to browser
DEBUG - 2018-12-31 11:54:57 --> Total execution time: 0.1667
INFO - 2018-12-31 11:54:57 --> Config Class Initialized
INFO - 2018-12-31 11:54:57 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:57 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:57 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:57 --> URI Class Initialized
INFO - 2018-12-31 11:54:57 --> Router Class Initialized
INFO - 2018-12-31 11:54:57 --> Output Class Initialized
INFO - 2018-12-31 11:54:57 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:57 --> CSRF cookie sent
INFO - 2018-12-31 11:54:57 --> Input Class Initialized
INFO - 2018-12-31 11:54:57 --> Language Class Initialized
ERROR - 2018-12-31 11:54:57 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:57 --> Config Class Initialized
INFO - 2018-12-31 11:54:57 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:57 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:57 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:57 --> URI Class Initialized
INFO - 2018-12-31 11:54:57 --> Router Class Initialized
INFO - 2018-12-31 11:54:57 --> Output Class Initialized
INFO - 2018-12-31 11:54:57 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:57 --> CSRF cookie sent
INFO - 2018-12-31 11:54:57 --> Input Class Initialized
INFO - 2018-12-31 11:54:57 --> Language Class Initialized
ERROR - 2018-12-31 11:54:57 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:57 --> Config Class Initialized
INFO - 2018-12-31 11:54:57 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:57 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:57 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:57 --> URI Class Initialized
INFO - 2018-12-31 11:54:57 --> Router Class Initialized
INFO - 2018-12-31 11:54:57 --> Output Class Initialized
INFO - 2018-12-31 11:54:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:58 --> CSRF cookie sent
INFO - 2018-12-31 11:54:58 --> Input Class Initialized
INFO - 2018-12-31 11:54:58 --> Language Class Initialized
ERROR - 2018-12-31 11:54:58 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:58 --> Config Class Initialized
INFO - 2018-12-31 11:54:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:58 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:58 --> URI Class Initialized
INFO - 2018-12-31 11:54:58 --> Router Class Initialized
INFO - 2018-12-31 11:54:58 --> Output Class Initialized
INFO - 2018-12-31 11:54:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:58 --> CSRF cookie sent
INFO - 2018-12-31 11:54:58 --> Input Class Initialized
INFO - 2018-12-31 11:54:58 --> Language Class Initialized
ERROR - 2018-12-31 11:54:58 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:58 --> Config Class Initialized
INFO - 2018-12-31 11:54:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:58 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:58 --> URI Class Initialized
INFO - 2018-12-31 11:54:58 --> Router Class Initialized
INFO - 2018-12-31 11:54:58 --> Output Class Initialized
INFO - 2018-12-31 11:54:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:58 --> CSRF cookie sent
INFO - 2018-12-31 11:54:58 --> Input Class Initialized
INFO - 2018-12-31 11:54:58 --> Language Class Initialized
ERROR - 2018-12-31 11:54:58 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:58 --> Config Class Initialized
INFO - 2018-12-31 11:54:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:58 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:58 --> URI Class Initialized
INFO - 2018-12-31 11:54:58 --> Router Class Initialized
INFO - 2018-12-31 11:54:58 --> Output Class Initialized
INFO - 2018-12-31 11:54:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:58 --> CSRF cookie sent
INFO - 2018-12-31 11:54:58 --> Input Class Initialized
INFO - 2018-12-31 11:54:58 --> Language Class Initialized
ERROR - 2018-12-31 11:54:58 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:58 --> Config Class Initialized
INFO - 2018-12-31 11:54:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:58 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:58 --> URI Class Initialized
INFO - 2018-12-31 11:54:58 --> Router Class Initialized
INFO - 2018-12-31 11:54:58 --> Output Class Initialized
INFO - 2018-12-31 11:54:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:58 --> CSRF cookie sent
INFO - 2018-12-31 11:54:58 --> Input Class Initialized
INFO - 2018-12-31 11:54:58 --> Language Class Initialized
ERROR - 2018-12-31 11:54:58 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:58 --> Config Class Initialized
INFO - 2018-12-31 11:54:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:58 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:58 --> URI Class Initialized
INFO - 2018-12-31 11:54:58 --> Router Class Initialized
INFO - 2018-12-31 11:54:58 --> Output Class Initialized
INFO - 2018-12-31 11:54:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:58 --> CSRF cookie sent
INFO - 2018-12-31 11:54:58 --> Input Class Initialized
INFO - 2018-12-31 11:54:58 --> Language Class Initialized
ERROR - 2018-12-31 11:54:58 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:58 --> Config Class Initialized
INFO - 2018-12-31 11:54:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:58 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:58 --> URI Class Initialized
INFO - 2018-12-31 11:54:58 --> Router Class Initialized
INFO - 2018-12-31 11:54:58 --> Output Class Initialized
INFO - 2018-12-31 11:54:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:58 --> CSRF cookie sent
INFO - 2018-12-31 11:54:58 --> Input Class Initialized
INFO - 2018-12-31 11:54:59 --> Language Class Initialized
ERROR - 2018-12-31 11:54:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:59 --> Config Class Initialized
INFO - 2018-12-31 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:59 --> URI Class Initialized
INFO - 2018-12-31 11:54:59 --> Router Class Initialized
INFO - 2018-12-31 11:54:59 --> Output Class Initialized
INFO - 2018-12-31 11:54:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:59 --> CSRF cookie sent
INFO - 2018-12-31 11:54:59 --> Input Class Initialized
INFO - 2018-12-31 11:54:59 --> Language Class Initialized
ERROR - 2018-12-31 11:54:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:59 --> Config Class Initialized
INFO - 2018-12-31 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:59 --> URI Class Initialized
INFO - 2018-12-31 11:54:59 --> Router Class Initialized
INFO - 2018-12-31 11:54:59 --> Output Class Initialized
INFO - 2018-12-31 11:54:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:59 --> CSRF cookie sent
INFO - 2018-12-31 11:54:59 --> Input Class Initialized
INFO - 2018-12-31 11:54:59 --> Language Class Initialized
ERROR - 2018-12-31 11:54:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:59 --> Config Class Initialized
INFO - 2018-12-31 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:59 --> URI Class Initialized
INFO - 2018-12-31 11:54:59 --> Router Class Initialized
INFO - 2018-12-31 11:54:59 --> Output Class Initialized
INFO - 2018-12-31 11:54:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:59 --> CSRF cookie sent
INFO - 2018-12-31 11:54:59 --> Input Class Initialized
INFO - 2018-12-31 11:54:59 --> Language Class Initialized
ERROR - 2018-12-31 11:54:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:59 --> Config Class Initialized
INFO - 2018-12-31 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:59 --> URI Class Initialized
INFO - 2018-12-31 11:54:59 --> Router Class Initialized
INFO - 2018-12-31 11:54:59 --> Output Class Initialized
INFO - 2018-12-31 11:54:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:59 --> CSRF cookie sent
INFO - 2018-12-31 11:54:59 --> Input Class Initialized
INFO - 2018-12-31 11:54:59 --> Language Class Initialized
ERROR - 2018-12-31 11:54:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:59 --> Config Class Initialized
INFO - 2018-12-31 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:59 --> URI Class Initialized
INFO - 2018-12-31 11:54:59 --> Router Class Initialized
INFO - 2018-12-31 11:54:59 --> Output Class Initialized
INFO - 2018-12-31 11:54:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:59 --> CSRF cookie sent
INFO - 2018-12-31 11:54:59 --> Input Class Initialized
INFO - 2018-12-31 11:54:59 --> Language Class Initialized
ERROR - 2018-12-31 11:54:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:59 --> Config Class Initialized
INFO - 2018-12-31 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:59 --> URI Class Initialized
INFO - 2018-12-31 11:54:59 --> Router Class Initialized
INFO - 2018-12-31 11:54:59 --> Output Class Initialized
INFO - 2018-12-31 11:54:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:54:59 --> CSRF cookie sent
INFO - 2018-12-31 11:54:59 --> Input Class Initialized
INFO - 2018-12-31 11:54:59 --> Language Class Initialized
ERROR - 2018-12-31 11:54:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:54:59 --> Config Class Initialized
INFO - 2018-12-31 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:54:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:54:59 --> URI Class Initialized
INFO - 2018-12-31 11:54:59 --> Router Class Initialized
INFO - 2018-12-31 11:54:59 --> Output Class Initialized
INFO - 2018-12-31 11:54:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:00 --> CSRF cookie sent
INFO - 2018-12-31 11:55:00 --> Input Class Initialized
INFO - 2018-12-31 11:55:00 --> Language Class Initialized
ERROR - 2018-12-31 11:55:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:55:00 --> Config Class Initialized
INFO - 2018-12-31 11:55:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:00 --> URI Class Initialized
INFO - 2018-12-31 11:55:00 --> Router Class Initialized
INFO - 2018-12-31 11:55:00 --> Output Class Initialized
INFO - 2018-12-31 11:55:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:00 --> CSRF cookie sent
INFO - 2018-12-31 11:55:00 --> Input Class Initialized
INFO - 2018-12-31 11:55:00 --> Language Class Initialized
ERROR - 2018-12-31 11:55:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:55:00 --> Config Class Initialized
INFO - 2018-12-31 11:55:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:00 --> URI Class Initialized
INFO - 2018-12-31 11:55:00 --> Router Class Initialized
INFO - 2018-12-31 11:55:00 --> Output Class Initialized
INFO - 2018-12-31 11:55:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:00 --> CSRF cookie sent
INFO - 2018-12-31 11:55:00 --> Input Class Initialized
INFO - 2018-12-31 11:55:00 --> Language Class Initialized
ERROR - 2018-12-31 11:55:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:55:00 --> Config Class Initialized
INFO - 2018-12-31 11:55:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:00 --> URI Class Initialized
INFO - 2018-12-31 11:55:00 --> Router Class Initialized
INFO - 2018-12-31 11:55:00 --> Output Class Initialized
INFO - 2018-12-31 11:55:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:00 --> CSRF cookie sent
INFO - 2018-12-31 11:55:00 --> Input Class Initialized
INFO - 2018-12-31 11:55:00 --> Language Class Initialized
ERROR - 2018-12-31 11:55:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:55:00 --> Config Class Initialized
INFO - 2018-12-31 11:55:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:00 --> URI Class Initialized
INFO - 2018-12-31 11:55:00 --> Router Class Initialized
INFO - 2018-12-31 11:55:00 --> Output Class Initialized
INFO - 2018-12-31 11:55:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:00 --> CSRF cookie sent
INFO - 2018-12-31 11:55:00 --> Input Class Initialized
INFO - 2018-12-31 11:55:00 --> Language Class Initialized
ERROR - 2018-12-31 11:55:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:55:00 --> Config Class Initialized
INFO - 2018-12-31 11:55:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:00 --> URI Class Initialized
INFO - 2018-12-31 11:55:00 --> Router Class Initialized
INFO - 2018-12-31 11:55:00 --> Output Class Initialized
INFO - 2018-12-31 11:55:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:00 --> CSRF cookie sent
INFO - 2018-12-31 11:55:00 --> Input Class Initialized
INFO - 2018-12-31 11:55:00 --> Language Class Initialized
ERROR - 2018-12-31 11:55:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:55:06 --> Config Class Initialized
INFO - 2018-12-31 11:55:06 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:06 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:06 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:06 --> URI Class Initialized
DEBUG - 2018-12-31 11:55:06 --> No URI present. Default controller set.
INFO - 2018-12-31 11:55:06 --> Router Class Initialized
INFO - 2018-12-31 11:55:06 --> Output Class Initialized
INFO - 2018-12-31 11:55:06 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:06 --> CSRF cookie sent
INFO - 2018-12-31 11:55:06 --> Input Class Initialized
INFO - 2018-12-31 11:55:06 --> Language Class Initialized
INFO - 2018-12-31 11:55:06 --> Loader Class Initialized
INFO - 2018-12-31 11:55:06 --> Helper loaded: url_helper
INFO - 2018-12-31 11:55:06 --> Helper loaded: file_helper
INFO - 2018-12-31 11:55:06 --> Helper loaded: util_helper
INFO - 2018-12-31 11:55:06 --> Controller Class Initialized
INFO - 2018-12-31 11:55:06 --> Database Driver Class Initialized
INFO - 2018-12-31 11:55:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 11:55:06 --> Final output sent to browser
DEBUG - 2018-12-31 11:55:06 --> Total execution time: 0.1952
INFO - 2018-12-31 11:55:22 --> Config Class Initialized
INFO - 2018-12-31 11:55:22 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:22 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:22 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:22 --> URI Class Initialized
DEBUG - 2018-12-31 11:55:22 --> No URI present. Default controller set.
INFO - 2018-12-31 11:55:22 --> Router Class Initialized
INFO - 2018-12-31 11:55:22 --> Output Class Initialized
INFO - 2018-12-31 11:55:22 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:22 --> CSRF cookie sent
INFO - 2018-12-31 11:55:22 --> Input Class Initialized
INFO - 2018-12-31 11:55:22 --> Language Class Initialized
INFO - 2018-12-31 11:55:22 --> Loader Class Initialized
INFO - 2018-12-31 11:55:22 --> Helper loaded: url_helper
INFO - 2018-12-31 11:55:22 --> Helper loaded: file_helper
INFO - 2018-12-31 11:55:22 --> Helper loaded: util_helper
INFO - 2018-12-31 11:55:22 --> Controller Class Initialized
INFO - 2018-12-31 11:55:22 --> Database Driver Class Initialized
INFO - 2018-12-31 11:55:22 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 11:55:22 --> Final output sent to browser
DEBUG - 2018-12-31 11:55:22 --> Total execution time: 0.2033
INFO - 2018-12-31 11:55:27 --> Config Class Initialized
INFO - 2018-12-31 11:55:27 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:27 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:27 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:27 --> URI Class Initialized
INFO - 2018-12-31 11:55:27 --> Router Class Initialized
INFO - 2018-12-31 11:55:27 --> Output Class Initialized
INFO - 2018-12-31 11:55:27 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:27 --> CSRF cookie sent
INFO - 2018-12-31 11:55:27 --> Input Class Initialized
INFO - 2018-12-31 11:55:27 --> Language Class Initialized
INFO - 2018-12-31 11:55:27 --> Loader Class Initialized
INFO - 2018-12-31 11:55:27 --> Helper loaded: url_helper
INFO - 2018-12-31 11:55:27 --> Helper loaded: file_helper
INFO - 2018-12-31 11:55:27 --> Helper loaded: util_helper
INFO - 2018-12-31 11:55:27 --> Controller Class Initialized
INFO - 2018-12-31 11:55:27 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:55:27 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:55:27 --> Email Class Initialized
INFO - 2018-12-31 11:55:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:55:27 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:55:27 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:55:27 --> Helper loaded: date_helper
INFO - 2018-12-31 11:55:27 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:55:27 --> Helper loaded: form_helper
INFO - 2018-12-31 11:55:27 --> Form Validation Class Initialized
INFO - 2018-12-31 11:55:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:55:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:55:27 --> Final output sent to browser
DEBUG - 2018-12-31 11:55:27 --> Total execution time: 0.3030
INFO - 2018-12-31 11:55:28 --> Config Class Initialized
INFO - 2018-12-31 11:55:28 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:28 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:28 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:28 --> URI Class Initialized
INFO - 2018-12-31 11:55:28 --> Router Class Initialized
INFO - 2018-12-31 11:55:28 --> Output Class Initialized
INFO - 2018-12-31 11:55:28 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:28 --> CSRF cookie sent
INFO - 2018-12-31 11:55:28 --> Input Class Initialized
INFO - 2018-12-31 11:55:28 --> Language Class Initialized
INFO - 2018-12-31 11:55:28 --> Loader Class Initialized
INFO - 2018-12-31 11:55:28 --> Helper loaded: url_helper
INFO - 2018-12-31 11:55:28 --> Helper loaded: file_helper
INFO - 2018-12-31 11:55:28 --> Helper loaded: util_helper
INFO - 2018-12-31 11:55:28 --> Controller Class Initialized
INFO - 2018-12-31 11:55:28 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:55:28 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:55:28 --> Email Class Initialized
INFO - 2018-12-31 11:55:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:55:28 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:55:28 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:55:28 --> Helper loaded: date_helper
INFO - 2018-12-31 11:55:28 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:55:28 --> Helper loaded: form_helper
INFO - 2018-12-31 11:55:28 --> Form Validation Class Initialized
INFO - 2018-12-31 11:55:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:55:33 --> Config Class Initialized
INFO - 2018-12-31 11:55:33 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:33 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:33 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:33 --> URI Class Initialized
INFO - 2018-12-31 11:55:33 --> Router Class Initialized
INFO - 2018-12-31 11:55:33 --> Output Class Initialized
INFO - 2018-12-31 11:55:33 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:33 --> CSRF cookie sent
INFO - 2018-12-31 11:55:33 --> Input Class Initialized
INFO - 2018-12-31 11:55:33 --> Language Class Initialized
INFO - 2018-12-31 11:55:33 --> Loader Class Initialized
INFO - 2018-12-31 11:55:33 --> Helper loaded: url_helper
INFO - 2018-12-31 11:55:33 --> Helper loaded: file_helper
INFO - 2018-12-31 11:55:33 --> Helper loaded: util_helper
INFO - 2018-12-31 11:55:33 --> Controller Class Initialized
INFO - 2018-12-31 11:55:33 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:55:33 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:55:33 --> Email Class Initialized
INFO - 2018-12-31 11:55:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:55:33 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:55:33 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:55:33 --> Helper loaded: date_helper
INFO - 2018-12-31 11:55:33 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:55:33 --> Helper loaded: form_helper
INFO - 2018-12-31 11:55:33 --> Form Validation Class Initialized
INFO - 2018-12-31 11:55:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:55:33 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:55:33 --> Final output sent to browser
DEBUG - 2018-12-31 11:55:33 --> Total execution time: 0.2768
INFO - 2018-12-31 11:55:58 --> Config Class Initialized
INFO - 2018-12-31 11:55:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:58 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:58 --> URI Class Initialized
INFO - 2018-12-31 11:55:58 --> Router Class Initialized
INFO - 2018-12-31 11:55:58 --> Output Class Initialized
INFO - 2018-12-31 11:55:58 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:58 --> CSRF cookie sent
INFO - 2018-12-31 11:55:58 --> CSRF token verified
INFO - 2018-12-31 11:55:58 --> Input Class Initialized
INFO - 2018-12-31 11:55:58 --> Language Class Initialized
INFO - 2018-12-31 11:55:58 --> Loader Class Initialized
INFO - 2018-12-31 11:55:58 --> Helper loaded: url_helper
INFO - 2018-12-31 11:55:58 --> Helper loaded: file_helper
INFO - 2018-12-31 11:55:58 --> Helper loaded: util_helper
INFO - 2018-12-31 11:55:58 --> Controller Class Initialized
INFO - 2018-12-31 11:55:58 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:55:58 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:55:58 --> Email Class Initialized
INFO - 2018-12-31 11:55:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:55:58 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:55:58 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:55:58 --> Helper loaded: date_helper
INFO - 2018-12-31 11:55:58 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:55:58 --> Helper loaded: form_helper
INFO - 2018-12-31 11:55:58 --> Form Validation Class Initialized
INFO - 2018-12-31 11:55:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:55:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 11:55:59 --> Config Class Initialized
INFO - 2018-12-31 11:55:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:59 --> URI Class Initialized
DEBUG - 2018-12-31 11:55:59 --> No URI present. Default controller set.
INFO - 2018-12-31 11:55:59 --> Router Class Initialized
INFO - 2018-12-31 11:55:59 --> Output Class Initialized
INFO - 2018-12-31 11:55:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:59 --> CSRF cookie sent
INFO - 2018-12-31 11:55:59 --> Input Class Initialized
INFO - 2018-12-31 11:55:59 --> Language Class Initialized
INFO - 2018-12-31 11:55:59 --> Loader Class Initialized
INFO - 2018-12-31 11:55:59 --> Helper loaded: url_helper
INFO - 2018-12-31 11:55:59 --> Helper loaded: file_helper
INFO - 2018-12-31 11:55:59 --> Helper loaded: util_helper
INFO - 2018-12-31 11:55:59 --> Controller Class Initialized
INFO - 2018-12-31 11:55:59 --> Database Driver Class Initialized
INFO - 2018-12-31 11:55:59 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 11:55:59 --> Final output sent to browser
DEBUG - 2018-12-31 11:55:59 --> Total execution time: 0.1702
INFO - 2018-12-31 11:55:59 --> Config Class Initialized
INFO - 2018-12-31 11:55:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:59 --> URI Class Initialized
INFO - 2018-12-31 11:55:59 --> Router Class Initialized
INFO - 2018-12-31 11:55:59 --> Output Class Initialized
INFO - 2018-12-31 11:55:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:59 --> CSRF cookie sent
INFO - 2018-12-31 11:55:59 --> Input Class Initialized
INFO - 2018-12-31 11:55:59 --> Language Class Initialized
ERROR - 2018-12-31 11:55:59 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:55:59 --> Config Class Initialized
INFO - 2018-12-31 11:55:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:55:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:55:59 --> Utf8 Class Initialized
INFO - 2018-12-31 11:55:59 --> URI Class Initialized
INFO - 2018-12-31 11:55:59 --> Router Class Initialized
INFO - 2018-12-31 11:55:59 --> Output Class Initialized
INFO - 2018-12-31 11:55:59 --> Security Class Initialized
DEBUG - 2018-12-31 11:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:55:59 --> CSRF cookie sent
INFO - 2018-12-31 11:55:59 --> Input Class Initialized
INFO - 2018-12-31 11:56:00 --> Language Class Initialized
ERROR - 2018-12-31 11:56:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:00 --> Config Class Initialized
INFO - 2018-12-31 11:56:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:00 --> URI Class Initialized
INFO - 2018-12-31 11:56:00 --> Router Class Initialized
INFO - 2018-12-31 11:56:00 --> Output Class Initialized
INFO - 2018-12-31 11:56:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:00 --> CSRF cookie sent
INFO - 2018-12-31 11:56:00 --> Input Class Initialized
INFO - 2018-12-31 11:56:00 --> Language Class Initialized
ERROR - 2018-12-31 11:56:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:00 --> Config Class Initialized
INFO - 2018-12-31 11:56:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:00 --> URI Class Initialized
INFO - 2018-12-31 11:56:00 --> Router Class Initialized
INFO - 2018-12-31 11:56:00 --> Output Class Initialized
INFO - 2018-12-31 11:56:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:00 --> CSRF cookie sent
INFO - 2018-12-31 11:56:00 --> Input Class Initialized
INFO - 2018-12-31 11:56:00 --> Language Class Initialized
ERROR - 2018-12-31 11:56:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:00 --> Config Class Initialized
INFO - 2018-12-31 11:56:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:00 --> URI Class Initialized
INFO - 2018-12-31 11:56:00 --> Router Class Initialized
INFO - 2018-12-31 11:56:00 --> Output Class Initialized
INFO - 2018-12-31 11:56:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:00 --> CSRF cookie sent
INFO - 2018-12-31 11:56:00 --> Input Class Initialized
INFO - 2018-12-31 11:56:00 --> Language Class Initialized
ERROR - 2018-12-31 11:56:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:00 --> Config Class Initialized
INFO - 2018-12-31 11:56:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:00 --> URI Class Initialized
INFO - 2018-12-31 11:56:00 --> Router Class Initialized
INFO - 2018-12-31 11:56:00 --> Output Class Initialized
INFO - 2018-12-31 11:56:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:00 --> CSRF cookie sent
INFO - 2018-12-31 11:56:00 --> Input Class Initialized
INFO - 2018-12-31 11:56:00 --> Language Class Initialized
ERROR - 2018-12-31 11:56:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:00 --> Config Class Initialized
INFO - 2018-12-31 11:56:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:00 --> URI Class Initialized
INFO - 2018-12-31 11:56:00 --> Router Class Initialized
INFO - 2018-12-31 11:56:00 --> Output Class Initialized
INFO - 2018-12-31 11:56:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:00 --> CSRF cookie sent
INFO - 2018-12-31 11:56:00 --> Input Class Initialized
INFO - 2018-12-31 11:56:00 --> Language Class Initialized
ERROR - 2018-12-31 11:56:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:00 --> Config Class Initialized
INFO - 2018-12-31 11:56:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:00 --> URI Class Initialized
INFO - 2018-12-31 11:56:00 --> Router Class Initialized
INFO - 2018-12-31 11:56:00 --> Output Class Initialized
INFO - 2018-12-31 11:56:00 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:00 --> CSRF cookie sent
INFO - 2018-12-31 11:56:00 --> Input Class Initialized
INFO - 2018-12-31 11:56:00 --> Language Class Initialized
ERROR - 2018-12-31 11:56:00 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:00 --> Config Class Initialized
INFO - 2018-12-31 11:56:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:00 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:00 --> URI Class Initialized
INFO - 2018-12-31 11:56:01 --> Router Class Initialized
INFO - 2018-12-31 11:56:01 --> Output Class Initialized
INFO - 2018-12-31 11:56:01 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:01 --> CSRF cookie sent
INFO - 2018-12-31 11:56:01 --> Input Class Initialized
INFO - 2018-12-31 11:56:01 --> Language Class Initialized
ERROR - 2018-12-31 11:56:01 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:01 --> Config Class Initialized
INFO - 2018-12-31 11:56:01 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:01 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:01 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:01 --> URI Class Initialized
INFO - 2018-12-31 11:56:01 --> Router Class Initialized
INFO - 2018-12-31 11:56:01 --> Output Class Initialized
INFO - 2018-12-31 11:56:01 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:01 --> CSRF cookie sent
INFO - 2018-12-31 11:56:01 --> Input Class Initialized
INFO - 2018-12-31 11:56:01 --> Language Class Initialized
ERROR - 2018-12-31 11:56:01 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:01 --> Config Class Initialized
INFO - 2018-12-31 11:56:01 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:01 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:01 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:01 --> URI Class Initialized
INFO - 2018-12-31 11:56:01 --> Router Class Initialized
INFO - 2018-12-31 11:56:01 --> Output Class Initialized
INFO - 2018-12-31 11:56:01 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:01 --> CSRF cookie sent
INFO - 2018-12-31 11:56:01 --> Input Class Initialized
INFO - 2018-12-31 11:56:01 --> Language Class Initialized
ERROR - 2018-12-31 11:56:01 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:01 --> Config Class Initialized
INFO - 2018-12-31 11:56:01 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:01 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:01 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:01 --> URI Class Initialized
INFO - 2018-12-31 11:56:01 --> Router Class Initialized
INFO - 2018-12-31 11:56:01 --> Output Class Initialized
INFO - 2018-12-31 11:56:01 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:01 --> CSRF cookie sent
INFO - 2018-12-31 11:56:01 --> Input Class Initialized
INFO - 2018-12-31 11:56:01 --> Language Class Initialized
ERROR - 2018-12-31 11:56:01 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:01 --> Config Class Initialized
INFO - 2018-12-31 11:56:01 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:01 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:01 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:01 --> URI Class Initialized
INFO - 2018-12-31 11:56:01 --> Router Class Initialized
INFO - 2018-12-31 11:56:01 --> Output Class Initialized
INFO - 2018-12-31 11:56:01 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:01 --> CSRF cookie sent
INFO - 2018-12-31 11:56:01 --> Input Class Initialized
INFO - 2018-12-31 11:56:01 --> Language Class Initialized
ERROR - 2018-12-31 11:56:01 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:01 --> Config Class Initialized
INFO - 2018-12-31 11:56:01 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:01 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:01 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:01 --> URI Class Initialized
INFO - 2018-12-31 11:56:01 --> Router Class Initialized
INFO - 2018-12-31 11:56:01 --> Output Class Initialized
INFO - 2018-12-31 11:56:01 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:01 --> CSRF cookie sent
INFO - 2018-12-31 11:56:01 --> Input Class Initialized
INFO - 2018-12-31 11:56:01 --> Language Class Initialized
ERROR - 2018-12-31 11:56:01 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:01 --> Config Class Initialized
INFO - 2018-12-31 11:56:01 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:01 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:01 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:01 --> URI Class Initialized
INFO - 2018-12-31 11:56:01 --> Router Class Initialized
INFO - 2018-12-31 11:56:01 --> Output Class Initialized
INFO - 2018-12-31 11:56:01 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:01 --> CSRF cookie sent
INFO - 2018-12-31 11:56:01 --> Input Class Initialized
INFO - 2018-12-31 11:56:01 --> Language Class Initialized
ERROR - 2018-12-31 11:56:02 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:02 --> Config Class Initialized
INFO - 2018-12-31 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:02 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:02 --> URI Class Initialized
INFO - 2018-12-31 11:56:02 --> Router Class Initialized
INFO - 2018-12-31 11:56:02 --> Output Class Initialized
INFO - 2018-12-31 11:56:02 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:02 --> CSRF cookie sent
INFO - 2018-12-31 11:56:02 --> Input Class Initialized
INFO - 2018-12-31 11:56:02 --> Language Class Initialized
ERROR - 2018-12-31 11:56:02 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:02 --> Config Class Initialized
INFO - 2018-12-31 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:02 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:02 --> URI Class Initialized
INFO - 2018-12-31 11:56:02 --> Router Class Initialized
INFO - 2018-12-31 11:56:02 --> Output Class Initialized
INFO - 2018-12-31 11:56:02 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:02 --> CSRF cookie sent
INFO - 2018-12-31 11:56:02 --> Input Class Initialized
INFO - 2018-12-31 11:56:02 --> Language Class Initialized
ERROR - 2018-12-31 11:56:02 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:02 --> Config Class Initialized
INFO - 2018-12-31 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:02 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:02 --> URI Class Initialized
INFO - 2018-12-31 11:56:02 --> Router Class Initialized
INFO - 2018-12-31 11:56:02 --> Output Class Initialized
INFO - 2018-12-31 11:56:02 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:02 --> CSRF cookie sent
INFO - 2018-12-31 11:56:02 --> Input Class Initialized
INFO - 2018-12-31 11:56:02 --> Language Class Initialized
ERROR - 2018-12-31 11:56:02 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:02 --> Config Class Initialized
INFO - 2018-12-31 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:02 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:02 --> URI Class Initialized
INFO - 2018-12-31 11:56:02 --> Router Class Initialized
INFO - 2018-12-31 11:56:02 --> Output Class Initialized
INFO - 2018-12-31 11:56:02 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:02 --> CSRF cookie sent
INFO - 2018-12-31 11:56:02 --> Input Class Initialized
INFO - 2018-12-31 11:56:02 --> Language Class Initialized
ERROR - 2018-12-31 11:56:02 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:56:02 --> Config Class Initialized
INFO - 2018-12-31 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:56:02 --> Utf8 Class Initialized
INFO - 2018-12-31 11:56:02 --> URI Class Initialized
INFO - 2018-12-31 11:56:02 --> Router Class Initialized
INFO - 2018-12-31 11:56:02 --> Output Class Initialized
INFO - 2018-12-31 11:56:02 --> Security Class Initialized
DEBUG - 2018-12-31 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:56:02 --> CSRF cookie sent
INFO - 2018-12-31 11:56:02 --> Input Class Initialized
INFO - 2018-12-31 11:56:02 --> Language Class Initialized
ERROR - 2018-12-31 11:56:02 --> 404 Page Not Found: Static/themes
INFO - 2018-12-31 11:57:43 --> Config Class Initialized
INFO - 2018-12-31 11:57:43 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:57:43 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:57:43 --> Utf8 Class Initialized
INFO - 2018-12-31 11:57:43 --> URI Class Initialized
INFO - 2018-12-31 11:57:43 --> Router Class Initialized
INFO - 2018-12-31 11:57:43 --> Output Class Initialized
INFO - 2018-12-31 11:57:43 --> Security Class Initialized
DEBUG - 2018-12-31 11:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:57:43 --> CSRF cookie sent
INFO - 2018-12-31 11:57:43 --> Input Class Initialized
INFO - 2018-12-31 11:57:43 --> Language Class Initialized
INFO - 2018-12-31 11:57:43 --> Loader Class Initialized
INFO - 2018-12-31 11:57:43 --> Helper loaded: url_helper
INFO - 2018-12-31 11:57:43 --> Helper loaded: file_helper
INFO - 2018-12-31 11:57:43 --> Helper loaded: util_helper
INFO - 2018-12-31 11:57:43 --> Controller Class Initialized
INFO - 2018-12-31 11:57:43 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:57:43 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:57:43 --> Email Class Initialized
INFO - 2018-12-31 11:57:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:57:43 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:57:43 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:57:43 --> Helper loaded: date_helper
INFO - 2018-12-31 11:57:43 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:57:43 --> Helper loaded: form_helper
INFO - 2018-12-31 11:57:43 --> Form Validation Class Initialized
INFO - 2018-12-31 11:57:43 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:57:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:57:43 --> Final output sent to browser
DEBUG - 2018-12-31 11:57:43 --> Total execution time: 0.2697
INFO - 2018-12-31 11:57:44 --> Config Class Initialized
INFO - 2018-12-31 11:57:44 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:57:44 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:57:44 --> Utf8 Class Initialized
INFO - 2018-12-31 11:57:44 --> URI Class Initialized
INFO - 2018-12-31 11:57:44 --> Router Class Initialized
INFO - 2018-12-31 11:57:44 --> Output Class Initialized
INFO - 2018-12-31 11:57:44 --> Security Class Initialized
DEBUG - 2018-12-31 11:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:57:44 --> CSRF cookie sent
INFO - 2018-12-31 11:57:44 --> Input Class Initialized
INFO - 2018-12-31 11:57:44 --> Language Class Initialized
INFO - 2018-12-31 11:57:44 --> Loader Class Initialized
INFO - 2018-12-31 11:57:44 --> Helper loaded: url_helper
INFO - 2018-12-31 11:57:44 --> Helper loaded: file_helper
INFO - 2018-12-31 11:57:44 --> Helper loaded: util_helper
INFO - 2018-12-31 11:57:44 --> Controller Class Initialized
INFO - 2018-12-31 11:57:44 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:57:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:57:44 --> Email Class Initialized
INFO - 2018-12-31 11:57:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:57:44 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:57:44 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:57:44 --> Helper loaded: date_helper
INFO - 2018-12-31 11:57:44 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:57:44 --> Helper loaded: form_helper
INFO - 2018-12-31 11:57:44 --> Form Validation Class Initialized
INFO - 2018-12-31 11:57:44 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:57:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:57:44 --> Final output sent to browser
DEBUG - 2018-12-31 11:57:44 --> Total execution time: 0.2839
INFO - 2018-12-31 11:57:50 --> Config Class Initialized
INFO - 2018-12-31 11:57:50 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:57:50 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:57:50 --> Utf8 Class Initialized
INFO - 2018-12-31 11:57:50 --> URI Class Initialized
INFO - 2018-12-31 11:57:50 --> Router Class Initialized
INFO - 2018-12-31 11:57:50 --> Output Class Initialized
INFO - 2018-12-31 11:57:50 --> Security Class Initialized
DEBUG - 2018-12-31 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:57:50 --> CSRF cookie sent
INFO - 2018-12-31 11:57:50 --> Input Class Initialized
INFO - 2018-12-31 11:57:50 --> Language Class Initialized
INFO - 2018-12-31 11:57:50 --> Loader Class Initialized
INFO - 2018-12-31 11:57:50 --> Helper loaded: url_helper
INFO - 2018-12-31 11:57:50 --> Helper loaded: file_helper
INFO - 2018-12-31 11:57:50 --> Helper loaded: util_helper
INFO - 2018-12-31 11:57:50 --> Controller Class Initialized
INFO - 2018-12-31 11:57:50 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:57:50 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:57:50 --> Email Class Initialized
INFO - 2018-12-31 11:57:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:57:50 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:57:50 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:57:50 --> Helper loaded: date_helper
INFO - 2018-12-31 11:57:50 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:57:50 --> Helper loaded: form_helper
INFO - 2018-12-31 11:57:50 --> Form Validation Class Initialized
INFO - 2018-12-31 11:57:50 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:57:51 --> Config Class Initialized
INFO - 2018-12-31 11:57:51 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:57:51 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:57:51 --> Utf8 Class Initialized
INFO - 2018-12-31 11:57:51 --> URI Class Initialized
INFO - 2018-12-31 11:57:51 --> Router Class Initialized
INFO - 2018-12-31 11:57:51 --> Output Class Initialized
INFO - 2018-12-31 11:57:51 --> Security Class Initialized
DEBUG - 2018-12-31 11:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:57:51 --> CSRF cookie sent
INFO - 2018-12-31 11:57:51 --> Input Class Initialized
INFO - 2018-12-31 11:57:51 --> Language Class Initialized
INFO - 2018-12-31 11:57:51 --> Loader Class Initialized
INFO - 2018-12-31 11:57:51 --> Helper loaded: url_helper
INFO - 2018-12-31 11:57:51 --> Helper loaded: file_helper
INFO - 2018-12-31 11:57:51 --> Helper loaded: util_helper
INFO - 2018-12-31 11:57:51 --> Controller Class Initialized
INFO - 2018-12-31 11:57:51 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:57:51 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:57:51 --> Email Class Initialized
INFO - 2018-12-31 11:57:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:57:51 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:57:51 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:57:51 --> Helper loaded: date_helper
INFO - 2018-12-31 11:57:51 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:57:51 --> Helper loaded: form_helper
INFO - 2018-12-31 11:57:51 --> Form Validation Class Initialized
INFO - 2018-12-31 11:57:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:57:51 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:57:51 --> Final output sent to browser
DEBUG - 2018-12-31 11:57:51 --> Total execution time: 0.2762
INFO - 2018-12-31 11:58:40 --> Config Class Initialized
INFO - 2018-12-31 11:58:40 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:58:40 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:58:40 --> Utf8 Class Initialized
INFO - 2018-12-31 11:58:40 --> URI Class Initialized
INFO - 2018-12-31 11:58:40 --> Router Class Initialized
INFO - 2018-12-31 11:58:40 --> Output Class Initialized
INFO - 2018-12-31 11:58:40 --> Security Class Initialized
DEBUG - 2018-12-31 11:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:58:40 --> CSRF cookie sent
INFO - 2018-12-31 11:58:40 --> Input Class Initialized
INFO - 2018-12-31 11:58:40 --> Language Class Initialized
INFO - 2018-12-31 11:58:40 --> Loader Class Initialized
INFO - 2018-12-31 11:58:40 --> Helper loaded: url_helper
INFO - 2018-12-31 11:58:40 --> Helper loaded: file_helper
INFO - 2018-12-31 11:58:40 --> Helper loaded: util_helper
INFO - 2018-12-31 11:58:40 --> Controller Class Initialized
INFO - 2018-12-31 11:58:40 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:58:40 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:58:40 --> Email Class Initialized
INFO - 2018-12-31 11:58:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:58:40 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:58:40 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:58:40 --> Helper loaded: date_helper
INFO - 2018-12-31 11:58:40 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:58:40 --> Helper loaded: form_helper
INFO - 2018-12-31 11:58:40 --> Form Validation Class Initialized
INFO - 2018-12-31 11:58:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:58:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:58:40 --> Final output sent to browser
DEBUG - 2018-12-31 11:58:40 --> Total execution time: 0.2735
INFO - 2018-12-31 11:58:42 --> Config Class Initialized
INFO - 2018-12-31 11:58:42 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:58:42 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:58:42 --> Utf8 Class Initialized
INFO - 2018-12-31 11:58:42 --> URI Class Initialized
INFO - 2018-12-31 11:58:42 --> Router Class Initialized
INFO - 2018-12-31 11:58:42 --> Output Class Initialized
INFO - 2018-12-31 11:58:42 --> Security Class Initialized
DEBUG - 2018-12-31 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:58:42 --> CSRF cookie sent
INFO - 2018-12-31 11:58:42 --> Input Class Initialized
INFO - 2018-12-31 11:58:42 --> Language Class Initialized
INFO - 2018-12-31 11:58:42 --> Loader Class Initialized
INFO - 2018-12-31 11:58:42 --> Helper loaded: url_helper
INFO - 2018-12-31 11:58:42 --> Helper loaded: file_helper
INFO - 2018-12-31 11:58:42 --> Helper loaded: util_helper
INFO - 2018-12-31 11:58:42 --> Controller Class Initialized
INFO - 2018-12-31 11:58:42 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:58:42 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:58:42 --> Email Class Initialized
INFO - 2018-12-31 11:58:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:58:42 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:58:42 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:58:42 --> Helper loaded: date_helper
INFO - 2018-12-31 11:58:42 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:58:42 --> Helper loaded: form_helper
INFO - 2018-12-31 11:58:42 --> Form Validation Class Initialized
INFO - 2018-12-31 11:58:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:58:43 --> Config Class Initialized
INFO - 2018-12-31 11:58:43 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:58:43 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:58:43 --> Utf8 Class Initialized
INFO - 2018-12-31 11:58:43 --> URI Class Initialized
INFO - 2018-12-31 11:58:43 --> Router Class Initialized
INFO - 2018-12-31 11:58:43 --> Output Class Initialized
INFO - 2018-12-31 11:58:43 --> Security Class Initialized
DEBUG - 2018-12-31 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:58:43 --> CSRF cookie sent
INFO - 2018-12-31 11:58:43 --> Input Class Initialized
INFO - 2018-12-31 11:58:43 --> Language Class Initialized
INFO - 2018-12-31 11:58:43 --> Loader Class Initialized
INFO - 2018-12-31 11:58:43 --> Helper loaded: url_helper
INFO - 2018-12-31 11:58:43 --> Helper loaded: file_helper
INFO - 2018-12-31 11:58:43 --> Helper loaded: util_helper
INFO - 2018-12-31 11:58:43 --> Controller Class Initialized
INFO - 2018-12-31 11:58:43 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:58:43 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:58:43 --> Email Class Initialized
INFO - 2018-12-31 11:58:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:58:43 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:58:43 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:58:43 --> Helper loaded: date_helper
INFO - 2018-12-31 11:58:43 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:58:43 --> Helper loaded: form_helper
INFO - 2018-12-31 11:58:43 --> Form Validation Class Initialized
INFO - 2018-12-31 11:58:43 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:58:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:58:43 --> Final output sent to browser
DEBUG - 2018-12-31 11:58:43 --> Total execution time: 0.3559
INFO - 2018-12-31 11:58:54 --> Config Class Initialized
INFO - 2018-12-31 11:58:54 --> Hooks Class Initialized
DEBUG - 2018-12-31 11:58:54 --> UTF-8 Support Enabled
INFO - 2018-12-31 11:58:54 --> Utf8 Class Initialized
INFO - 2018-12-31 11:58:54 --> URI Class Initialized
INFO - 2018-12-31 11:58:54 --> Router Class Initialized
INFO - 2018-12-31 11:58:54 --> Output Class Initialized
INFO - 2018-12-31 11:58:54 --> Security Class Initialized
DEBUG - 2018-12-31 11:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 11:58:54 --> CSRF cookie sent
INFO - 2018-12-31 11:58:54 --> Input Class Initialized
INFO - 2018-12-31 11:58:54 --> Language Class Initialized
INFO - 2018-12-31 11:58:54 --> Loader Class Initialized
INFO - 2018-12-31 11:58:54 --> Helper loaded: url_helper
INFO - 2018-12-31 11:58:54 --> Helper loaded: file_helper
INFO - 2018-12-31 11:58:54 --> Helper loaded: util_helper
INFO - 2018-12-31 11:58:54 --> Controller Class Initialized
INFO - 2018-12-31 11:58:54 --> Database Driver Class Initialized
DEBUG - 2018-12-31 11:58:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 11:58:54 --> Email Class Initialized
INFO - 2018-12-31 11:58:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 11:58:54 --> Helper loaded: cookie_helper
INFO - 2018-12-31 11:58:54 --> Helper loaded: language_helper
DEBUG - 2018-12-31 11:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 11:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 11:58:54 --> Helper loaded: date_helper
INFO - 2018-12-31 11:58:54 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 11:58:54 --> Helper loaded: form_helper
INFO - 2018-12-31 11:58:54 --> Form Validation Class Initialized
INFO - 2018-12-31 11:58:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 11:58:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 11:58:54 --> Final output sent to browser
DEBUG - 2018-12-31 11:58:54 --> Total execution time: 0.2853
INFO - 2018-12-31 12:00:15 --> Config Class Initialized
INFO - 2018-12-31 12:00:15 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:00:15 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:00:15 --> Utf8 Class Initialized
INFO - 2018-12-31 12:00:15 --> URI Class Initialized
INFO - 2018-12-31 12:00:15 --> Router Class Initialized
INFO - 2018-12-31 12:00:15 --> Output Class Initialized
INFO - 2018-12-31 12:00:15 --> Security Class Initialized
DEBUG - 2018-12-31 12:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:00:15 --> CSRF cookie sent
INFO - 2018-12-31 12:00:15 --> CSRF token verified
INFO - 2018-12-31 12:00:15 --> Input Class Initialized
INFO - 2018-12-31 12:00:15 --> Language Class Initialized
INFO - 2018-12-31 12:00:15 --> Loader Class Initialized
INFO - 2018-12-31 12:00:15 --> Helper loaded: url_helper
INFO - 2018-12-31 12:00:15 --> Helper loaded: file_helper
INFO - 2018-12-31 12:00:15 --> Helper loaded: util_helper
INFO - 2018-12-31 12:00:15 --> Controller Class Initialized
INFO - 2018-12-31 12:00:15 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:00:15 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:00:15 --> Email Class Initialized
INFO - 2018-12-31 12:00:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:00:15 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:00:15 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:00:15 --> Helper loaded: date_helper
INFO - 2018-12-31 12:00:15 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:00:15 --> Helper loaded: form_helper
INFO - 2018-12-31 12:00:15 --> Form Validation Class Initialized
INFO - 2018-12-31 12:00:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 12:00:16 --> Config Class Initialized
INFO - 2018-12-31 12:00:16 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:00:16 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:00:16 --> Utf8 Class Initialized
INFO - 2018-12-31 12:00:16 --> URI Class Initialized
DEBUG - 2018-12-31 12:00:16 --> No URI present. Default controller set.
INFO - 2018-12-31 12:00:16 --> Router Class Initialized
INFO - 2018-12-31 12:00:16 --> Output Class Initialized
INFO - 2018-12-31 12:00:16 --> Security Class Initialized
DEBUG - 2018-12-31 12:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:00:16 --> CSRF cookie sent
INFO - 2018-12-31 12:00:16 --> Input Class Initialized
INFO - 2018-12-31 12:00:16 --> Language Class Initialized
INFO - 2018-12-31 12:00:16 --> Loader Class Initialized
INFO - 2018-12-31 12:00:16 --> Helper loaded: url_helper
INFO - 2018-12-31 12:00:16 --> Helper loaded: file_helper
INFO - 2018-12-31 12:00:16 --> Helper loaded: util_helper
INFO - 2018-12-31 12:00:16 --> Controller Class Initialized
INFO - 2018-12-31 12:00:16 --> Database Driver Class Initialized
INFO - 2018-12-31 12:00:16 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:00:16 --> Final output sent to browser
DEBUG - 2018-12-31 12:00:16 --> Total execution time: 0.2167
INFO - 2018-12-31 12:00:18 --> Config Class Initialized
INFO - 2018-12-31 12:00:18 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:00:18 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:00:18 --> Utf8 Class Initialized
INFO - 2018-12-31 12:00:18 --> URI Class Initialized
INFO - 2018-12-31 12:00:18 --> Router Class Initialized
INFO - 2018-12-31 12:00:18 --> Output Class Initialized
INFO - 2018-12-31 12:00:18 --> Security Class Initialized
DEBUG - 2018-12-31 12:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:00:18 --> CSRF cookie sent
INFO - 2018-12-31 12:00:18 --> Input Class Initialized
INFO - 2018-12-31 12:00:18 --> Language Class Initialized
INFO - 2018-12-31 12:00:18 --> Loader Class Initialized
INFO - 2018-12-31 12:00:18 --> Helper loaded: url_helper
INFO - 2018-12-31 12:00:18 --> Helper loaded: file_helper
INFO - 2018-12-31 12:00:18 --> Helper loaded: util_helper
INFO - 2018-12-31 12:00:18 --> Controller Class Initialized
INFO - 2018-12-31 12:00:18 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:00:18 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:00:18 --> Email Class Initialized
INFO - 2018-12-31 12:00:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:00:18 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:00:18 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:00:18 --> Helper loaded: date_helper
INFO - 2018-12-31 12:00:18 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:00:18 --> Helper loaded: form_helper
INFO - 2018-12-31 12:00:18 --> Form Validation Class Initialized
INFO - 2018-12-31 12:00:18 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:00:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:00:18 --> Final output sent to browser
DEBUG - 2018-12-31 12:00:18 --> Total execution time: 0.3410
INFO - 2018-12-31 12:00:26 --> Config Class Initialized
INFO - 2018-12-31 12:00:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:00:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:00:26 --> Utf8 Class Initialized
INFO - 2018-12-31 12:00:26 --> URI Class Initialized
INFO - 2018-12-31 12:00:26 --> Router Class Initialized
INFO - 2018-12-31 12:00:26 --> Output Class Initialized
INFO - 2018-12-31 12:00:26 --> Security Class Initialized
DEBUG - 2018-12-31 12:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:00:26 --> CSRF cookie sent
INFO - 2018-12-31 12:00:26 --> CSRF token verified
INFO - 2018-12-31 12:00:26 --> Input Class Initialized
INFO - 2018-12-31 12:00:26 --> Language Class Initialized
INFO - 2018-12-31 12:00:26 --> Loader Class Initialized
INFO - 2018-12-31 12:00:26 --> Helper loaded: url_helper
INFO - 2018-12-31 12:00:26 --> Helper loaded: file_helper
INFO - 2018-12-31 12:00:26 --> Helper loaded: util_helper
INFO - 2018-12-31 12:00:26 --> Controller Class Initialized
INFO - 2018-12-31 12:00:26 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:00:26 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:00:26 --> Email Class Initialized
INFO - 2018-12-31 12:00:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:00:26 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:00:26 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:00:27 --> Helper loaded: date_helper
INFO - 2018-12-31 12:00:27 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:00:27 --> Helper loaded: form_helper
INFO - 2018-12-31 12:00:27 --> Form Validation Class Initialized
INFO - 2018-12-31 12:00:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:00:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 12:00:27 --> Config Class Initialized
INFO - 2018-12-31 12:00:27 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:00:27 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:00:27 --> Utf8 Class Initialized
INFO - 2018-12-31 12:00:27 --> URI Class Initialized
DEBUG - 2018-12-31 12:00:27 --> No URI present. Default controller set.
INFO - 2018-12-31 12:00:27 --> Router Class Initialized
INFO - 2018-12-31 12:00:27 --> Output Class Initialized
INFO - 2018-12-31 12:00:27 --> Security Class Initialized
DEBUG - 2018-12-31 12:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:00:27 --> CSRF cookie sent
INFO - 2018-12-31 12:00:27 --> Input Class Initialized
INFO - 2018-12-31 12:00:27 --> Language Class Initialized
INFO - 2018-12-31 12:00:27 --> Loader Class Initialized
INFO - 2018-12-31 12:00:27 --> Helper loaded: url_helper
INFO - 2018-12-31 12:00:27 --> Helper loaded: file_helper
INFO - 2018-12-31 12:00:27 --> Helper loaded: util_helper
INFO - 2018-12-31 12:00:27 --> Controller Class Initialized
INFO - 2018-12-31 12:00:27 --> Database Driver Class Initialized
INFO - 2018-12-31 12:00:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:00:27 --> Final output sent to browser
DEBUG - 2018-12-31 12:00:27 --> Total execution time: 0.1811
INFO - 2018-12-31 12:02:09 --> Config Class Initialized
INFO - 2018-12-31 12:02:09 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:02:09 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:02:09 --> Utf8 Class Initialized
INFO - 2018-12-31 12:02:09 --> URI Class Initialized
INFO - 2018-12-31 12:02:09 --> Router Class Initialized
INFO - 2018-12-31 12:02:09 --> Output Class Initialized
INFO - 2018-12-31 12:02:09 --> Security Class Initialized
DEBUG - 2018-12-31 12:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:02:09 --> CSRF cookie sent
INFO - 2018-12-31 12:02:09 --> Input Class Initialized
INFO - 2018-12-31 12:02:09 --> Language Class Initialized
INFO - 2018-12-31 12:02:09 --> Loader Class Initialized
INFO - 2018-12-31 12:02:09 --> Helper loaded: url_helper
INFO - 2018-12-31 12:02:09 --> Helper loaded: file_helper
INFO - 2018-12-31 12:02:09 --> Helper loaded: util_helper
INFO - 2018-12-31 12:02:09 --> Controller Class Initialized
INFO - 2018-12-31 12:02:09 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:02:09 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:02:09 --> Email Class Initialized
INFO - 2018-12-31 12:02:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:02:09 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:02:10 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:02:10 --> Helper loaded: date_helper
INFO - 2018-12-31 12:02:10 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:02:10 --> Helper loaded: form_helper
INFO - 2018-12-31 12:02:10 --> Form Validation Class Initialized
INFO - 2018-12-31 12:02:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:02:10 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:02:10 --> Final output sent to browser
DEBUG - 2018-12-31 12:02:10 --> Total execution time: 0.3049
INFO - 2018-12-31 12:02:10 --> Config Class Initialized
INFO - 2018-12-31 12:02:10 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:02:10 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:02:10 --> Utf8 Class Initialized
INFO - 2018-12-31 12:02:10 --> URI Class Initialized
INFO - 2018-12-31 12:02:10 --> Router Class Initialized
INFO - 2018-12-31 12:02:10 --> Output Class Initialized
INFO - 2018-12-31 12:02:10 --> Security Class Initialized
DEBUG - 2018-12-31 12:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:02:10 --> CSRF cookie sent
INFO - 2018-12-31 12:02:10 --> Input Class Initialized
INFO - 2018-12-31 12:02:10 --> Language Class Initialized
INFO - 2018-12-31 12:02:10 --> Loader Class Initialized
INFO - 2018-12-31 12:02:10 --> Helper loaded: url_helper
INFO - 2018-12-31 12:02:10 --> Helper loaded: file_helper
INFO - 2018-12-31 12:02:10 --> Helper loaded: util_helper
INFO - 2018-12-31 12:02:10 --> Controller Class Initialized
INFO - 2018-12-31 12:02:10 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:02:10 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:02:10 --> Email Class Initialized
INFO - 2018-12-31 12:02:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:02:10 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:02:10 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:02:10 --> Helper loaded: date_helper
INFO - 2018-12-31 12:02:10 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:02:10 --> Helper loaded: form_helper
INFO - 2018-12-31 12:02:10 --> Form Validation Class Initialized
INFO - 2018-12-31 12:02:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:02:10 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:02:10 --> Final output sent to browser
DEBUG - 2018-12-31 12:02:10 --> Total execution time: 0.2905
INFO - 2018-12-31 12:02:12 --> Config Class Initialized
INFO - 2018-12-31 12:02:12 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:02:12 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:02:12 --> Utf8 Class Initialized
INFO - 2018-12-31 12:02:12 --> URI Class Initialized
INFO - 2018-12-31 12:02:12 --> Router Class Initialized
INFO - 2018-12-31 12:02:12 --> Output Class Initialized
INFO - 2018-12-31 12:02:12 --> Security Class Initialized
DEBUG - 2018-12-31 12:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:02:12 --> CSRF cookie sent
INFO - 2018-12-31 12:02:12 --> Input Class Initialized
INFO - 2018-12-31 12:02:12 --> Language Class Initialized
INFO - 2018-12-31 12:02:12 --> Loader Class Initialized
INFO - 2018-12-31 12:02:12 --> Helper loaded: url_helper
INFO - 2018-12-31 12:02:12 --> Helper loaded: file_helper
INFO - 2018-12-31 12:02:12 --> Helper loaded: util_helper
INFO - 2018-12-31 12:02:12 --> Controller Class Initialized
INFO - 2018-12-31 12:02:12 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:02:12 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:02:12 --> Email Class Initialized
INFO - 2018-12-31 12:02:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:02:12 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:02:12 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:02:12 --> Helper loaded: date_helper
INFO - 2018-12-31 12:02:12 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:02:12 --> Helper loaded: form_helper
INFO - 2018-12-31 12:02:12 --> Form Validation Class Initialized
INFO - 2018-12-31 12:02:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:02:13 --> Config Class Initialized
INFO - 2018-12-31 12:02:13 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:02:13 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:02:13 --> Utf8 Class Initialized
INFO - 2018-12-31 12:02:13 --> URI Class Initialized
INFO - 2018-12-31 12:02:13 --> Router Class Initialized
INFO - 2018-12-31 12:02:13 --> Output Class Initialized
INFO - 2018-12-31 12:02:13 --> Security Class Initialized
DEBUG - 2018-12-31 12:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:02:13 --> CSRF cookie sent
INFO - 2018-12-31 12:02:13 --> Input Class Initialized
INFO - 2018-12-31 12:02:13 --> Language Class Initialized
ERROR - 2018-12-31 12:02:13 --> 404 Page Not Found: Login/index
INFO - 2018-12-31 12:02:54 --> Config Class Initialized
INFO - 2018-12-31 12:02:54 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:02:54 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:02:54 --> Utf8 Class Initialized
INFO - 2018-12-31 12:02:54 --> URI Class Initialized
INFO - 2018-12-31 12:02:54 --> Router Class Initialized
INFO - 2018-12-31 12:02:54 --> Output Class Initialized
INFO - 2018-12-31 12:02:54 --> Security Class Initialized
DEBUG - 2018-12-31 12:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:02:54 --> CSRF cookie sent
INFO - 2018-12-31 12:02:54 --> Input Class Initialized
INFO - 2018-12-31 12:02:54 --> Language Class Initialized
INFO - 2018-12-31 12:02:54 --> Loader Class Initialized
INFO - 2018-12-31 12:02:54 --> Helper loaded: url_helper
INFO - 2018-12-31 12:02:54 --> Helper loaded: file_helper
INFO - 2018-12-31 12:02:54 --> Helper loaded: util_helper
INFO - 2018-12-31 12:02:54 --> Controller Class Initialized
INFO - 2018-12-31 12:02:54 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:02:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:02:54 --> Email Class Initialized
INFO - 2018-12-31 12:02:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:02:54 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:02:54 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:02:54 --> Helper loaded: date_helper
INFO - 2018-12-31 12:02:54 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:02:54 --> Helper loaded: form_helper
INFO - 2018-12-31 12:02:54 --> Form Validation Class Initialized
INFO - 2018-12-31 12:02:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:02:54 --> Config Class Initialized
INFO - 2018-12-31 12:02:54 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:02:54 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:02:54 --> Utf8 Class Initialized
INFO - 2018-12-31 12:02:54 --> URI Class Initialized
INFO - 2018-12-31 12:02:54 --> Router Class Initialized
INFO - 2018-12-31 12:02:54 --> Output Class Initialized
INFO - 2018-12-31 12:02:54 --> Security Class Initialized
DEBUG - 2018-12-31 12:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:02:54 --> CSRF cookie sent
INFO - 2018-12-31 12:02:54 --> Input Class Initialized
INFO - 2018-12-31 12:02:54 --> Language Class Initialized
ERROR - 2018-12-31 12:02:54 --> 404 Page Not Found: Base_auth/index
INFO - 2018-12-31 12:03:10 --> Config Class Initialized
INFO - 2018-12-31 12:03:10 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:03:10 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:03:10 --> Utf8 Class Initialized
INFO - 2018-12-31 12:03:10 --> URI Class Initialized
INFO - 2018-12-31 12:03:10 --> Router Class Initialized
INFO - 2018-12-31 12:03:10 --> Output Class Initialized
INFO - 2018-12-31 12:03:10 --> Security Class Initialized
DEBUG - 2018-12-31 12:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:03:10 --> CSRF cookie sent
INFO - 2018-12-31 12:03:10 --> Input Class Initialized
INFO - 2018-12-31 12:03:10 --> Language Class Initialized
INFO - 2018-12-31 12:03:10 --> Loader Class Initialized
INFO - 2018-12-31 12:03:10 --> Helper loaded: url_helper
INFO - 2018-12-31 12:03:10 --> Helper loaded: file_helper
INFO - 2018-12-31 12:03:10 --> Helper loaded: util_helper
INFO - 2018-12-31 12:03:10 --> Controller Class Initialized
INFO - 2018-12-31 12:03:10 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:03:10 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:03:10 --> Email Class Initialized
INFO - 2018-12-31 12:03:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:03:10 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:03:10 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:03:10 --> Helper loaded: date_helper
INFO - 2018-12-31 12:03:10 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:03:10 --> Helper loaded: form_helper
INFO - 2018-12-31 12:03:10 --> Form Validation Class Initialized
INFO - 2018-12-31 12:03:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:03:11 --> Config Class Initialized
INFO - 2018-12-31 12:03:11 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:03:11 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:03:11 --> Utf8 Class Initialized
INFO - 2018-12-31 12:03:11 --> URI Class Initialized
INFO - 2018-12-31 12:03:11 --> Router Class Initialized
INFO - 2018-12-31 12:03:11 --> Output Class Initialized
INFO - 2018-12-31 12:03:11 --> Security Class Initialized
DEBUG - 2018-12-31 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:03:11 --> CSRF cookie sent
INFO - 2018-12-31 12:03:11 --> Input Class Initialized
INFO - 2018-12-31 12:03:11 --> Language Class Initialized
INFO - 2018-12-31 12:03:11 --> Loader Class Initialized
INFO - 2018-12-31 12:03:11 --> Helper loaded: url_helper
INFO - 2018-12-31 12:03:11 --> Helper loaded: file_helper
INFO - 2018-12-31 12:03:11 --> Helper loaded: util_helper
INFO - 2018-12-31 12:03:11 --> Controller Class Initialized
INFO - 2018-12-31 12:03:11 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:03:11 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:03:11 --> Email Class Initialized
INFO - 2018-12-31 12:03:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:03:11 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:03:11 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:03:11 --> Helper loaded: date_helper
INFO - 2018-12-31 12:03:11 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:03:11 --> Helper loaded: form_helper
INFO - 2018-12-31 12:03:11 --> Form Validation Class Initialized
INFO - 2018-12-31 12:03:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:03:11 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:03:11 --> Final output sent to browser
DEBUG - 2018-12-31 12:03:11 --> Total execution time: 0.2793
INFO - 2018-12-31 12:04:42 --> Config Class Initialized
INFO - 2018-12-31 12:04:42 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:04:42 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:04:42 --> Utf8 Class Initialized
INFO - 2018-12-31 12:04:42 --> URI Class Initialized
INFO - 2018-12-31 12:04:42 --> Router Class Initialized
INFO - 2018-12-31 12:04:42 --> Output Class Initialized
INFO - 2018-12-31 12:04:42 --> Security Class Initialized
DEBUG - 2018-12-31 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:04:42 --> CSRF cookie sent
INFO - 2018-12-31 12:04:42 --> Input Class Initialized
INFO - 2018-12-31 12:04:42 --> Language Class Initialized
INFO - 2018-12-31 12:04:42 --> Loader Class Initialized
INFO - 2018-12-31 12:04:42 --> Helper loaded: url_helper
INFO - 2018-12-31 12:04:42 --> Helper loaded: file_helper
INFO - 2018-12-31 12:04:42 --> Helper loaded: util_helper
INFO - 2018-12-31 12:04:42 --> Controller Class Initialized
INFO - 2018-12-31 12:04:42 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:04:42 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:04:42 --> Email Class Initialized
INFO - 2018-12-31 12:04:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:04:42 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:04:42 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:04:42 --> Helper loaded: date_helper
INFO - 2018-12-31 12:04:42 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:04:42 --> Helper loaded: form_helper
INFO - 2018-12-31 12:04:42 --> Form Validation Class Initialized
INFO - 2018-12-31 12:04:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:04:42 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:04:43 --> Final output sent to browser
DEBUG - 2018-12-31 12:04:43 --> Total execution time: 0.2917
INFO - 2018-12-31 12:04:48 --> Config Class Initialized
INFO - 2018-12-31 12:04:48 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:04:48 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:04:48 --> Utf8 Class Initialized
INFO - 2018-12-31 12:04:48 --> URI Class Initialized
INFO - 2018-12-31 12:04:48 --> Router Class Initialized
INFO - 2018-12-31 12:04:48 --> Output Class Initialized
INFO - 2018-12-31 12:04:48 --> Security Class Initialized
DEBUG - 2018-12-31 12:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:04:48 --> CSRF cookie sent
INFO - 2018-12-31 12:04:48 --> CSRF token verified
INFO - 2018-12-31 12:04:48 --> Input Class Initialized
INFO - 2018-12-31 12:04:48 --> Language Class Initialized
INFO - 2018-12-31 12:04:48 --> Loader Class Initialized
INFO - 2018-12-31 12:04:48 --> Helper loaded: url_helper
INFO - 2018-12-31 12:04:48 --> Helper loaded: file_helper
INFO - 2018-12-31 12:04:48 --> Helper loaded: util_helper
INFO - 2018-12-31 12:04:48 --> Controller Class Initialized
INFO - 2018-12-31 12:04:48 --> Database Driver Class Initialized
DEBUG - 2018-12-31 12:04:48 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:04:48 --> Email Class Initialized
INFO - 2018-12-31 12:04:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:04:48 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:04:48 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:04:48 --> Helper loaded: date_helper
INFO - 2018-12-31 12:04:48 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:04:48 --> Helper loaded: form_helper
INFO - 2018-12-31 12:04:48 --> Form Validation Class Initialized
INFO - 2018-12-31 12:04:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:04:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 12:04:49 --> Config Class Initialized
INFO - 2018-12-31 12:04:49 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:04:49 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:04:49 --> Utf8 Class Initialized
INFO - 2018-12-31 12:04:49 --> URI Class Initialized
DEBUG - 2018-12-31 12:04:49 --> No URI present. Default controller set.
INFO - 2018-12-31 12:04:49 --> Router Class Initialized
INFO - 2018-12-31 12:04:49 --> Output Class Initialized
INFO - 2018-12-31 12:04:49 --> Security Class Initialized
DEBUG - 2018-12-31 12:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:04:49 --> CSRF cookie sent
INFO - 2018-12-31 12:04:49 --> Input Class Initialized
INFO - 2018-12-31 12:04:49 --> Language Class Initialized
INFO - 2018-12-31 12:04:49 --> Loader Class Initialized
INFO - 2018-12-31 12:04:49 --> Helper loaded: url_helper
INFO - 2018-12-31 12:04:49 --> Helper loaded: file_helper
INFO - 2018-12-31 12:04:49 --> Helper loaded: util_helper
INFO - 2018-12-31 12:04:49 --> Controller Class Initialized
INFO - 2018-12-31 12:04:49 --> Database Driver Class Initialized
INFO - 2018-12-31 12:04:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:04:49 --> Final output sent to browser
DEBUG - 2018-12-31 12:04:49 --> Total execution time: 0.1804
INFO - 2018-12-31 12:37:02 --> Config Class Initialized
INFO - 2018-12-31 12:37:02 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:37:02 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:37:02 --> Utf8 Class Initialized
INFO - 2018-12-31 12:37:02 --> URI Class Initialized
DEBUG - 2018-12-31 12:37:02 --> No URI present. Default controller set.
INFO - 2018-12-31 12:37:02 --> Router Class Initialized
INFO - 2018-12-31 12:37:02 --> Output Class Initialized
INFO - 2018-12-31 12:37:02 --> Security Class Initialized
DEBUG - 2018-12-31 12:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:37:02 --> CSRF cookie sent
INFO - 2018-12-31 12:37:02 --> Input Class Initialized
INFO - 2018-12-31 12:37:02 --> Language Class Initialized
INFO - 2018-12-31 12:37:02 --> Loader Class Initialized
INFO - 2018-12-31 12:37:02 --> Helper loaded: url_helper
INFO - 2018-12-31 12:37:02 --> Helper loaded: file_helper
INFO - 2018-12-31 12:37:02 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:37:02 --> Helper loaded: util_helper
INFO - 2018-12-31 12:37:02 --> Controller Class Initialized
INFO - 2018-12-31 12:37:02 --> Database Driver Class Initialized
ERROR - 2018-12-31 12:37:02 --> Severity: error --> Exception: Call to undefined function is_auth() C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes\argon-design-system\index.php 127
INFO - 2018-12-31 12:37:25 --> Config Class Initialized
INFO - 2018-12-31 12:37:25 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:37:25 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:37:25 --> Utf8 Class Initialized
INFO - 2018-12-31 12:37:25 --> URI Class Initialized
DEBUG - 2018-12-31 12:37:25 --> No URI present. Default controller set.
INFO - 2018-12-31 12:37:25 --> Router Class Initialized
INFO - 2018-12-31 12:37:25 --> Output Class Initialized
INFO - 2018-12-31 12:37:25 --> Security Class Initialized
DEBUG - 2018-12-31 12:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:37:25 --> CSRF cookie sent
INFO - 2018-12-31 12:37:25 --> Input Class Initialized
INFO - 2018-12-31 12:37:25 --> Language Class Initialized
INFO - 2018-12-31 12:37:25 --> Loader Class Initialized
INFO - 2018-12-31 12:37:25 --> Helper loaded: url_helper
INFO - 2018-12-31 12:37:25 --> Helper loaded: file_helper
INFO - 2018-12-31 12:37:25 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:37:25 --> Helper loaded: util_helper
INFO - 2018-12-31 12:37:25 --> Controller Class Initialized
INFO - 2018-12-31 12:37:25 --> Database Driver Class Initialized
ERROR - 2018-12-31 12:37:25 --> Severity: Notice --> Undefined property: Cindex::$ion_auth C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\auth_helper.php 13
ERROR - 2018-12-31 12:37:25 --> Severity: error --> Exception: Call to a member function logged_in() on null C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\auth_helper.php 13
INFO - 2018-12-31 12:40:04 --> Config Class Initialized
INFO - 2018-12-31 12:40:04 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:40:04 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:40:04 --> Utf8 Class Initialized
INFO - 2018-12-31 12:40:04 --> URI Class Initialized
DEBUG - 2018-12-31 12:40:04 --> No URI present. Default controller set.
INFO - 2018-12-31 12:40:04 --> Router Class Initialized
INFO - 2018-12-31 12:40:04 --> Output Class Initialized
INFO - 2018-12-31 12:40:04 --> Security Class Initialized
DEBUG - 2018-12-31 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:40:04 --> CSRF cookie sent
INFO - 2018-12-31 12:40:04 --> Input Class Initialized
INFO - 2018-12-31 12:40:04 --> Language Class Initialized
INFO - 2018-12-31 12:40:04 --> Loader Class Initialized
INFO - 2018-12-31 12:40:04 --> Helper loaded: url_helper
INFO - 2018-12-31 12:40:04 --> Helper loaded: file_helper
INFO - 2018-12-31 12:40:04 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:40:04 --> Helper loaded: util_helper
DEBUG - 2018-12-31 12:40:04 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
INFO - 2018-12-31 12:40:04 --> Email Class Initialized
INFO - 2018-12-31 12:40:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:40:04 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:40:04 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-31 12:40:04 --> Helper loaded: date_helper
ERROR - 2018-12-31 12:40:04 --> Severity: Notice --> Undefined property: Cindex::$db C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\models\Ion_auth_model.php 213
INFO - 2018-12-31 12:40:04 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:40:04 --> Controller Class Initialized
INFO - 2018-12-31 12:40:04 --> Database Driver Class Initialized
INFO - 2018-12-31 12:40:04 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:40:04 --> Final output sent to browser
DEBUG - 2018-12-31 12:40:04 --> Total execution time: 0.3139
INFO - 2018-12-31 12:41:09 --> Config Class Initialized
INFO - 2018-12-31 12:41:09 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:41:09 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:41:09 --> Utf8 Class Initialized
INFO - 2018-12-31 12:41:09 --> URI Class Initialized
DEBUG - 2018-12-31 12:41:09 --> No URI present. Default controller set.
INFO - 2018-12-31 12:41:09 --> Router Class Initialized
INFO - 2018-12-31 12:41:09 --> Output Class Initialized
INFO - 2018-12-31 12:41:09 --> Security Class Initialized
DEBUG - 2018-12-31 12:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:41:09 --> CSRF cookie sent
INFO - 2018-12-31 12:41:09 --> Input Class Initialized
INFO - 2018-12-31 12:41:09 --> Language Class Initialized
INFO - 2018-12-31 12:41:09 --> Loader Class Initialized
INFO - 2018-12-31 12:41:09 --> Helper loaded: url_helper
INFO - 2018-12-31 12:41:09 --> Helper loaded: file_helper
INFO - 2018-12-31 12:41:09 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:41:09 --> Helper loaded: util_helper
INFO - 2018-12-31 12:41:09 --> Database Driver Class Initialized
INFO - 2018-12-31 12:41:09 --> Email Class Initialized
DEBUG - 2018-12-31 12:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:41:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:41:09 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:41:09 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:41:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:41:09 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:41:09 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:41:09 --> Helper loaded: date_helper
INFO - 2018-12-31 12:41:09 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:41:09 --> Controller Class Initialized
INFO - 2018-12-31 12:41:09 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:41:09 --> Final output sent to browser
DEBUG - 2018-12-31 12:41:09 --> Total execution time: 0.3182
INFO - 2018-12-31 12:43:36 --> Config Class Initialized
INFO - 2018-12-31 12:43:36 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:43:36 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:43:36 --> Utf8 Class Initialized
INFO - 2018-12-31 12:43:36 --> URI Class Initialized
DEBUG - 2018-12-31 12:43:36 --> No URI present. Default controller set.
INFO - 2018-12-31 12:43:36 --> Router Class Initialized
INFO - 2018-12-31 12:43:36 --> Output Class Initialized
INFO - 2018-12-31 12:43:36 --> Security Class Initialized
DEBUG - 2018-12-31 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:43:36 --> CSRF cookie sent
INFO - 2018-12-31 12:43:36 --> Input Class Initialized
INFO - 2018-12-31 12:43:36 --> Language Class Initialized
INFO - 2018-12-31 12:43:36 --> Loader Class Initialized
INFO - 2018-12-31 12:43:36 --> Helper loaded: url_helper
INFO - 2018-12-31 12:43:36 --> Helper loaded: file_helper
INFO - 2018-12-31 12:43:36 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:43:36 --> Helper loaded: util_helper
INFO - 2018-12-31 12:43:37 --> Database Driver Class Initialized
INFO - 2018-12-31 12:43:37 --> Email Class Initialized
DEBUG - 2018-12-31 12:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:43:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:43:37 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:43:37 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:43:37 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:43:37 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:37 --> Helper loaded: date_helper
INFO - 2018-12-31 12:43:37 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:43:37 --> Controller Class Initialized
INFO - 2018-12-31 12:43:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:43:37 --> Final output sent to browser
DEBUG - 2018-12-31 12:43:37 --> Total execution time: 0.3128
INFO - 2018-12-31 12:43:41 --> Config Class Initialized
INFO - 2018-12-31 12:43:41 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:43:41 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:43:41 --> Utf8 Class Initialized
INFO - 2018-12-31 12:43:41 --> URI Class Initialized
INFO - 2018-12-31 12:43:41 --> Router Class Initialized
INFO - 2018-12-31 12:43:41 --> Output Class Initialized
INFO - 2018-12-31 12:43:41 --> Security Class Initialized
DEBUG - 2018-12-31 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:43:41 --> CSRF cookie sent
INFO - 2018-12-31 12:43:41 --> Input Class Initialized
INFO - 2018-12-31 12:43:41 --> Language Class Initialized
INFO - 2018-12-31 12:43:41 --> Loader Class Initialized
INFO - 2018-12-31 12:43:41 --> Helper loaded: url_helper
INFO - 2018-12-31 12:43:41 --> Helper loaded: file_helper
INFO - 2018-12-31 12:43:41 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:43:41 --> Helper loaded: util_helper
INFO - 2018-12-31 12:43:41 --> Database Driver Class Initialized
INFO - 2018-12-31 12:43:41 --> Email Class Initialized
DEBUG - 2018-12-31 12:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:43:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:43:41 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:43:41 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:43:41 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:43:41 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:41 --> Helper loaded: date_helper
INFO - 2018-12-31 12:43:41 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:43:41 --> Controller Class Initialized
DEBUG - 2018-12-31 12:43:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:41 --> Helper loaded: form_helper
INFO - 2018-12-31 12:43:41 --> Form Validation Class Initialized
INFO - 2018-12-31 12:43:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:43:41 --> Config Class Initialized
INFO - 2018-12-31 12:43:41 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:43:41 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:43:41 --> Utf8 Class Initialized
INFO - 2018-12-31 12:43:41 --> URI Class Initialized
INFO - 2018-12-31 12:43:41 --> Router Class Initialized
INFO - 2018-12-31 12:43:41 --> Output Class Initialized
INFO - 2018-12-31 12:43:41 --> Security Class Initialized
DEBUG - 2018-12-31 12:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:43:42 --> CSRF cookie sent
INFO - 2018-12-31 12:43:42 --> Input Class Initialized
INFO - 2018-12-31 12:43:42 --> Language Class Initialized
INFO - 2018-12-31 12:43:42 --> Loader Class Initialized
INFO - 2018-12-31 12:43:42 --> Helper loaded: url_helper
INFO - 2018-12-31 12:43:42 --> Helper loaded: file_helper
INFO - 2018-12-31 12:43:42 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:43:42 --> Helper loaded: util_helper
INFO - 2018-12-31 12:43:42 --> Database Driver Class Initialized
INFO - 2018-12-31 12:43:42 --> Email Class Initialized
DEBUG - 2018-12-31 12:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:43:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:43:42 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:43:42 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:43:42 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:43:42 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:42 --> Helper loaded: date_helper
INFO - 2018-12-31 12:43:42 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:43:42 --> Controller Class Initialized
DEBUG - 2018-12-31 12:43:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:43:42 --> Helper loaded: form_helper
INFO - 2018-12-31 12:43:42 --> Form Validation Class Initialized
INFO - 2018-12-31 12:43:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:43:42 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:43:42 --> Final output sent to browser
DEBUG - 2018-12-31 12:43:42 --> Total execution time: 0.3373
INFO - 2018-12-31 12:44:14 --> Config Class Initialized
INFO - 2018-12-31 12:44:14 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:44:14 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:44:14 --> Utf8 Class Initialized
INFO - 2018-12-31 12:44:14 --> URI Class Initialized
DEBUG - 2018-12-31 12:44:14 --> No URI present. Default controller set.
INFO - 2018-12-31 12:44:14 --> Router Class Initialized
INFO - 2018-12-31 12:44:14 --> Output Class Initialized
INFO - 2018-12-31 12:44:14 --> Security Class Initialized
DEBUG - 2018-12-31 12:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:44:14 --> CSRF cookie sent
INFO - 2018-12-31 12:44:14 --> Input Class Initialized
INFO - 2018-12-31 12:44:15 --> Language Class Initialized
INFO - 2018-12-31 12:44:15 --> Loader Class Initialized
INFO - 2018-12-31 12:44:15 --> Helper loaded: url_helper
INFO - 2018-12-31 12:44:15 --> Helper loaded: file_helper
INFO - 2018-12-31 12:44:15 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:44:15 --> Helper loaded: util_helper
INFO - 2018-12-31 12:44:15 --> Database Driver Class Initialized
INFO - 2018-12-31 12:44:15 --> Email Class Initialized
DEBUG - 2018-12-31 12:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:44:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:44:15 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:44:15 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:44:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:44:15 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:44:15 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:44:15 --> Helper loaded: date_helper
INFO - 2018-12-31 12:44:15 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:44:15 --> Controller Class Initialized
INFO - 2018-12-31 12:44:15 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:44:15 --> Final output sent to browser
DEBUG - 2018-12-31 12:44:15 --> Total execution time: 0.2965
INFO - 2018-12-31 12:45:32 --> Config Class Initialized
INFO - 2018-12-31 12:45:32 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:45:32 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:45:32 --> Utf8 Class Initialized
INFO - 2018-12-31 12:45:32 --> URI Class Initialized
DEBUG - 2018-12-31 12:45:32 --> No URI present. Default controller set.
INFO - 2018-12-31 12:45:32 --> Router Class Initialized
INFO - 2018-12-31 12:45:32 --> Output Class Initialized
INFO - 2018-12-31 12:45:32 --> Security Class Initialized
DEBUG - 2018-12-31 12:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:45:32 --> CSRF cookie sent
INFO - 2018-12-31 12:45:32 --> Input Class Initialized
INFO - 2018-12-31 12:45:32 --> Language Class Initialized
INFO - 2018-12-31 12:45:32 --> Loader Class Initialized
INFO - 2018-12-31 12:45:32 --> Helper loaded: url_helper
INFO - 2018-12-31 12:45:32 --> Helper loaded: file_helper
INFO - 2018-12-31 12:45:32 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:45:32 --> Helper loaded: util_helper
INFO - 2018-12-31 12:45:32 --> Database Driver Class Initialized
INFO - 2018-12-31 12:45:32 --> Email Class Initialized
DEBUG - 2018-12-31 12:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:45:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:45:32 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:45:32 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:45:32 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:45:32 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:32 --> Helper loaded: date_helper
INFO - 2018-12-31 12:45:32 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:45:32 --> Controller Class Initialized
INFO - 2018-12-31 12:45:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:45:32 --> Final output sent to browser
DEBUG - 2018-12-31 12:45:32 --> Total execution time: 0.3168
INFO - 2018-12-31 12:45:44 --> Config Class Initialized
INFO - 2018-12-31 12:45:44 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:45:44 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:45:44 --> Utf8 Class Initialized
INFO - 2018-12-31 12:45:44 --> URI Class Initialized
DEBUG - 2018-12-31 12:45:44 --> No URI present. Default controller set.
INFO - 2018-12-31 12:45:44 --> Router Class Initialized
INFO - 2018-12-31 12:45:44 --> Output Class Initialized
INFO - 2018-12-31 12:45:44 --> Security Class Initialized
DEBUG - 2018-12-31 12:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:45:44 --> CSRF cookie sent
INFO - 2018-12-31 12:45:44 --> Input Class Initialized
INFO - 2018-12-31 12:45:44 --> Language Class Initialized
INFO - 2018-12-31 12:45:44 --> Loader Class Initialized
INFO - 2018-12-31 12:45:44 --> Helper loaded: url_helper
INFO - 2018-12-31 12:45:44 --> Helper loaded: file_helper
INFO - 2018-12-31 12:45:44 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:45:44 --> Helper loaded: util_helper
INFO - 2018-12-31 12:45:44 --> Database Driver Class Initialized
INFO - 2018-12-31 12:45:44 --> Email Class Initialized
DEBUG - 2018-12-31 12:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:45:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:45:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:45:44 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:45:44 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:45:44 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:44 --> Helper loaded: date_helper
INFO - 2018-12-31 12:45:44 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:45:44 --> Controller Class Initialized
INFO - 2018-12-31 12:45:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:45:44 --> Final output sent to browser
DEBUG - 2018-12-31 12:45:44 --> Total execution time: 0.2904
INFO - 2018-12-31 12:45:46 --> Config Class Initialized
INFO - 2018-12-31 12:45:46 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:45:46 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:45:46 --> Utf8 Class Initialized
INFO - 2018-12-31 12:45:46 --> URI Class Initialized
DEBUG - 2018-12-31 12:45:46 --> No URI present. Default controller set.
INFO - 2018-12-31 12:45:46 --> Router Class Initialized
INFO - 2018-12-31 12:45:46 --> Output Class Initialized
INFO - 2018-12-31 12:45:46 --> Security Class Initialized
DEBUG - 2018-12-31 12:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:45:46 --> CSRF cookie sent
INFO - 2018-12-31 12:45:46 --> Input Class Initialized
INFO - 2018-12-31 12:45:46 --> Language Class Initialized
INFO - 2018-12-31 12:45:46 --> Loader Class Initialized
INFO - 2018-12-31 12:45:46 --> Helper loaded: url_helper
INFO - 2018-12-31 12:45:46 --> Helper loaded: file_helper
INFO - 2018-12-31 12:45:46 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:45:46 --> Helper loaded: util_helper
INFO - 2018-12-31 12:45:46 --> Database Driver Class Initialized
INFO - 2018-12-31 12:45:46 --> Email Class Initialized
DEBUG - 2018-12-31 12:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:45:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:45:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:45:46 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:45:46 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:45:46 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:46 --> Helper loaded: date_helper
INFO - 2018-12-31 12:45:46 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:45:46 --> Controller Class Initialized
INFO - 2018-12-31 12:45:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:45:46 --> Final output sent to browser
DEBUG - 2018-12-31 12:45:46 --> Total execution time: 0.2971
INFO - 2018-12-31 12:45:47 --> Config Class Initialized
INFO - 2018-12-31 12:45:47 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:45:47 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:45:47 --> Utf8 Class Initialized
INFO - 2018-12-31 12:45:47 --> URI Class Initialized
DEBUG - 2018-12-31 12:45:47 --> No URI present. Default controller set.
INFO - 2018-12-31 12:45:47 --> Router Class Initialized
INFO - 2018-12-31 12:45:47 --> Output Class Initialized
INFO - 2018-12-31 12:45:47 --> Security Class Initialized
DEBUG - 2018-12-31 12:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:45:47 --> CSRF cookie sent
INFO - 2018-12-31 12:45:47 --> Input Class Initialized
INFO - 2018-12-31 12:45:47 --> Language Class Initialized
INFO - 2018-12-31 12:45:47 --> Loader Class Initialized
INFO - 2018-12-31 12:45:47 --> Helper loaded: url_helper
INFO - 2018-12-31 12:45:47 --> Helper loaded: file_helper
INFO - 2018-12-31 12:45:47 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:45:47 --> Helper loaded: util_helper
INFO - 2018-12-31 12:45:47 --> Database Driver Class Initialized
INFO - 2018-12-31 12:45:47 --> Email Class Initialized
DEBUG - 2018-12-31 12:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:45:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:45:47 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:45:47 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:45:47 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:45:47 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:45:47 --> Helper loaded: date_helper
INFO - 2018-12-31 12:45:47 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:45:47 --> Controller Class Initialized
INFO - 2018-12-31 12:45:47 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:45:47 --> Final output sent to browser
DEBUG - 2018-12-31 12:45:47 --> Total execution time: 0.3186
INFO - 2018-12-31 12:47:08 --> Config Class Initialized
INFO - 2018-12-31 12:47:08 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:47:08 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:47:08 --> Utf8 Class Initialized
INFO - 2018-12-31 12:47:08 --> URI Class Initialized
DEBUG - 2018-12-31 12:47:08 --> No URI present. Default controller set.
INFO - 2018-12-31 12:47:08 --> Router Class Initialized
INFO - 2018-12-31 12:47:08 --> Output Class Initialized
INFO - 2018-12-31 12:47:08 --> Security Class Initialized
DEBUG - 2018-12-31 12:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:47:08 --> CSRF cookie sent
INFO - 2018-12-31 12:47:08 --> Input Class Initialized
INFO - 2018-12-31 12:47:08 --> Language Class Initialized
INFO - 2018-12-31 12:47:08 --> Loader Class Initialized
INFO - 2018-12-31 12:47:08 --> Helper loaded: url_helper
INFO - 2018-12-31 12:47:08 --> Helper loaded: file_helper
INFO - 2018-12-31 12:47:08 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:47:08 --> Helper loaded: util_helper
INFO - 2018-12-31 12:47:08 --> Database Driver Class Initialized
INFO - 2018-12-31 12:47:08 --> Email Class Initialized
DEBUG - 2018-12-31 12:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:47:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:47:08 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:47:08 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:47:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:47:08 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:47:08 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:47:08 --> Helper loaded: date_helper
INFO - 2018-12-31 12:47:08 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:47:08 --> Controller Class Initialized
INFO - 2018-12-31 12:47:08 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:47:08 --> Final output sent to browser
DEBUG - 2018-12-31 12:47:08 --> Total execution time: 0.3817
INFO - 2018-12-31 12:48:12 --> Config Class Initialized
INFO - 2018-12-31 12:48:12 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:48:12 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:48:12 --> Utf8 Class Initialized
INFO - 2018-12-31 12:48:12 --> URI Class Initialized
DEBUG - 2018-12-31 12:48:12 --> No URI present. Default controller set.
INFO - 2018-12-31 12:48:12 --> Router Class Initialized
INFO - 2018-12-31 12:48:12 --> Output Class Initialized
INFO - 2018-12-31 12:48:12 --> Security Class Initialized
DEBUG - 2018-12-31 12:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:48:12 --> CSRF cookie sent
INFO - 2018-12-31 12:48:12 --> Input Class Initialized
INFO - 2018-12-31 12:48:12 --> Language Class Initialized
INFO - 2018-12-31 12:48:12 --> Loader Class Initialized
INFO - 2018-12-31 12:48:12 --> Helper loaded: url_helper
INFO - 2018-12-31 12:48:12 --> Helper loaded: file_helper
INFO - 2018-12-31 12:48:12 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:48:12 --> Helper loaded: util_helper
INFO - 2018-12-31 12:48:12 --> Database Driver Class Initialized
INFO - 2018-12-31 12:48:12 --> Email Class Initialized
DEBUG - 2018-12-31 12:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:48:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:48:12 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:48:12 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:48:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:48:12 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:48:12 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:48:12 --> Helper loaded: date_helper
INFO - 2018-12-31 12:48:12 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:48:12 --> Controller Class Initialized
INFO - 2018-12-31 12:48:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:48:12 --> Final output sent to browser
DEBUG - 2018-12-31 12:48:12 --> Total execution time: 0.3307
INFO - 2018-12-31 12:53:57 --> Config Class Initialized
INFO - 2018-12-31 12:53:57 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:53:57 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:53:57 --> Utf8 Class Initialized
INFO - 2018-12-31 12:53:57 --> URI Class Initialized
DEBUG - 2018-12-31 12:53:57 --> No URI present. Default controller set.
INFO - 2018-12-31 12:53:57 --> Router Class Initialized
INFO - 2018-12-31 12:53:57 --> Output Class Initialized
INFO - 2018-12-31 12:53:57 --> Security Class Initialized
DEBUG - 2018-12-31 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:53:57 --> CSRF cookie sent
INFO - 2018-12-31 12:53:57 --> Input Class Initialized
INFO - 2018-12-31 12:53:57 --> Language Class Initialized
INFO - 2018-12-31 12:53:57 --> Loader Class Initialized
INFO - 2018-12-31 12:53:57 --> Helper loaded: url_helper
INFO - 2018-12-31 12:53:57 --> Helper loaded: file_helper
INFO - 2018-12-31 12:53:57 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:53:57 --> Helper loaded: util_helper
INFO - 2018-12-31 12:53:57 --> Database Driver Class Initialized
INFO - 2018-12-31 12:53:57 --> Email Class Initialized
DEBUG - 2018-12-31 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:53:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:53:57 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:53:57 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:53:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:53:57 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:53:57 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:53:57 --> Helper loaded: date_helper
INFO - 2018-12-31 12:53:57 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:53:57 --> Controller Class Initialized
INFO - 2018-12-31 12:53:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:53:57 --> Final output sent to browser
DEBUG - 2018-12-31 12:53:58 --> Total execution time: 0.6970
INFO - 2018-12-31 12:54:06 --> Config Class Initialized
INFO - 2018-12-31 12:54:06 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:54:06 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:54:06 --> Utf8 Class Initialized
INFO - 2018-12-31 12:54:06 --> URI Class Initialized
INFO - 2018-12-31 12:54:06 --> Router Class Initialized
INFO - 2018-12-31 12:54:06 --> Output Class Initialized
INFO - 2018-12-31 12:54:06 --> Security Class Initialized
DEBUG - 2018-12-31 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:54:06 --> CSRF cookie sent
INFO - 2018-12-31 12:54:06 --> Input Class Initialized
INFO - 2018-12-31 12:54:06 --> Language Class Initialized
INFO - 2018-12-31 12:54:06 --> Loader Class Initialized
INFO - 2018-12-31 12:54:06 --> Helper loaded: url_helper
INFO - 2018-12-31 12:54:06 --> Helper loaded: file_helper
INFO - 2018-12-31 12:54:06 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:54:06 --> Helper loaded: util_helper
INFO - 2018-12-31 12:54:06 --> Database Driver Class Initialized
INFO - 2018-12-31 12:54:06 --> Email Class Initialized
DEBUG - 2018-12-31 12:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:54:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:54:06 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:54:06 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:54:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:54:06 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:54:06 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:54:06 --> Helper loaded: date_helper
INFO - 2018-12-31 12:54:06 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:54:06 --> Controller Class Initialized
DEBUG - 2018-12-31 12:54:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:54:06 --> Helper loaded: form_helper
INFO - 2018-12-31 12:54:06 --> Form Validation Class Initialized
INFO - 2018-12-31 12:54:06 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:54:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:54:06 --> Final output sent to browser
DEBUG - 2018-12-31 12:54:06 --> Total execution time: 0.4398
INFO - 2018-12-31 12:55:18 --> Config Class Initialized
INFO - 2018-12-31 12:55:18 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:55:18 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:55:18 --> Utf8 Class Initialized
INFO - 2018-12-31 12:55:18 --> URI Class Initialized
DEBUG - 2018-12-31 12:55:18 --> No URI present. Default controller set.
INFO - 2018-12-31 12:55:18 --> Router Class Initialized
INFO - 2018-12-31 12:55:18 --> Output Class Initialized
INFO - 2018-12-31 12:55:18 --> Security Class Initialized
DEBUG - 2018-12-31 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:55:18 --> CSRF cookie sent
INFO - 2018-12-31 12:55:18 --> Input Class Initialized
INFO - 2018-12-31 12:55:18 --> Language Class Initialized
INFO - 2018-12-31 12:55:19 --> Loader Class Initialized
INFO - 2018-12-31 12:55:19 --> Helper loaded: url_helper
INFO - 2018-12-31 12:55:19 --> Helper loaded: file_helper
INFO - 2018-12-31 12:55:19 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:55:19 --> Helper loaded: util_helper
INFO - 2018-12-31 12:55:19 --> Database Driver Class Initialized
INFO - 2018-12-31 12:55:19 --> Email Class Initialized
DEBUG - 2018-12-31 12:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:55:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:55:19 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:55:19 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:55:19 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:55:19 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:19 --> Helper loaded: date_helper
INFO - 2018-12-31 12:55:19 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:55:19 --> Controller Class Initialized
INFO - 2018-12-31 12:55:19 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:55:19 --> Final output sent to browser
DEBUG - 2018-12-31 12:55:19 --> Total execution time: 0.3417
INFO - 2018-12-31 12:55:29 --> Config Class Initialized
INFO - 2018-12-31 12:55:29 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:55:29 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:55:29 --> Utf8 Class Initialized
INFO - 2018-12-31 12:55:29 --> URI Class Initialized
INFO - 2018-12-31 12:55:29 --> Router Class Initialized
INFO - 2018-12-31 12:55:29 --> Output Class Initialized
INFO - 2018-12-31 12:55:29 --> Security Class Initialized
DEBUG - 2018-12-31 12:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:55:29 --> CSRF cookie sent
INFO - 2018-12-31 12:55:29 --> Input Class Initialized
INFO - 2018-12-31 12:55:29 --> Language Class Initialized
INFO - 2018-12-31 12:55:29 --> Loader Class Initialized
INFO - 2018-12-31 12:55:29 --> Helper loaded: url_helper
INFO - 2018-12-31 12:55:29 --> Helper loaded: file_helper
INFO - 2018-12-31 12:55:29 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:55:29 --> Helper loaded: util_helper
INFO - 2018-12-31 12:55:29 --> Database Driver Class Initialized
INFO - 2018-12-31 12:55:29 --> Email Class Initialized
DEBUG - 2018-12-31 12:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:55:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:55:29 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:55:29 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:55:29 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:55:29 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:29 --> Helper loaded: date_helper
INFO - 2018-12-31 12:55:29 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:55:29 --> Controller Class Initialized
DEBUG - 2018-12-31 12:55:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:29 --> Helper loaded: form_helper
INFO - 2018-12-31 12:55:29 --> Form Validation Class Initialized
INFO - 2018-12-31 12:55:29 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:55:29 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:55:29 --> Final output sent to browser
DEBUG - 2018-12-31 12:55:29 --> Total execution time: 0.4084
INFO - 2018-12-31 12:55:43 --> Config Class Initialized
INFO - 2018-12-31 12:55:43 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:55:43 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:55:43 --> Utf8 Class Initialized
INFO - 2018-12-31 12:55:43 --> URI Class Initialized
DEBUG - 2018-12-31 12:55:43 --> No URI present. Default controller set.
INFO - 2018-12-31 12:55:43 --> Router Class Initialized
INFO - 2018-12-31 12:55:43 --> Output Class Initialized
INFO - 2018-12-31 12:55:43 --> Security Class Initialized
DEBUG - 2018-12-31 12:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:55:43 --> CSRF cookie sent
INFO - 2018-12-31 12:55:43 --> Input Class Initialized
INFO - 2018-12-31 12:55:43 --> Language Class Initialized
INFO - 2018-12-31 12:55:43 --> Loader Class Initialized
INFO - 2018-12-31 12:55:43 --> Helper loaded: url_helper
INFO - 2018-12-31 12:55:43 --> Helper loaded: file_helper
INFO - 2018-12-31 12:55:43 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:55:43 --> Helper loaded: util_helper
INFO - 2018-12-31 12:55:43 --> Database Driver Class Initialized
INFO - 2018-12-31 12:55:43 --> Email Class Initialized
DEBUG - 2018-12-31 12:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:55:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:55:43 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:55:43 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:55:43 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:55:43 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:43 --> Helper loaded: date_helper
INFO - 2018-12-31 12:55:44 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:55:44 --> Controller Class Initialized
INFO - 2018-12-31 12:55:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 12:55:44 --> Final output sent to browser
DEBUG - 2018-12-31 12:55:44 --> Total execution time: 0.3359
INFO - 2018-12-31 12:55:51 --> Config Class Initialized
INFO - 2018-12-31 12:55:51 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:55:51 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:55:51 --> Utf8 Class Initialized
INFO - 2018-12-31 12:55:51 --> URI Class Initialized
INFO - 2018-12-31 12:55:51 --> Router Class Initialized
INFO - 2018-12-31 12:55:51 --> Output Class Initialized
INFO - 2018-12-31 12:55:51 --> Security Class Initialized
DEBUG - 2018-12-31 12:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:55:51 --> CSRF cookie sent
INFO - 2018-12-31 12:55:51 --> Input Class Initialized
INFO - 2018-12-31 12:55:51 --> Language Class Initialized
INFO - 2018-12-31 12:55:51 --> Loader Class Initialized
INFO - 2018-12-31 12:55:51 --> Helper loaded: url_helper
INFO - 2018-12-31 12:55:51 --> Helper loaded: file_helper
INFO - 2018-12-31 12:55:51 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:55:51 --> Helper loaded: util_helper
INFO - 2018-12-31 12:55:51 --> Database Driver Class Initialized
INFO - 2018-12-31 12:55:51 --> Email Class Initialized
DEBUG - 2018-12-31 12:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:55:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:55:51 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:55:51 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:55:51 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:55:51 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:51 --> Helper loaded: date_helper
INFO - 2018-12-31 12:55:51 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:55:51 --> Controller Class Initialized
DEBUG - 2018-12-31 12:55:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:55:51 --> Helper loaded: form_helper
INFO - 2018-12-31 12:55:51 --> Form Validation Class Initialized
INFO - 2018-12-31 12:55:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:55:51 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:55:51 --> Final output sent to browser
DEBUG - 2018-12-31 12:55:51 --> Total execution time: 0.3731
INFO - 2018-12-31 12:55:56 --> Config Class Initialized
INFO - 2018-12-31 12:55:56 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:55:56 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:55:56 --> Utf8 Class Initialized
INFO - 2018-12-31 12:55:56 --> URI Class Initialized
INFO - 2018-12-31 12:55:56 --> Router Class Initialized
INFO - 2018-12-31 12:55:56 --> Output Class Initialized
INFO - 2018-12-31 12:55:56 --> Security Class Initialized
DEBUG - 2018-12-31 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:55:56 --> CSRF cookie sent
INFO - 2018-12-31 12:55:56 --> Input Class Initialized
INFO - 2018-12-31 12:55:56 --> Language Class Initialized
ERROR - 2018-12-31 12:55:56 --> 404 Page Not Found: Create_user/index
INFO - 2018-12-31 12:56:06 --> Config Class Initialized
INFO - 2018-12-31 12:56:06 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:56:06 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:56:06 --> Utf8 Class Initialized
INFO - 2018-12-31 12:56:06 --> URI Class Initialized
INFO - 2018-12-31 12:56:06 --> Router Class Initialized
INFO - 2018-12-31 12:56:06 --> Output Class Initialized
INFO - 2018-12-31 12:56:06 --> Security Class Initialized
DEBUG - 2018-12-31 12:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:56:06 --> CSRF cookie sent
INFO - 2018-12-31 12:56:06 --> Input Class Initialized
INFO - 2018-12-31 12:56:06 --> Language Class Initialized
INFO - 2018-12-31 12:56:06 --> Loader Class Initialized
INFO - 2018-12-31 12:56:06 --> Helper loaded: url_helper
INFO - 2018-12-31 12:56:06 --> Helper loaded: file_helper
INFO - 2018-12-31 12:56:06 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:56:06 --> Helper loaded: util_helper
INFO - 2018-12-31 12:56:06 --> Database Driver Class Initialized
INFO - 2018-12-31 12:56:06 --> Email Class Initialized
DEBUG - 2018-12-31 12:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:56:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:56:06 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:56:06 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:56:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:56:06 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:56:06 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:56:06 --> Helper loaded: date_helper
INFO - 2018-12-31 12:56:07 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:56:07 --> Controller Class Initialized
DEBUG - 2018-12-31 12:56:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:56:07 --> Helper loaded: form_helper
INFO - 2018-12-31 12:56:07 --> Form Validation Class Initialized
INFO - 2018-12-31 12:56:07 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:56:07 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:56:07 --> Final output sent to browser
DEBUG - 2018-12-31 12:56:07 --> Total execution time: 0.3980
INFO - 2018-12-31 12:56:10 --> Config Class Initialized
INFO - 2018-12-31 12:56:10 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:56:10 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:56:10 --> Utf8 Class Initialized
INFO - 2018-12-31 12:56:10 --> URI Class Initialized
INFO - 2018-12-31 12:56:10 --> Router Class Initialized
INFO - 2018-12-31 12:56:10 --> Output Class Initialized
INFO - 2018-12-31 12:56:10 --> Security Class Initialized
DEBUG - 2018-12-31 12:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:56:10 --> CSRF cookie sent
INFO - 2018-12-31 12:56:10 --> Input Class Initialized
INFO - 2018-12-31 12:56:10 --> Language Class Initialized
INFO - 2018-12-31 12:56:10 --> Loader Class Initialized
INFO - 2018-12-31 12:56:10 --> Helper loaded: url_helper
INFO - 2018-12-31 12:56:10 --> Helper loaded: file_helper
INFO - 2018-12-31 12:56:10 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:56:10 --> Helper loaded: util_helper
INFO - 2018-12-31 12:56:10 --> Database Driver Class Initialized
INFO - 2018-12-31 12:56:10 --> Email Class Initialized
DEBUG - 2018-12-31 12:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:56:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:56:10 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:56:10 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:56:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:56:10 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:56:10 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:56:10 --> Helper loaded: date_helper
INFO - 2018-12-31 12:56:10 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:56:10 --> Controller Class Initialized
DEBUG - 2018-12-31 12:56:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:56:10 --> Helper loaded: form_helper
INFO - 2018-12-31 12:56:10 --> Form Validation Class Initialized
INFO - 2018-12-31 12:56:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:56:10 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 12:56:10 --> Final output sent to browser
DEBUG - 2018-12-31 12:56:10 --> Total execution time: 0.3429
INFO - 2018-12-31 12:58:12 --> Config Class Initialized
INFO - 2018-12-31 12:58:12 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:58:12 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:58:12 --> Utf8 Class Initialized
INFO - 2018-12-31 12:58:12 --> URI Class Initialized
INFO - 2018-12-31 12:58:12 --> Router Class Initialized
INFO - 2018-12-31 12:58:12 --> Output Class Initialized
INFO - 2018-12-31 12:58:12 --> Security Class Initialized
DEBUG - 2018-12-31 12:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:58:12 --> CSRF cookie sent
INFO - 2018-12-31 12:58:12 --> Input Class Initialized
INFO - 2018-12-31 12:58:12 --> Language Class Initialized
INFO - 2018-12-31 12:58:12 --> Loader Class Initialized
INFO - 2018-12-31 12:58:12 --> Helper loaded: url_helper
INFO - 2018-12-31 12:58:12 --> Helper loaded: file_helper
INFO - 2018-12-31 12:58:12 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:58:12 --> Helper loaded: util_helper
INFO - 2018-12-31 12:58:12 --> Database Driver Class Initialized
INFO - 2018-12-31 12:58:12 --> Email Class Initialized
DEBUG - 2018-12-31 12:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:58:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:58:12 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:58:12 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:58:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:58:12 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:58:12 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:58:12 --> Helper loaded: date_helper
INFO - 2018-12-31 12:58:12 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:58:12 --> Controller Class Initialized
DEBUG - 2018-12-31 12:58:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:58:12 --> Helper loaded: form_helper
INFO - 2018-12-31 12:58:12 --> Form Validation Class Initialized
INFO - 2018-12-31 12:58:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:58:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 12:58:12 --> Final output sent to browser
DEBUG - 2018-12-31 12:58:12 --> Total execution time: 0.3513
INFO - 2018-12-31 12:58:23 --> Config Class Initialized
INFO - 2018-12-31 12:58:23 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:58:23 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:58:23 --> Utf8 Class Initialized
INFO - 2018-12-31 12:58:23 --> URI Class Initialized
INFO - 2018-12-31 12:58:23 --> Router Class Initialized
INFO - 2018-12-31 12:58:23 --> Output Class Initialized
INFO - 2018-12-31 12:58:23 --> Security Class Initialized
DEBUG - 2018-12-31 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:58:23 --> CSRF cookie sent
INFO - 2018-12-31 12:58:23 --> Input Class Initialized
INFO - 2018-12-31 12:58:23 --> Language Class Initialized
INFO - 2018-12-31 12:58:23 --> Loader Class Initialized
INFO - 2018-12-31 12:58:23 --> Helper loaded: url_helper
INFO - 2018-12-31 12:58:23 --> Helper loaded: file_helper
INFO - 2018-12-31 12:58:23 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:58:23 --> Helper loaded: util_helper
INFO - 2018-12-31 12:58:23 --> Database Driver Class Initialized
INFO - 2018-12-31 12:58:23 --> Email Class Initialized
DEBUG - 2018-12-31 12:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:58:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:58:23 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:58:23 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:58:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:58:23 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:58:23 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:58:23 --> Helper loaded: date_helper
INFO - 2018-12-31 12:58:23 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:58:23 --> Controller Class Initialized
DEBUG - 2018-12-31 12:58:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:58:23 --> Helper loaded: form_helper
INFO - 2018-12-31 12:58:23 --> Form Validation Class Initialized
INFO - 2018-12-31 12:58:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:58:23 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:58:23 --> Final output sent to browser
DEBUG - 2018-12-31 12:58:23 --> Total execution time: 0.3845
INFO - 2018-12-31 12:59:26 --> Config Class Initialized
INFO - 2018-12-31 12:59:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:59:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:59:26 --> Utf8 Class Initialized
INFO - 2018-12-31 12:59:26 --> URI Class Initialized
INFO - 2018-12-31 12:59:26 --> Router Class Initialized
INFO - 2018-12-31 12:59:26 --> Output Class Initialized
INFO - 2018-12-31 12:59:26 --> Security Class Initialized
DEBUG - 2018-12-31 12:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:59:26 --> CSRF cookie sent
INFO - 2018-12-31 12:59:26 --> Input Class Initialized
INFO - 2018-12-31 12:59:26 --> Language Class Initialized
INFO - 2018-12-31 12:59:26 --> Loader Class Initialized
INFO - 2018-12-31 12:59:26 --> Helper loaded: url_helper
INFO - 2018-12-31 12:59:26 --> Helper loaded: file_helper
INFO - 2018-12-31 12:59:26 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:59:26 --> Helper loaded: util_helper
INFO - 2018-12-31 12:59:26 --> Database Driver Class Initialized
INFO - 2018-12-31 12:59:26 --> Email Class Initialized
DEBUG - 2018-12-31 12:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:59:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:59:26 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:59:26 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:59:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:59:26 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:59:26 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:59:26 --> Helper loaded: date_helper
INFO - 2018-12-31 12:59:26 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:59:26 --> Controller Class Initialized
DEBUG - 2018-12-31 12:59:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:59:26 --> Helper loaded: form_helper
INFO - 2018-12-31 12:59:26 --> Form Validation Class Initialized
INFO - 2018-12-31 12:59:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:59:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 12:59:26 --> Final output sent to browser
DEBUG - 2018-12-31 12:59:26 --> Total execution time: 0.3484
INFO - 2018-12-31 12:59:32 --> Config Class Initialized
INFO - 2018-12-31 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-12-31 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-12-31 12:59:32 --> Utf8 Class Initialized
INFO - 2018-12-31 12:59:32 --> URI Class Initialized
INFO - 2018-12-31 12:59:32 --> Router Class Initialized
INFO - 2018-12-31 12:59:32 --> Output Class Initialized
INFO - 2018-12-31 12:59:32 --> Security Class Initialized
DEBUG - 2018-12-31 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 12:59:32 --> CSRF cookie sent
INFO - 2018-12-31 12:59:32 --> Input Class Initialized
INFO - 2018-12-31 12:59:32 --> Language Class Initialized
INFO - 2018-12-31 12:59:32 --> Loader Class Initialized
INFO - 2018-12-31 12:59:32 --> Helper loaded: url_helper
INFO - 2018-12-31 12:59:32 --> Helper loaded: file_helper
INFO - 2018-12-31 12:59:32 --> Helper loaded: auth_helper
INFO - 2018-12-31 12:59:32 --> Helper loaded: util_helper
INFO - 2018-12-31 12:59:32 --> Database Driver Class Initialized
INFO - 2018-12-31 12:59:32 --> Email Class Initialized
DEBUG - 2018-12-31 12:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 12:59:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 12:59:32 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 12:59:32 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:59:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 12:59:32 --> Helper loaded: cookie_helper
INFO - 2018-12-31 12:59:32 --> Helper loaded: language_helper
DEBUG - 2018-12-31 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:59:32 --> Helper loaded: date_helper
INFO - 2018-12-31 12:59:32 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 12:59:32 --> Controller Class Initialized
DEBUG - 2018-12-31 12:59:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 12:59:32 --> Helper loaded: form_helper
INFO - 2018-12-31 12:59:32 --> Form Validation Class Initialized
INFO - 2018-12-31 12:59:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 12:59:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 12:59:32 --> Final output sent to browser
DEBUG - 2018-12-31 12:59:32 --> Total execution time: 0.3433
INFO - 2018-12-31 13:01:38 --> Config Class Initialized
INFO - 2018-12-31 13:01:38 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:01:38 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:01:38 --> Utf8 Class Initialized
INFO - 2018-12-31 13:01:38 --> URI Class Initialized
INFO - 2018-12-31 13:01:38 --> Router Class Initialized
INFO - 2018-12-31 13:01:38 --> Output Class Initialized
INFO - 2018-12-31 13:01:38 --> Security Class Initialized
DEBUG - 2018-12-31 13:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:01:38 --> CSRF cookie sent
INFO - 2018-12-31 13:01:38 --> Input Class Initialized
INFO - 2018-12-31 13:01:38 --> Language Class Initialized
INFO - 2018-12-31 13:01:39 --> Loader Class Initialized
INFO - 2018-12-31 13:01:39 --> Helper loaded: url_helper
INFO - 2018-12-31 13:01:39 --> Helper loaded: file_helper
INFO - 2018-12-31 13:01:39 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:01:39 --> Helper loaded: util_helper
INFO - 2018-12-31 13:01:39 --> Database Driver Class Initialized
INFO - 2018-12-31 13:01:39 --> Email Class Initialized
DEBUG - 2018-12-31 13:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:01:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:01:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:01:39 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:01:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:01:39 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:01:39 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:01:39 --> Helper loaded: date_helper
INFO - 2018-12-31 13:01:39 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:01:39 --> Controller Class Initialized
DEBUG - 2018-12-31 13:01:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:01:39 --> Helper loaded: form_helper
INFO - 2018-12-31 13:01:39 --> Form Validation Class Initialized
INFO - 2018-12-31 13:01:39 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:01:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:01:39 --> Final output sent to browser
DEBUG - 2018-12-31 13:01:39 --> Total execution time: 0.3524
INFO - 2018-12-31 13:03:58 --> Config Class Initialized
INFO - 2018-12-31 13:03:58 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:03:58 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:03:58 --> Utf8 Class Initialized
INFO - 2018-12-31 13:03:58 --> URI Class Initialized
INFO - 2018-12-31 13:03:58 --> Router Class Initialized
INFO - 2018-12-31 13:03:58 --> Output Class Initialized
INFO - 2018-12-31 13:03:58 --> Security Class Initialized
DEBUG - 2018-12-31 13:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:03:58 --> CSRF cookie sent
INFO - 2018-12-31 13:03:58 --> Input Class Initialized
INFO - 2018-12-31 13:03:58 --> Language Class Initialized
INFO - 2018-12-31 13:03:58 --> Loader Class Initialized
INFO - 2018-12-31 13:03:58 --> Helper loaded: url_helper
INFO - 2018-12-31 13:03:58 --> Helper loaded: file_helper
INFO - 2018-12-31 13:03:58 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:03:58 --> Helper loaded: util_helper
INFO - 2018-12-31 13:03:58 --> Database Driver Class Initialized
INFO - 2018-12-31 13:03:58 --> Email Class Initialized
DEBUG - 2018-12-31 13:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:03:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:03:58 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:03:58 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:03:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:03:58 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:03:58 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:03:58 --> Helper loaded: date_helper
INFO - 2018-12-31 13:03:58 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:03:58 --> Controller Class Initialized
DEBUG - 2018-12-31 13:03:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:03:58 --> Helper loaded: form_helper
INFO - 2018-12-31 13:03:58 --> Form Validation Class Initialized
INFO - 2018-12-31 13:03:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:03:58 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:03:58 --> Final output sent to browser
DEBUG - 2018-12-31 13:03:58 --> Total execution time: 0.3749
INFO - 2018-12-31 13:04:04 --> Config Class Initialized
INFO - 2018-12-31 13:04:04 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:04:04 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:04:04 --> Utf8 Class Initialized
INFO - 2018-12-31 13:04:04 --> URI Class Initialized
INFO - 2018-12-31 13:04:04 --> Router Class Initialized
INFO - 2018-12-31 13:04:04 --> Output Class Initialized
INFO - 2018-12-31 13:04:04 --> Security Class Initialized
DEBUG - 2018-12-31 13:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:04:04 --> CSRF cookie sent
INFO - 2018-12-31 13:04:04 --> Input Class Initialized
INFO - 2018-12-31 13:04:04 --> Language Class Initialized
INFO - 2018-12-31 13:04:04 --> Loader Class Initialized
INFO - 2018-12-31 13:04:04 --> Helper loaded: url_helper
INFO - 2018-12-31 13:04:04 --> Helper loaded: file_helper
INFO - 2018-12-31 13:04:04 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:04:04 --> Helper loaded: util_helper
INFO - 2018-12-31 13:04:04 --> Database Driver Class Initialized
INFO - 2018-12-31 13:04:04 --> Email Class Initialized
DEBUG - 2018-12-31 13:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:04:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:04:04 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:04:04 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:04:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:04:04 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:04:04 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:04:04 --> Helper loaded: date_helper
INFO - 2018-12-31 13:04:05 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:04:05 --> Controller Class Initialized
DEBUG - 2018-12-31 13:04:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:04:05 --> Helper loaded: form_helper
INFO - 2018-12-31 13:04:05 --> Form Validation Class Initialized
INFO - 2018-12-31 13:04:05 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:04:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:04:05 --> Final output sent to browser
DEBUG - 2018-12-31 13:04:05 --> Total execution time: 0.3501
INFO - 2018-12-31 13:05:17 --> Config Class Initialized
INFO - 2018-12-31 13:05:17 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:05:17 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:05:17 --> Utf8 Class Initialized
INFO - 2018-12-31 13:05:17 --> URI Class Initialized
INFO - 2018-12-31 13:05:17 --> Router Class Initialized
INFO - 2018-12-31 13:05:17 --> Output Class Initialized
INFO - 2018-12-31 13:05:17 --> Security Class Initialized
DEBUG - 2018-12-31 13:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:05:17 --> CSRF cookie sent
INFO - 2018-12-31 13:05:17 --> Input Class Initialized
INFO - 2018-12-31 13:05:17 --> Language Class Initialized
INFO - 2018-12-31 13:05:17 --> Loader Class Initialized
INFO - 2018-12-31 13:05:17 --> Helper loaded: url_helper
INFO - 2018-12-31 13:05:17 --> Helper loaded: file_helper
INFO - 2018-12-31 13:05:17 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:05:17 --> Helper loaded: util_helper
INFO - 2018-12-31 13:05:17 --> Database Driver Class Initialized
INFO - 2018-12-31 13:05:17 --> Email Class Initialized
DEBUG - 2018-12-31 13:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:05:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:05:17 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:05:17 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:05:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:05:17 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:05:17 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:05:17 --> Helper loaded: date_helper
INFO - 2018-12-31 13:05:17 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:05:17 --> Controller Class Initialized
DEBUG - 2018-12-31 13:05:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:05:17 --> Helper loaded: form_helper
INFO - 2018-12-31 13:05:17 --> Form Validation Class Initialized
INFO - 2018-12-31 13:05:17 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:05:17 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:05:17 --> Final output sent to browser
DEBUG - 2018-12-31 13:05:17 --> Total execution time: 0.3538
INFO - 2018-12-31 13:05:27 --> Config Class Initialized
INFO - 2018-12-31 13:05:27 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:05:27 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:05:27 --> Utf8 Class Initialized
INFO - 2018-12-31 13:05:27 --> URI Class Initialized
INFO - 2018-12-31 13:05:27 --> Router Class Initialized
INFO - 2018-12-31 13:05:27 --> Output Class Initialized
INFO - 2018-12-31 13:05:28 --> Security Class Initialized
DEBUG - 2018-12-31 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:05:28 --> CSRF cookie sent
INFO - 2018-12-31 13:05:28 --> Input Class Initialized
INFO - 2018-12-31 13:05:28 --> Language Class Initialized
INFO - 2018-12-31 13:05:28 --> Loader Class Initialized
INFO - 2018-12-31 13:05:28 --> Helper loaded: url_helper
INFO - 2018-12-31 13:05:28 --> Helper loaded: file_helper
INFO - 2018-12-31 13:05:28 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:05:28 --> Helper loaded: util_helper
INFO - 2018-12-31 13:05:28 --> Database Driver Class Initialized
INFO - 2018-12-31 13:05:28 --> Email Class Initialized
DEBUG - 2018-12-31 13:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:05:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:05:28 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:05:28 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:05:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:05:28 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:05:28 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:05:28 --> Helper loaded: date_helper
INFO - 2018-12-31 13:05:28 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:05:28 --> Controller Class Initialized
DEBUG - 2018-12-31 13:05:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:05:28 --> Helper loaded: form_helper
INFO - 2018-12-31 13:05:28 --> Form Validation Class Initialized
INFO - 2018-12-31 13:05:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:05:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:05:28 --> Final output sent to browser
DEBUG - 2018-12-31 13:05:28 --> Total execution time: 0.3382
INFO - 2018-12-31 13:06:33 --> Config Class Initialized
INFO - 2018-12-31 13:06:33 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:06:33 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:06:33 --> Utf8 Class Initialized
INFO - 2018-12-31 13:06:33 --> URI Class Initialized
INFO - 2018-12-31 13:06:33 --> Router Class Initialized
INFO - 2018-12-31 13:06:33 --> Output Class Initialized
INFO - 2018-12-31 13:06:33 --> Security Class Initialized
DEBUG - 2018-12-31 13:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:06:33 --> CSRF cookie sent
INFO - 2018-12-31 13:06:33 --> Input Class Initialized
INFO - 2018-12-31 13:06:33 --> Language Class Initialized
INFO - 2018-12-31 13:06:33 --> Loader Class Initialized
INFO - 2018-12-31 13:06:33 --> Helper loaded: url_helper
INFO - 2018-12-31 13:06:33 --> Helper loaded: file_helper
INFO - 2018-12-31 13:06:33 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:06:33 --> Helper loaded: util_helper
INFO - 2018-12-31 13:06:33 --> Database Driver Class Initialized
INFO - 2018-12-31 13:06:33 --> Email Class Initialized
DEBUG - 2018-12-31 13:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:06:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:06:33 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:06:33 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:06:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:06:33 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:06:33 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:06:33 --> Helper loaded: date_helper
INFO - 2018-12-31 13:06:33 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:06:33 --> Controller Class Initialized
DEBUG - 2018-12-31 13:06:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:06:33 --> Helper loaded: form_helper
INFO - 2018-12-31 13:06:33 --> Form Validation Class Initialized
INFO - 2018-12-31 13:06:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:06:33 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:06:33 --> Final output sent to browser
DEBUG - 2018-12-31 13:06:33 --> Total execution time: 0.3498
INFO - 2018-12-31 13:07:17 --> Config Class Initialized
INFO - 2018-12-31 13:07:17 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:07:17 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:07:17 --> Utf8 Class Initialized
INFO - 2018-12-31 13:07:17 --> URI Class Initialized
INFO - 2018-12-31 13:07:17 --> Router Class Initialized
INFO - 2018-12-31 13:07:17 --> Output Class Initialized
INFO - 2018-12-31 13:07:17 --> Security Class Initialized
DEBUG - 2018-12-31 13:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:07:17 --> CSRF cookie sent
INFO - 2018-12-31 13:07:17 --> Input Class Initialized
INFO - 2018-12-31 13:07:17 --> Language Class Initialized
INFO - 2018-12-31 13:07:17 --> Loader Class Initialized
INFO - 2018-12-31 13:07:17 --> Helper loaded: url_helper
INFO - 2018-12-31 13:07:17 --> Helper loaded: file_helper
INFO - 2018-12-31 13:07:17 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:07:17 --> Helper loaded: util_helper
INFO - 2018-12-31 13:07:17 --> Database Driver Class Initialized
INFO - 2018-12-31 13:07:17 --> Email Class Initialized
DEBUG - 2018-12-31 13:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:07:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:07:17 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:07:17 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:07:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:07:17 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:07:17 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:07:17 --> Helper loaded: date_helper
INFO - 2018-12-31 13:07:17 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:07:17 --> Controller Class Initialized
DEBUG - 2018-12-31 13:07:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:07:17 --> Helper loaded: form_helper
INFO - 2018-12-31 13:07:17 --> Form Validation Class Initialized
INFO - 2018-12-31 13:07:17 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:07:17 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:07:17 --> Final output sent to browser
DEBUG - 2018-12-31 13:07:17 --> Total execution time: 0.3405
INFO - 2018-12-31 13:08:41 --> Config Class Initialized
INFO - 2018-12-31 13:08:41 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:08:42 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:08:42 --> Utf8 Class Initialized
INFO - 2018-12-31 13:08:42 --> URI Class Initialized
INFO - 2018-12-31 13:08:42 --> Router Class Initialized
INFO - 2018-12-31 13:08:42 --> Output Class Initialized
INFO - 2018-12-31 13:08:42 --> Security Class Initialized
DEBUG - 2018-12-31 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:08:42 --> CSRF cookie sent
INFO - 2018-12-31 13:08:42 --> Input Class Initialized
INFO - 2018-12-31 13:08:42 --> Language Class Initialized
INFO - 2018-12-31 13:08:42 --> Loader Class Initialized
INFO - 2018-12-31 13:08:42 --> Helper loaded: url_helper
INFO - 2018-12-31 13:08:42 --> Helper loaded: file_helper
INFO - 2018-12-31 13:08:42 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:08:42 --> Helper loaded: util_helper
INFO - 2018-12-31 13:08:42 --> Database Driver Class Initialized
INFO - 2018-12-31 13:08:42 --> Email Class Initialized
DEBUG - 2018-12-31 13:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:08:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:08:42 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:08:42 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:08:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:08:42 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:08:42 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:08:42 --> Helper loaded: date_helper
INFO - 2018-12-31 13:08:42 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:08:42 --> Controller Class Initialized
DEBUG - 2018-12-31 13:08:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:08:42 --> Helper loaded: form_helper
INFO - 2018-12-31 13:08:42 --> Form Validation Class Initialized
INFO - 2018-12-31 13:08:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:08:42 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:08:42 --> Final output sent to browser
DEBUG - 2018-12-31 13:08:42 --> Total execution time: 0.4044
INFO - 2018-12-31 13:08:45 --> Config Class Initialized
INFO - 2018-12-31 13:08:45 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:08:45 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:08:45 --> Utf8 Class Initialized
INFO - 2018-12-31 13:08:45 --> URI Class Initialized
INFO - 2018-12-31 13:08:45 --> Router Class Initialized
INFO - 2018-12-31 13:08:45 --> Output Class Initialized
INFO - 2018-12-31 13:08:45 --> Security Class Initialized
DEBUG - 2018-12-31 13:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:08:45 --> CSRF cookie sent
INFO - 2018-12-31 13:08:45 --> CSRF token verified
INFO - 2018-12-31 13:08:45 --> Input Class Initialized
INFO - 2018-12-31 13:08:45 --> Language Class Initialized
INFO - 2018-12-31 13:08:45 --> Loader Class Initialized
INFO - 2018-12-31 13:08:45 --> Helper loaded: url_helper
INFO - 2018-12-31 13:08:45 --> Helper loaded: file_helper
INFO - 2018-12-31 13:08:45 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:08:45 --> Helper loaded: util_helper
INFO - 2018-12-31 13:08:45 --> Database Driver Class Initialized
INFO - 2018-12-31 13:08:45 --> Email Class Initialized
DEBUG - 2018-12-31 13:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:08:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:08:45 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:08:45 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:08:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:08:45 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:08:45 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:08:45 --> Helper loaded: date_helper
INFO - 2018-12-31 13:08:45 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:08:45 --> Controller Class Initialized
DEBUG - 2018-12-31 13:08:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:08:45 --> Helper loaded: form_helper
INFO - 2018-12-31 13:08:45 --> Form Validation Class Initialized
INFO - 2018-12-31 13:08:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:08:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:08:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:08:45 --> Final output sent to browser
DEBUG - 2018-12-31 13:08:45 --> Total execution time: 0.4027
INFO - 2018-12-31 13:17:53 --> Config Class Initialized
INFO - 2018-12-31 13:17:53 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:17:53 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:17:53 --> Utf8 Class Initialized
INFO - 2018-12-31 13:17:53 --> URI Class Initialized
INFO - 2018-12-31 13:17:53 --> Router Class Initialized
INFO - 2018-12-31 13:17:53 --> Output Class Initialized
INFO - 2018-12-31 13:17:53 --> Security Class Initialized
DEBUG - 2018-12-31 13:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:17:53 --> CSRF cookie sent
INFO - 2018-12-31 13:17:53 --> Input Class Initialized
INFO - 2018-12-31 13:17:53 --> Language Class Initialized
INFO - 2018-12-31 13:17:53 --> Loader Class Initialized
INFO - 2018-12-31 13:17:53 --> Helper loaded: url_helper
INFO - 2018-12-31 13:17:53 --> Helper loaded: file_helper
INFO - 2018-12-31 13:17:53 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:17:53 --> Helper loaded: util_helper
INFO - 2018-12-31 13:17:53 --> Database Driver Class Initialized
INFO - 2018-12-31 13:17:53 --> Email Class Initialized
DEBUG - 2018-12-31 13:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:17:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:17:53 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:17:53 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:17:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:17:53 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:17:53 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:17:53 --> Helper loaded: date_helper
INFO - 2018-12-31 13:17:53 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:17:53 --> Controller Class Initialized
DEBUG - 2018-12-31 13:17:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:17:53 --> Helper loaded: form_helper
INFO - 2018-12-31 13:17:53 --> Form Validation Class Initialized
INFO - 2018-12-31 13:17:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:17:53 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:17:53 --> Final output sent to browser
DEBUG - 2018-12-31 13:17:53 --> Total execution time: 0.3684
INFO - 2018-12-31 13:17:55 --> Config Class Initialized
INFO - 2018-12-31 13:17:55 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:17:55 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:17:55 --> Utf8 Class Initialized
INFO - 2018-12-31 13:17:55 --> URI Class Initialized
INFO - 2018-12-31 13:17:55 --> Router Class Initialized
INFO - 2018-12-31 13:17:55 --> Output Class Initialized
INFO - 2018-12-31 13:17:56 --> Security Class Initialized
DEBUG - 2018-12-31 13:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:17:56 --> CSRF cookie sent
INFO - 2018-12-31 13:17:56 --> CSRF token verified
INFO - 2018-12-31 13:17:56 --> Input Class Initialized
INFO - 2018-12-31 13:17:56 --> Language Class Initialized
INFO - 2018-12-31 13:17:56 --> Loader Class Initialized
INFO - 2018-12-31 13:17:56 --> Helper loaded: url_helper
INFO - 2018-12-31 13:17:56 --> Helper loaded: file_helper
INFO - 2018-12-31 13:17:56 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:17:56 --> Helper loaded: util_helper
INFO - 2018-12-31 13:17:56 --> Database Driver Class Initialized
INFO - 2018-12-31 13:17:56 --> Email Class Initialized
DEBUG - 2018-12-31 13:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:17:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:17:56 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:17:56 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:17:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:17:56 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:17:56 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:17:56 --> Helper loaded: date_helper
INFO - 2018-12-31 13:17:56 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:17:56 --> Controller Class Initialized
DEBUG - 2018-12-31 13:17:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:17:56 --> Helper loaded: form_helper
INFO - 2018-12-31 13:17:56 --> Form Validation Class Initialized
INFO - 2018-12-31 13:17:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:17:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:17:56 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:17:56 --> Final output sent to browser
DEBUG - 2018-12-31 13:17:56 --> Total execution time: 0.3886
INFO - 2018-12-31 13:18:21 --> Config Class Initialized
INFO - 2018-12-31 13:18:21 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:18:21 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:18:21 --> Utf8 Class Initialized
INFO - 2018-12-31 13:18:21 --> URI Class Initialized
INFO - 2018-12-31 13:18:22 --> Router Class Initialized
INFO - 2018-12-31 13:18:22 --> Output Class Initialized
INFO - 2018-12-31 13:18:22 --> Security Class Initialized
DEBUG - 2018-12-31 13:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:18:22 --> CSRF cookie sent
INFO - 2018-12-31 13:18:22 --> Input Class Initialized
INFO - 2018-12-31 13:18:22 --> Language Class Initialized
INFO - 2018-12-31 13:18:22 --> Loader Class Initialized
INFO - 2018-12-31 13:18:22 --> Helper loaded: url_helper
INFO - 2018-12-31 13:18:22 --> Helper loaded: file_helper
INFO - 2018-12-31 13:18:22 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:18:22 --> Helper loaded: util_helper
INFO - 2018-12-31 13:18:22 --> Database Driver Class Initialized
INFO - 2018-12-31 13:18:22 --> Email Class Initialized
DEBUG - 2018-12-31 13:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:18:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:18:22 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:18:22 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:18:22 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:18:22 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:22 --> Helper loaded: date_helper
INFO - 2018-12-31 13:18:22 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:18:22 --> Controller Class Initialized
DEBUG - 2018-12-31 13:18:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:22 --> Helper loaded: form_helper
INFO - 2018-12-31 13:18:22 --> Form Validation Class Initialized
INFO - 2018-12-31 13:18:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:18:22 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:18:22 --> Final output sent to browser
DEBUG - 2018-12-31 13:18:22 --> Total execution time: 0.3492
INFO - 2018-12-31 13:18:28 --> Config Class Initialized
INFO - 2018-12-31 13:18:28 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:18:28 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:18:28 --> Utf8 Class Initialized
INFO - 2018-12-31 13:18:28 --> URI Class Initialized
INFO - 2018-12-31 13:18:28 --> Router Class Initialized
INFO - 2018-12-31 13:18:28 --> Output Class Initialized
INFO - 2018-12-31 13:18:28 --> Security Class Initialized
DEBUG - 2018-12-31 13:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:18:28 --> CSRF cookie sent
INFO - 2018-12-31 13:18:28 --> Input Class Initialized
INFO - 2018-12-31 13:18:28 --> Language Class Initialized
INFO - 2018-12-31 13:18:28 --> Loader Class Initialized
INFO - 2018-12-31 13:18:28 --> Helper loaded: url_helper
INFO - 2018-12-31 13:18:28 --> Helper loaded: file_helper
INFO - 2018-12-31 13:18:28 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:18:28 --> Helper loaded: util_helper
INFO - 2018-12-31 13:18:28 --> Database Driver Class Initialized
INFO - 2018-12-31 13:18:28 --> Email Class Initialized
DEBUG - 2018-12-31 13:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:18:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:18:28 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:18:28 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:18:28 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:18:28 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:28 --> Helper loaded: date_helper
INFO - 2018-12-31 13:18:28 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:18:28 --> Controller Class Initialized
DEBUG - 2018-12-31 13:18:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:28 --> Helper loaded: form_helper
INFO - 2018-12-31 13:18:28 --> Form Validation Class Initialized
INFO - 2018-12-31 13:18:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:18:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:18:28 --> Final output sent to browser
DEBUG - 2018-12-31 13:18:28 --> Total execution time: 0.3418
INFO - 2018-12-31 13:18:46 --> Config Class Initialized
INFO - 2018-12-31 13:18:46 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:18:46 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:18:46 --> Utf8 Class Initialized
INFO - 2018-12-31 13:18:46 --> URI Class Initialized
INFO - 2018-12-31 13:18:46 --> Router Class Initialized
INFO - 2018-12-31 13:18:46 --> Output Class Initialized
INFO - 2018-12-31 13:18:46 --> Security Class Initialized
DEBUG - 2018-12-31 13:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:18:46 --> CSRF cookie sent
INFO - 2018-12-31 13:18:46 --> CSRF token verified
INFO - 2018-12-31 13:18:46 --> Input Class Initialized
INFO - 2018-12-31 13:18:46 --> Language Class Initialized
INFO - 2018-12-31 13:18:46 --> Loader Class Initialized
INFO - 2018-12-31 13:18:46 --> Helper loaded: url_helper
INFO - 2018-12-31 13:18:46 --> Helper loaded: file_helper
INFO - 2018-12-31 13:18:46 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:18:46 --> Helper loaded: util_helper
INFO - 2018-12-31 13:18:46 --> Database Driver Class Initialized
INFO - 2018-12-31 13:18:46 --> Email Class Initialized
DEBUG - 2018-12-31 13:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:18:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:18:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:18:46 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:18:46 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:18:46 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:46 --> Helper loaded: date_helper
INFO - 2018-12-31 13:18:46 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:18:46 --> Controller Class Initialized
DEBUG - 2018-12-31 13:18:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:18:46 --> Helper loaded: form_helper
INFO - 2018-12-31 13:18:46 --> Form Validation Class Initialized
INFO - 2018-12-31 13:18:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:18:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:18:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:18:46 --> Final output sent to browser
DEBUG - 2018-12-31 13:18:46 --> Total execution time: 0.3800
INFO - 2018-12-31 13:19:49 --> Config Class Initialized
INFO - 2018-12-31 13:19:49 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:19:49 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:19:49 --> Utf8 Class Initialized
INFO - 2018-12-31 13:19:49 --> URI Class Initialized
INFO - 2018-12-31 13:19:49 --> Router Class Initialized
INFO - 2018-12-31 13:19:49 --> Output Class Initialized
INFO - 2018-12-31 13:19:49 --> Security Class Initialized
DEBUG - 2018-12-31 13:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:19:49 --> CSRF cookie sent
INFO - 2018-12-31 13:19:49 --> Input Class Initialized
INFO - 2018-12-31 13:19:49 --> Language Class Initialized
INFO - 2018-12-31 13:19:49 --> Loader Class Initialized
INFO - 2018-12-31 13:19:49 --> Helper loaded: url_helper
INFO - 2018-12-31 13:19:49 --> Helper loaded: file_helper
INFO - 2018-12-31 13:19:49 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:19:49 --> Helper loaded: util_helper
INFO - 2018-12-31 13:19:49 --> Database Driver Class Initialized
INFO - 2018-12-31 13:19:49 --> Email Class Initialized
DEBUG - 2018-12-31 13:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:19:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:19:49 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:19:49 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:19:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:19:49 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:19:49 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:19:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:19:49 --> Helper loaded: date_helper
INFO - 2018-12-31 13:19:49 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:19:49 --> Controller Class Initialized
DEBUG - 2018-12-31 13:19:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:19:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:19:49 --> Helper loaded: form_helper
INFO - 2018-12-31 13:19:49 --> Form Validation Class Initialized
INFO - 2018-12-31 13:19:49 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:19:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:19:49 --> Final output sent to browser
DEBUG - 2018-12-31 13:19:49 --> Total execution time: 0.3465
INFO - 2018-12-31 13:19:59 --> Config Class Initialized
INFO - 2018-12-31 13:19:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:19:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:19:59 --> Utf8 Class Initialized
INFO - 2018-12-31 13:19:59 --> URI Class Initialized
INFO - 2018-12-31 13:19:59 --> Router Class Initialized
INFO - 2018-12-31 13:19:59 --> Output Class Initialized
INFO - 2018-12-31 13:19:59 --> Security Class Initialized
DEBUG - 2018-12-31 13:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:19:59 --> CSRF cookie sent
INFO - 2018-12-31 13:19:59 --> CSRF token verified
INFO - 2018-12-31 13:19:59 --> Input Class Initialized
INFO - 2018-12-31 13:19:59 --> Language Class Initialized
INFO - 2018-12-31 13:19:59 --> Loader Class Initialized
INFO - 2018-12-31 13:19:59 --> Helper loaded: url_helper
INFO - 2018-12-31 13:19:59 --> Helper loaded: file_helper
INFO - 2018-12-31 13:19:59 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:19:59 --> Helper loaded: util_helper
INFO - 2018-12-31 13:19:59 --> Database Driver Class Initialized
INFO - 2018-12-31 13:19:59 --> Email Class Initialized
DEBUG - 2018-12-31 13:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:19:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:19:59 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:19:59 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:19:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:19:59 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:19:59 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:19:59 --> Helper loaded: date_helper
INFO - 2018-12-31 13:19:59 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:19:59 --> Controller Class Initialized
DEBUG - 2018-12-31 13:19:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:19:59 --> Helper loaded: form_helper
INFO - 2018-12-31 13:19:59 --> Form Validation Class Initialized
INFO - 2018-12-31 13:19:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:19:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:19:59 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:19:59 --> Final output sent to browser
DEBUG - 2018-12-31 13:19:59 --> Total execution time: 0.3818
INFO - 2018-12-31 13:20:17 --> Config Class Initialized
INFO - 2018-12-31 13:20:17 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:20:17 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:20:17 --> Utf8 Class Initialized
INFO - 2018-12-31 13:20:17 --> URI Class Initialized
INFO - 2018-12-31 13:20:17 --> Router Class Initialized
INFO - 2018-12-31 13:20:17 --> Output Class Initialized
INFO - 2018-12-31 13:20:17 --> Security Class Initialized
DEBUG - 2018-12-31 13:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:20:17 --> CSRF cookie sent
INFO - 2018-12-31 13:20:17 --> Input Class Initialized
INFO - 2018-12-31 13:20:17 --> Language Class Initialized
INFO - 2018-12-31 13:20:17 --> Loader Class Initialized
INFO - 2018-12-31 13:20:17 --> Helper loaded: url_helper
INFO - 2018-12-31 13:20:17 --> Helper loaded: file_helper
INFO - 2018-12-31 13:20:17 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:20:17 --> Helper loaded: util_helper
INFO - 2018-12-31 13:20:17 --> Database Driver Class Initialized
INFO - 2018-12-31 13:20:17 --> Email Class Initialized
DEBUG - 2018-12-31 13:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:20:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:20:17 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:20:18 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:20:18 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:20:18 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:20:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:18 --> Helper loaded: date_helper
INFO - 2018-12-31 13:20:18 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:20:18 --> Controller Class Initialized
DEBUG - 2018-12-31 13:20:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:20:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:18 --> Helper loaded: form_helper
INFO - 2018-12-31 13:20:18 --> Form Validation Class Initialized
INFO - 2018-12-31 13:20:18 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:20:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:20:18 --> Final output sent to browser
DEBUG - 2018-12-31 13:20:18 --> Total execution time: 0.3591
INFO - 2018-12-31 13:20:23 --> Config Class Initialized
INFO - 2018-12-31 13:20:23 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:20:23 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:20:23 --> Utf8 Class Initialized
INFO - 2018-12-31 13:20:23 --> URI Class Initialized
INFO - 2018-12-31 13:20:23 --> Router Class Initialized
INFO - 2018-12-31 13:20:23 --> Output Class Initialized
INFO - 2018-12-31 13:20:23 --> Security Class Initialized
DEBUG - 2018-12-31 13:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:20:23 --> CSRF cookie sent
INFO - 2018-12-31 13:20:23 --> CSRF token verified
INFO - 2018-12-31 13:20:23 --> Input Class Initialized
INFO - 2018-12-31 13:20:23 --> Language Class Initialized
INFO - 2018-12-31 13:20:23 --> Loader Class Initialized
INFO - 2018-12-31 13:20:23 --> Helper loaded: url_helper
INFO - 2018-12-31 13:20:23 --> Helper loaded: file_helper
INFO - 2018-12-31 13:20:23 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:20:23 --> Helper loaded: util_helper
INFO - 2018-12-31 13:20:23 --> Database Driver Class Initialized
INFO - 2018-12-31 13:20:23 --> Email Class Initialized
DEBUG - 2018-12-31 13:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:20:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:20:24 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:20:24 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:20:24 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:20:24 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:24 --> Helper loaded: date_helper
INFO - 2018-12-31 13:20:24 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:20:24 --> Controller Class Initialized
DEBUG - 2018-12-31 13:20:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:24 --> Helper loaded: form_helper
INFO - 2018-12-31 13:20:24 --> Form Validation Class Initialized
INFO - 2018-12-31 13:20:24 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:20:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:20:24 --> Config Class Initialized
INFO - 2018-12-31 13:20:24 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:20:24 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:20:24 --> Utf8 Class Initialized
INFO - 2018-12-31 13:20:24 --> URI Class Initialized
INFO - 2018-12-31 13:20:24 --> Router Class Initialized
INFO - 2018-12-31 13:20:24 --> Output Class Initialized
INFO - 2018-12-31 13:20:24 --> Security Class Initialized
DEBUG - 2018-12-31 13:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:20:24 --> CSRF cookie sent
INFO - 2018-12-31 13:20:24 --> Input Class Initialized
INFO - 2018-12-31 13:20:24 --> Language Class Initialized
INFO - 2018-12-31 13:20:24 --> Loader Class Initialized
INFO - 2018-12-31 13:20:24 --> Helper loaded: url_helper
INFO - 2018-12-31 13:20:24 --> Helper loaded: file_helper
INFO - 2018-12-31 13:20:24 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:20:24 --> Helper loaded: util_helper
INFO - 2018-12-31 13:20:24 --> Database Driver Class Initialized
INFO - 2018-12-31 13:20:24 --> Email Class Initialized
DEBUG - 2018-12-31 13:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:20:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:20:24 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:20:24 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:20:24 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:20:24 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:24 --> Helper loaded: date_helper
INFO - 2018-12-31 13:20:24 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:20:24 --> Controller Class Initialized
DEBUG - 2018-12-31 13:20:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:20:24 --> Helper loaded: form_helper
INFO - 2018-12-31 13:20:24 --> Form Validation Class Initialized
INFO - 2018-12-31 13:20:24 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:20:24 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:20:24 --> Final output sent to browser
DEBUG - 2018-12-31 13:20:24 --> Total execution time: 0.3354
INFO - 2018-12-31 13:22:46 --> Config Class Initialized
INFO - 2018-12-31 13:22:46 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:22:46 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:22:46 --> Utf8 Class Initialized
INFO - 2018-12-31 13:22:46 --> URI Class Initialized
DEBUG - 2018-12-31 13:22:46 --> No URI present. Default controller set.
INFO - 2018-12-31 13:22:46 --> Router Class Initialized
INFO - 2018-12-31 13:22:46 --> Output Class Initialized
INFO - 2018-12-31 13:22:46 --> Security Class Initialized
DEBUG - 2018-12-31 13:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:22:46 --> CSRF cookie sent
INFO - 2018-12-31 13:22:46 --> Input Class Initialized
INFO - 2018-12-31 13:22:46 --> Language Class Initialized
INFO - 2018-12-31 13:22:46 --> Loader Class Initialized
INFO - 2018-12-31 13:22:46 --> Helper loaded: url_helper
INFO - 2018-12-31 13:22:46 --> Helper loaded: file_helper
INFO - 2018-12-31 13:22:46 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:22:46 --> Helper loaded: util_helper
INFO - 2018-12-31 13:22:46 --> Database Driver Class Initialized
INFO - 2018-12-31 13:22:46 --> Email Class Initialized
DEBUG - 2018-12-31 13:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:22:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:22:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:22:46 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:22:46 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:22:46 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:46 --> Helper loaded: date_helper
INFO - 2018-12-31 13:22:46 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:22:46 --> Controller Class Initialized
INFO - 2018-12-31 13:22:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:22:46 --> Final output sent to browser
DEBUG - 2018-12-31 13:22:46 --> Total execution time: 0.3317
INFO - 2018-12-31 13:22:53 --> Config Class Initialized
INFO - 2018-12-31 13:22:53 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:22:53 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:22:53 --> Utf8 Class Initialized
INFO - 2018-12-31 13:22:53 --> URI Class Initialized
INFO - 2018-12-31 13:22:53 --> Router Class Initialized
INFO - 2018-12-31 13:22:53 --> Output Class Initialized
INFO - 2018-12-31 13:22:53 --> Security Class Initialized
DEBUG - 2018-12-31 13:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:22:53 --> CSRF cookie sent
INFO - 2018-12-31 13:22:53 --> Input Class Initialized
INFO - 2018-12-31 13:22:53 --> Language Class Initialized
INFO - 2018-12-31 13:22:53 --> Loader Class Initialized
INFO - 2018-12-31 13:22:53 --> Helper loaded: url_helper
INFO - 2018-12-31 13:22:53 --> Helper loaded: file_helper
INFO - 2018-12-31 13:22:53 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:22:53 --> Helper loaded: util_helper
INFO - 2018-12-31 13:22:53 --> Database Driver Class Initialized
INFO - 2018-12-31 13:22:53 --> Email Class Initialized
DEBUG - 2018-12-31 13:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:22:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:22:53 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:22:53 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:22:53 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:22:53 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:53 --> Helper loaded: date_helper
INFO - 2018-12-31 13:22:53 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:22:53 --> Controller Class Initialized
DEBUG - 2018-12-31 13:22:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:53 --> Helper loaded: form_helper
INFO - 2018-12-31 13:22:53 --> Form Validation Class Initialized
INFO - 2018-12-31 13:22:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:22:53 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:22:53 --> Final output sent to browser
DEBUG - 2018-12-31 13:22:53 --> Total execution time: 0.3622
INFO - 2018-12-31 13:22:55 --> Config Class Initialized
INFO - 2018-12-31 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:22:55 --> Utf8 Class Initialized
INFO - 2018-12-31 13:22:55 --> URI Class Initialized
INFO - 2018-12-31 13:22:55 --> Router Class Initialized
INFO - 2018-12-31 13:22:55 --> Output Class Initialized
INFO - 2018-12-31 13:22:55 --> Security Class Initialized
DEBUG - 2018-12-31 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:22:55 --> CSRF cookie sent
INFO - 2018-12-31 13:22:55 --> CSRF token verified
INFO - 2018-12-31 13:22:55 --> Input Class Initialized
INFO - 2018-12-31 13:22:55 --> Language Class Initialized
INFO - 2018-12-31 13:22:55 --> Loader Class Initialized
INFO - 2018-12-31 13:22:55 --> Helper loaded: url_helper
INFO - 2018-12-31 13:22:55 --> Helper loaded: file_helper
INFO - 2018-12-31 13:22:55 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:22:55 --> Helper loaded: util_helper
INFO - 2018-12-31 13:22:55 --> Database Driver Class Initialized
INFO - 2018-12-31 13:22:55 --> Email Class Initialized
DEBUG - 2018-12-31 13:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:22:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:22:55 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:22:55 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:22:55 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:22:55 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:55 --> Helper loaded: date_helper
INFO - 2018-12-31 13:22:55 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:22:55 --> Controller Class Initialized
DEBUG - 2018-12-31 13:22:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:56 --> Helper loaded: form_helper
INFO - 2018-12-31 13:22:56 --> Form Validation Class Initialized
INFO - 2018-12-31 13:22:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:22:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:22:56 --> Config Class Initialized
INFO - 2018-12-31 13:22:56 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:22:56 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:22:56 --> Utf8 Class Initialized
INFO - 2018-12-31 13:22:56 --> URI Class Initialized
DEBUG - 2018-12-31 13:22:56 --> No URI present. Default controller set.
INFO - 2018-12-31 13:22:56 --> Router Class Initialized
INFO - 2018-12-31 13:22:56 --> Output Class Initialized
INFO - 2018-12-31 13:22:56 --> Security Class Initialized
DEBUG - 2018-12-31 13:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:22:56 --> CSRF cookie sent
INFO - 2018-12-31 13:22:56 --> Input Class Initialized
INFO - 2018-12-31 13:22:56 --> Language Class Initialized
INFO - 2018-12-31 13:22:56 --> Loader Class Initialized
INFO - 2018-12-31 13:22:56 --> Helper loaded: url_helper
INFO - 2018-12-31 13:22:56 --> Helper loaded: file_helper
INFO - 2018-12-31 13:22:56 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:22:56 --> Helper loaded: util_helper
INFO - 2018-12-31 13:22:56 --> Database Driver Class Initialized
INFO - 2018-12-31 13:22:56 --> Email Class Initialized
DEBUG - 2018-12-31 13:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:22:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:22:56 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:22:56 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:22:56 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:22:56 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:22:56 --> Helper loaded: date_helper
INFO - 2018-12-31 13:22:56 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:22:56 --> Controller Class Initialized
INFO - 2018-12-31 13:22:56 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:22:56 --> Final output sent to browser
DEBUG - 2018-12-31 13:22:56 --> Total execution time: 0.3053
INFO - 2018-12-31 13:22:59 --> Config Class Initialized
INFO - 2018-12-31 13:22:59 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:22:59 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:22:59 --> Utf8 Class Initialized
INFO - 2018-12-31 13:22:59 --> URI Class Initialized
INFO - 2018-12-31 13:22:59 --> Router Class Initialized
INFO - 2018-12-31 13:22:59 --> Output Class Initialized
INFO - 2018-12-31 13:22:59 --> Security Class Initialized
DEBUG - 2018-12-31 13:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:22:59 --> CSRF cookie sent
INFO - 2018-12-31 13:22:59 --> Input Class Initialized
INFO - 2018-12-31 13:22:59 --> Language Class Initialized
INFO - 2018-12-31 13:22:59 --> Loader Class Initialized
INFO - 2018-12-31 13:22:59 --> Helper loaded: url_helper
INFO - 2018-12-31 13:22:59 --> Helper loaded: file_helper
INFO - 2018-12-31 13:23:00 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:23:00 --> Helper loaded: util_helper
INFO - 2018-12-31 13:23:00 --> Database Driver Class Initialized
INFO - 2018-12-31 13:23:00 --> Email Class Initialized
DEBUG - 2018-12-31 13:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:23:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:23:00 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:23:00 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:23:00 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:23:00 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:00 --> Helper loaded: date_helper
INFO - 2018-12-31 13:23:00 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:23:00 --> Controller Class Initialized
DEBUG - 2018-12-31 13:23:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:00 --> Helper loaded: form_helper
INFO - 2018-12-31 13:23:00 --> Form Validation Class Initialized
INFO - 2018-12-31 13:23:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:23:00 --> Config Class Initialized
INFO - 2018-12-31 13:23:00 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:23:00 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:23:00 --> Utf8 Class Initialized
INFO - 2018-12-31 13:23:00 --> URI Class Initialized
INFO - 2018-12-31 13:23:00 --> Router Class Initialized
INFO - 2018-12-31 13:23:00 --> Output Class Initialized
INFO - 2018-12-31 13:23:00 --> Security Class Initialized
DEBUG - 2018-12-31 13:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:23:00 --> CSRF cookie sent
INFO - 2018-12-31 13:23:00 --> Input Class Initialized
INFO - 2018-12-31 13:23:00 --> Language Class Initialized
INFO - 2018-12-31 13:23:00 --> Loader Class Initialized
INFO - 2018-12-31 13:23:00 --> Helper loaded: url_helper
INFO - 2018-12-31 13:23:00 --> Helper loaded: file_helper
INFO - 2018-12-31 13:23:00 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:23:00 --> Helper loaded: util_helper
INFO - 2018-12-31 13:23:00 --> Database Driver Class Initialized
INFO - 2018-12-31 13:23:00 --> Email Class Initialized
DEBUG - 2018-12-31 13:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:23:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:23:00 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:23:00 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:23:00 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:23:00 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:00 --> Helper loaded: date_helper
INFO - 2018-12-31 13:23:00 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:23:00 --> Controller Class Initialized
DEBUG - 2018-12-31 13:23:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:00 --> Helper loaded: form_helper
INFO - 2018-12-31 13:23:00 --> Form Validation Class Initialized
INFO - 2018-12-31 13:23:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:23:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:23:00 --> Final output sent to browser
DEBUG - 2018-12-31 13:23:00 --> Total execution time: 0.3338
INFO - 2018-12-31 13:23:08 --> Config Class Initialized
INFO - 2018-12-31 13:23:08 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:23:08 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:23:08 --> Utf8 Class Initialized
INFO - 2018-12-31 13:23:08 --> URI Class Initialized
DEBUG - 2018-12-31 13:23:08 --> No URI present. Default controller set.
INFO - 2018-12-31 13:23:08 --> Router Class Initialized
INFO - 2018-12-31 13:23:08 --> Output Class Initialized
INFO - 2018-12-31 13:23:08 --> Security Class Initialized
DEBUG - 2018-12-31 13:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:23:08 --> CSRF cookie sent
INFO - 2018-12-31 13:23:08 --> Input Class Initialized
INFO - 2018-12-31 13:23:08 --> Language Class Initialized
INFO - 2018-12-31 13:23:08 --> Loader Class Initialized
INFO - 2018-12-31 13:23:08 --> Helper loaded: url_helper
INFO - 2018-12-31 13:23:08 --> Helper loaded: file_helper
INFO - 2018-12-31 13:23:08 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:23:08 --> Helper loaded: util_helper
INFO - 2018-12-31 13:23:08 --> Database Driver Class Initialized
INFO - 2018-12-31 13:23:08 --> Email Class Initialized
DEBUG - 2018-12-31 13:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:23:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:23:08 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:23:08 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:23:08 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:23:08 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:23:08 --> Helper loaded: date_helper
INFO - 2018-12-31 13:23:08 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:23:08 --> Controller Class Initialized
INFO - 2018-12-31 13:23:08 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:23:08 --> Final output sent to browser
DEBUG - 2018-12-31 13:23:08 --> Total execution time: 0.3478
INFO - 2018-12-31 13:32:35 --> Config Class Initialized
INFO - 2018-12-31 13:32:35 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:32:35 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:32:35 --> Utf8 Class Initialized
INFO - 2018-12-31 13:32:35 --> URI Class Initialized
DEBUG - 2018-12-31 13:32:35 --> No URI present. Default controller set.
INFO - 2018-12-31 13:32:35 --> Router Class Initialized
INFO - 2018-12-31 13:32:35 --> Output Class Initialized
INFO - 2018-12-31 13:32:35 --> Security Class Initialized
DEBUG - 2018-12-31 13:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:32:35 --> CSRF cookie sent
INFO - 2018-12-31 13:32:35 --> Input Class Initialized
INFO - 2018-12-31 13:32:35 --> Language Class Initialized
INFO - 2018-12-31 13:32:35 --> Loader Class Initialized
INFO - 2018-12-31 13:32:35 --> Helper loaded: url_helper
INFO - 2018-12-31 13:32:35 --> Helper loaded: file_helper
INFO - 2018-12-31 13:32:35 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:32:35 --> Helper loaded: util_helper
INFO - 2018-12-31 13:32:35 --> Database Driver Class Initialized
INFO - 2018-12-31 13:32:35 --> Email Class Initialized
DEBUG - 2018-12-31 13:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:32:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:32:35 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:32:35 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:32:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:32:35 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:32:35 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:32:35 --> Helper loaded: date_helper
INFO - 2018-12-31 13:32:35 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:32:35 --> Controller Class Initialized
INFO - 2018-12-31 13:32:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:32:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:32:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:32:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:32:35 --> Final output sent to browser
DEBUG - 2018-12-31 13:32:35 --> Total execution time: 0.3600
INFO - 2018-12-31 13:32:49 --> Config Class Initialized
INFO - 2018-12-31 13:32:49 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:32:49 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:32:49 --> Utf8 Class Initialized
INFO - 2018-12-31 13:32:50 --> URI Class Initialized
DEBUG - 2018-12-31 13:32:50 --> No URI present. Default controller set.
INFO - 2018-12-31 13:32:50 --> Router Class Initialized
INFO - 2018-12-31 13:32:50 --> Output Class Initialized
INFO - 2018-12-31 13:32:50 --> Security Class Initialized
DEBUG - 2018-12-31 13:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:32:50 --> CSRF cookie sent
INFO - 2018-12-31 13:32:50 --> Input Class Initialized
INFO - 2018-12-31 13:32:50 --> Language Class Initialized
INFO - 2018-12-31 13:32:50 --> Loader Class Initialized
INFO - 2018-12-31 13:32:50 --> Helper loaded: url_helper
INFO - 2018-12-31 13:32:50 --> Helper loaded: file_helper
INFO - 2018-12-31 13:32:50 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:32:50 --> Helper loaded: util_helper
INFO - 2018-12-31 13:32:50 --> Database Driver Class Initialized
INFO - 2018-12-31 13:32:50 --> Email Class Initialized
DEBUG - 2018-12-31 13:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:32:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:32:50 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:32:50 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:32:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:32:50 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:32:50 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:32:50 --> Helper loaded: date_helper
INFO - 2018-12-31 13:32:50 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:32:50 --> Controller Class Initialized
INFO - 2018-12-31 13:32:50 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:32:50 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:32:50 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:32:50 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:32:50 --> Final output sent to browser
DEBUG - 2018-12-31 13:32:50 --> Total execution time: 0.3508
INFO - 2018-12-31 13:32:55 --> Config Class Initialized
INFO - 2018-12-31 13:32:55 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:32:55 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:32:55 --> Utf8 Class Initialized
INFO - 2018-12-31 13:32:55 --> URI Class Initialized
INFO - 2018-12-31 13:32:55 --> Router Class Initialized
INFO - 2018-12-31 13:32:55 --> Output Class Initialized
INFO - 2018-12-31 13:32:55 --> Security Class Initialized
DEBUG - 2018-12-31 13:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:32:55 --> CSRF cookie sent
INFO - 2018-12-31 13:32:55 --> Input Class Initialized
INFO - 2018-12-31 13:32:55 --> Language Class Initialized
INFO - 2018-12-31 13:32:55 --> Loader Class Initialized
INFO - 2018-12-31 13:32:55 --> Helper loaded: url_helper
INFO - 2018-12-31 13:32:55 --> Helper loaded: file_helper
INFO - 2018-12-31 13:32:55 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:32:55 --> Helper loaded: util_helper
INFO - 2018-12-31 13:32:55 --> Database Driver Class Initialized
INFO - 2018-12-31 13:32:55 --> Email Class Initialized
DEBUG - 2018-12-31 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:32:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:32:55 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:32:55 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:32:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:32:55 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:32:55 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:32:55 --> Helper loaded: date_helper
INFO - 2018-12-31 13:32:55 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:32:55 --> Controller Class Initialized
DEBUG - 2018-12-31 13:32:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:32:55 --> Helper loaded: form_helper
INFO - 2018-12-31 13:32:55 --> Form Validation Class Initialized
INFO - 2018-12-31 13:32:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:32:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:32:55 --> Final output sent to browser
DEBUG - 2018-12-31 13:32:55 --> Total execution time: 0.3790
INFO - 2018-12-31 13:35:21 --> Config Class Initialized
INFO - 2018-12-31 13:35:21 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:35:21 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:35:21 --> Utf8 Class Initialized
INFO - 2018-12-31 13:35:21 --> URI Class Initialized
INFO - 2018-12-31 13:35:21 --> Router Class Initialized
INFO - 2018-12-31 13:35:21 --> Output Class Initialized
INFO - 2018-12-31 13:35:21 --> Security Class Initialized
DEBUG - 2018-12-31 13:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:35:21 --> CSRF cookie sent
INFO - 2018-12-31 13:35:21 --> Input Class Initialized
INFO - 2018-12-31 13:35:21 --> Language Class Initialized
INFO - 2018-12-31 13:35:21 --> Loader Class Initialized
INFO - 2018-12-31 13:35:22 --> Helper loaded: url_helper
INFO - 2018-12-31 13:35:22 --> Helper loaded: file_helper
INFO - 2018-12-31 13:35:22 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:35:22 --> Helper loaded: util_helper
INFO - 2018-12-31 13:35:22 --> Database Driver Class Initialized
INFO - 2018-12-31 13:35:22 --> Email Class Initialized
DEBUG - 2018-12-31 13:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:35:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:35:22 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:35:22 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:35:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:35:22 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:35:22 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:35:22 --> Helper loaded: date_helper
INFO - 2018-12-31 13:35:22 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:35:22 --> Controller Class Initialized
DEBUG - 2018-12-31 13:35:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:35:22 --> Helper loaded: form_helper
INFO - 2018-12-31 13:35:22 --> Form Validation Class Initialized
INFO - 2018-12-31 13:35:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:35:22 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:35:22 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:35:22 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:35:22 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:35:22 --> Final output sent to browser
DEBUG - 2018-12-31 13:35:22 --> Total execution time: 0.3758
INFO - 2018-12-31 13:36:14 --> Config Class Initialized
INFO - 2018-12-31 13:36:14 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:36:14 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:36:14 --> Utf8 Class Initialized
INFO - 2018-12-31 13:36:14 --> URI Class Initialized
INFO - 2018-12-31 13:36:14 --> Router Class Initialized
INFO - 2018-12-31 13:36:14 --> Output Class Initialized
INFO - 2018-12-31 13:36:14 --> Security Class Initialized
DEBUG - 2018-12-31 13:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:36:14 --> CSRF cookie sent
INFO - 2018-12-31 13:36:14 --> Input Class Initialized
INFO - 2018-12-31 13:36:14 --> Language Class Initialized
INFO - 2018-12-31 13:36:14 --> Loader Class Initialized
INFO - 2018-12-31 13:36:14 --> Helper loaded: url_helper
INFO - 2018-12-31 13:36:14 --> Helper loaded: file_helper
INFO - 2018-12-31 13:36:14 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:36:14 --> Helper loaded: util_helper
INFO - 2018-12-31 13:36:14 --> Database Driver Class Initialized
INFO - 2018-12-31 13:36:14 --> Email Class Initialized
DEBUG - 2018-12-31 13:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:36:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:36:14 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:36:14 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:36:14 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:36:14 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:15 --> Helper loaded: date_helper
INFO - 2018-12-31 13:36:15 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:36:15 --> Controller Class Initialized
DEBUG - 2018-12-31 13:36:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:15 --> Helper loaded: form_helper
INFO - 2018-12-31 13:36:15 --> Form Validation Class Initialized
INFO - 2018-12-31 13:36:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:36:15 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:36:15 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:36:15 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:36:15 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:36:15 --> Final output sent to browser
DEBUG - 2018-12-31 13:36:15 --> Total execution time: 0.3877
INFO - 2018-12-31 13:36:44 --> Config Class Initialized
INFO - 2018-12-31 13:36:44 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:36:44 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:36:44 --> Utf8 Class Initialized
INFO - 2018-12-31 13:36:44 --> URI Class Initialized
INFO - 2018-12-31 13:36:44 --> Router Class Initialized
INFO - 2018-12-31 13:36:44 --> Output Class Initialized
INFO - 2018-12-31 13:36:44 --> Security Class Initialized
DEBUG - 2018-12-31 13:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:36:44 --> CSRF cookie sent
INFO - 2018-12-31 13:36:44 --> Input Class Initialized
INFO - 2018-12-31 13:36:44 --> Language Class Initialized
INFO - 2018-12-31 13:36:44 --> Loader Class Initialized
INFO - 2018-12-31 13:36:44 --> Helper loaded: url_helper
INFO - 2018-12-31 13:36:44 --> Helper loaded: file_helper
INFO - 2018-12-31 13:36:44 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:36:44 --> Helper loaded: util_helper
INFO - 2018-12-31 13:36:44 --> Database Driver Class Initialized
INFO - 2018-12-31 13:36:44 --> Email Class Initialized
DEBUG - 2018-12-31 13:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:36:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:36:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:36:44 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:36:44 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:36:44 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:44 --> Helper loaded: date_helper
INFO - 2018-12-31 13:36:44 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:36:44 --> Controller Class Initialized
DEBUG - 2018-12-31 13:36:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:44 --> Helper loaded: form_helper
INFO - 2018-12-31 13:36:44 --> Form Validation Class Initialized
INFO - 2018-12-31 13:36:44 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:36:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:36:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:36:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:36:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:36:44 --> Final output sent to browser
DEBUG - 2018-12-31 13:36:44 --> Total execution time: 0.3863
INFO - 2018-12-31 13:36:53 --> Config Class Initialized
INFO - 2018-12-31 13:36:53 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:36:53 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:36:53 --> Utf8 Class Initialized
INFO - 2018-12-31 13:36:53 --> URI Class Initialized
INFO - 2018-12-31 13:36:53 --> Router Class Initialized
INFO - 2018-12-31 13:36:53 --> Output Class Initialized
INFO - 2018-12-31 13:36:53 --> Security Class Initialized
DEBUG - 2018-12-31 13:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:36:53 --> CSRF cookie sent
INFO - 2018-12-31 13:36:53 --> CSRF token verified
INFO - 2018-12-31 13:36:53 --> Input Class Initialized
INFO - 2018-12-31 13:36:53 --> Language Class Initialized
INFO - 2018-12-31 13:36:53 --> Loader Class Initialized
INFO - 2018-12-31 13:36:53 --> Helper loaded: url_helper
INFO - 2018-12-31 13:36:53 --> Helper loaded: file_helper
INFO - 2018-12-31 13:36:53 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:36:53 --> Helper loaded: util_helper
INFO - 2018-12-31 13:36:54 --> Database Driver Class Initialized
INFO - 2018-12-31 13:36:54 --> Email Class Initialized
DEBUG - 2018-12-31 13:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:36:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:36:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:36:54 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:36:54 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:36:54 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:54 --> Helper loaded: date_helper
INFO - 2018-12-31 13:36:54 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:36:54 --> Controller Class Initialized
DEBUG - 2018-12-31 13:36:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:54 --> Helper loaded: form_helper
INFO - 2018-12-31 13:36:54 --> Form Validation Class Initialized
INFO - 2018-12-31 13:36:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:36:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:36:54 --> Config Class Initialized
INFO - 2018-12-31 13:36:54 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:36:54 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:36:54 --> Utf8 Class Initialized
INFO - 2018-12-31 13:36:54 --> URI Class Initialized
INFO - 2018-12-31 13:36:54 --> Router Class Initialized
INFO - 2018-12-31 13:36:54 --> Output Class Initialized
INFO - 2018-12-31 13:36:54 --> Security Class Initialized
DEBUG - 2018-12-31 13:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:36:54 --> CSRF cookie sent
INFO - 2018-12-31 13:36:54 --> Input Class Initialized
INFO - 2018-12-31 13:36:54 --> Language Class Initialized
INFO - 2018-12-31 13:36:54 --> Loader Class Initialized
INFO - 2018-12-31 13:36:54 --> Helper loaded: url_helper
INFO - 2018-12-31 13:36:54 --> Helper loaded: file_helper
INFO - 2018-12-31 13:36:54 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:36:54 --> Helper loaded: util_helper
INFO - 2018-12-31 13:36:54 --> Database Driver Class Initialized
INFO - 2018-12-31 13:36:54 --> Email Class Initialized
DEBUG - 2018-12-31 13:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:36:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:36:55 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:36:55 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:36:55 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:36:55 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:36:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:55 --> Helper loaded: date_helper
INFO - 2018-12-31 13:36:55 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:36:55 --> Controller Class Initialized
DEBUG - 2018-12-31 13:36:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:36:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:36:55 --> Helper loaded: form_helper
INFO - 2018-12-31 13:36:55 --> Form Validation Class Initialized
INFO - 2018-12-31 13:36:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:36:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:36:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:36:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:36:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:36:55 --> Final output sent to browser
DEBUG - 2018-12-31 13:36:55 --> Total execution time: 0.3883
INFO - 2018-12-31 13:37:10 --> Config Class Initialized
INFO - 2018-12-31 13:37:10 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:37:10 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:37:10 --> Utf8 Class Initialized
INFO - 2018-12-31 13:37:10 --> URI Class Initialized
INFO - 2018-12-31 13:37:10 --> Router Class Initialized
INFO - 2018-12-31 13:37:10 --> Output Class Initialized
INFO - 2018-12-31 13:37:10 --> Security Class Initialized
DEBUG - 2018-12-31 13:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:37:10 --> CSRF cookie sent
INFO - 2018-12-31 13:37:10 --> Input Class Initialized
INFO - 2018-12-31 13:37:10 --> Language Class Initialized
INFO - 2018-12-31 13:37:10 --> Loader Class Initialized
INFO - 2018-12-31 13:37:10 --> Helper loaded: url_helper
INFO - 2018-12-31 13:37:10 --> Helper loaded: file_helper
INFO - 2018-12-31 13:37:10 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:37:10 --> Helper loaded: util_helper
INFO - 2018-12-31 13:37:11 --> Database Driver Class Initialized
INFO - 2018-12-31 13:37:11 --> Email Class Initialized
DEBUG - 2018-12-31 13:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:37:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:37:11 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:37:11 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:37:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:37:11 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:37:11 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:37:11 --> Helper loaded: date_helper
INFO - 2018-12-31 13:37:11 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:37:11 --> Controller Class Initialized
DEBUG - 2018-12-31 13:37:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:37:11 --> Helper loaded: form_helper
INFO - 2018-12-31 13:37:11 --> Form Validation Class Initialized
INFO - 2018-12-31 13:37:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:37:11 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:37:11 --> Final output sent to browser
DEBUG - 2018-12-31 13:37:11 --> Total execution time: 0.3730
INFO - 2018-12-31 13:39:26 --> Config Class Initialized
INFO - 2018-12-31 13:39:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:39:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:39:26 --> Utf8 Class Initialized
INFO - 2018-12-31 13:39:26 --> URI Class Initialized
INFO - 2018-12-31 13:39:26 --> Router Class Initialized
INFO - 2018-12-31 13:39:26 --> Output Class Initialized
INFO - 2018-12-31 13:39:26 --> Security Class Initialized
DEBUG - 2018-12-31 13:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:39:26 --> CSRF cookie sent
INFO - 2018-12-31 13:39:26 --> Input Class Initialized
INFO - 2018-12-31 13:39:26 --> Language Class Initialized
INFO - 2018-12-31 13:39:26 --> Loader Class Initialized
INFO - 2018-12-31 13:39:26 --> Helper loaded: url_helper
INFO - 2018-12-31 13:39:26 --> Helper loaded: file_helper
INFO - 2018-12-31 13:39:26 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:39:26 --> Helper loaded: util_helper
INFO - 2018-12-31 13:39:26 --> Database Driver Class Initialized
INFO - 2018-12-31 13:39:26 --> Email Class Initialized
DEBUG - 2018-12-31 13:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:39:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:39:27 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:39:27 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:39:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:39:27 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:39:27 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:39:27 --> Helper loaded: date_helper
INFO - 2018-12-31 13:39:27 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:39:27 --> Controller Class Initialized
DEBUG - 2018-12-31 13:39:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:39:27 --> Helper loaded: form_helper
INFO - 2018-12-31 13:39:27 --> Form Validation Class Initialized
INFO - 2018-12-31 13:39:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:39:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:39:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:39:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:39:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:39:27 --> Final output sent to browser
DEBUG - 2018-12-31 13:39:27 --> Total execution time: 0.3725
INFO - 2018-12-31 13:39:31 --> Config Class Initialized
INFO - 2018-12-31 13:39:31 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:39:31 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:39:31 --> Utf8 Class Initialized
INFO - 2018-12-31 13:39:31 --> URI Class Initialized
DEBUG - 2018-12-31 13:39:31 --> No URI present. Default controller set.
INFO - 2018-12-31 13:39:31 --> Router Class Initialized
INFO - 2018-12-31 13:39:31 --> Output Class Initialized
INFO - 2018-12-31 13:39:31 --> Security Class Initialized
DEBUG - 2018-12-31 13:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:39:31 --> CSRF cookie sent
INFO - 2018-12-31 13:39:31 --> Input Class Initialized
INFO - 2018-12-31 13:39:31 --> Language Class Initialized
INFO - 2018-12-31 13:39:31 --> Loader Class Initialized
INFO - 2018-12-31 13:39:31 --> Helper loaded: url_helper
INFO - 2018-12-31 13:39:31 --> Helper loaded: file_helper
INFO - 2018-12-31 13:39:31 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:39:31 --> Helper loaded: util_helper
INFO - 2018-12-31 13:39:31 --> Database Driver Class Initialized
INFO - 2018-12-31 13:39:31 --> Email Class Initialized
DEBUG - 2018-12-31 13:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:39:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:39:31 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:39:31 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:39:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:39:31 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:39:31 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:39:31 --> Helper loaded: date_helper
INFO - 2018-12-31 13:39:31 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:39:31 --> Controller Class Initialized
INFO - 2018-12-31 13:39:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:39:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:39:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:39:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:39:31 --> Final output sent to browser
DEBUG - 2018-12-31 13:39:31 --> Total execution time: 0.3359
INFO - 2018-12-31 13:47:42 --> Config Class Initialized
INFO - 2018-12-31 13:47:42 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:47:42 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:47:42 --> Utf8 Class Initialized
INFO - 2018-12-31 13:47:42 --> URI Class Initialized
DEBUG - 2018-12-31 13:47:42 --> No URI present. Default controller set.
INFO - 2018-12-31 13:47:42 --> Router Class Initialized
INFO - 2018-12-31 13:47:42 --> Output Class Initialized
INFO - 2018-12-31 13:47:42 --> Security Class Initialized
DEBUG - 2018-12-31 13:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:47:43 --> CSRF cookie sent
INFO - 2018-12-31 13:47:43 --> Input Class Initialized
INFO - 2018-12-31 13:47:43 --> Language Class Initialized
INFO - 2018-12-31 13:47:43 --> Loader Class Initialized
INFO - 2018-12-31 13:47:43 --> Helper loaded: url_helper
INFO - 2018-12-31 13:47:43 --> Helper loaded: file_helper
INFO - 2018-12-31 13:47:43 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:47:43 --> Helper loaded: util_helper
INFO - 2018-12-31 13:47:43 --> Database Driver Class Initialized
INFO - 2018-12-31 13:47:43 --> Email Class Initialized
DEBUG - 2018-12-31 13:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:47:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:47:43 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:47:43 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:47:43 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:47:43 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:43 --> Helper loaded: date_helper
INFO - 2018-12-31 13:47:43 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:47:43 --> Controller Class Initialized
INFO - 2018-12-31 13:47:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:47:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:47:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:47:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:47:43 --> Final output sent to browser
DEBUG - 2018-12-31 13:47:43 --> Total execution time: 0.3944
INFO - 2018-12-31 13:47:48 --> Config Class Initialized
INFO - 2018-12-31 13:47:48 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:47:48 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:47:48 --> Utf8 Class Initialized
INFO - 2018-12-31 13:47:48 --> URI Class Initialized
INFO - 2018-12-31 13:47:48 --> Router Class Initialized
INFO - 2018-12-31 13:47:48 --> Output Class Initialized
INFO - 2018-12-31 13:47:48 --> Security Class Initialized
DEBUG - 2018-12-31 13:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:47:48 --> CSRF cookie sent
INFO - 2018-12-31 13:47:48 --> Input Class Initialized
INFO - 2018-12-31 13:47:48 --> Language Class Initialized
INFO - 2018-12-31 13:47:48 --> Loader Class Initialized
INFO - 2018-12-31 13:47:48 --> Helper loaded: url_helper
INFO - 2018-12-31 13:47:48 --> Helper loaded: file_helper
INFO - 2018-12-31 13:47:48 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:47:48 --> Helper loaded: util_helper
INFO - 2018-12-31 13:47:48 --> Database Driver Class Initialized
INFO - 2018-12-31 13:47:48 --> Email Class Initialized
DEBUG - 2018-12-31 13:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:47:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:47:48 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:47:48 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:47:48 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:47:48 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:48 --> Helper loaded: date_helper
INFO - 2018-12-31 13:47:48 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:47:48 --> Controller Class Initialized
DEBUG - 2018-12-31 13:47:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:48 --> Helper loaded: form_helper
INFO - 2018-12-31 13:47:48 --> Form Validation Class Initialized
INFO - 2018-12-31 13:47:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:47:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:47:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:47:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:47:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:47:48 --> Final output sent to browser
DEBUG - 2018-12-31 13:47:48 --> Total execution time: 0.4018
INFO - 2018-12-31 13:47:53 --> Config Class Initialized
INFO - 2018-12-31 13:47:53 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:47:53 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:47:53 --> Utf8 Class Initialized
INFO - 2018-12-31 13:47:53 --> URI Class Initialized
INFO - 2018-12-31 13:47:53 --> Router Class Initialized
INFO - 2018-12-31 13:47:53 --> Output Class Initialized
INFO - 2018-12-31 13:47:53 --> Security Class Initialized
DEBUG - 2018-12-31 13:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:47:53 --> CSRF cookie sent
INFO - 2018-12-31 13:47:53 --> CSRF token verified
INFO - 2018-12-31 13:47:53 --> Input Class Initialized
INFO - 2018-12-31 13:47:53 --> Language Class Initialized
INFO - 2018-12-31 13:47:53 --> Loader Class Initialized
INFO - 2018-12-31 13:47:53 --> Helper loaded: url_helper
INFO - 2018-12-31 13:47:53 --> Helper loaded: file_helper
INFO - 2018-12-31 13:47:53 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:47:53 --> Helper loaded: util_helper
INFO - 2018-12-31 13:47:53 --> Database Driver Class Initialized
INFO - 2018-12-31 13:47:53 --> Email Class Initialized
DEBUG - 2018-12-31 13:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:47:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:47:53 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:47:53 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:47:53 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:47:54 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:54 --> Helper loaded: date_helper
INFO - 2018-12-31 13:47:54 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:47:54 --> Controller Class Initialized
DEBUG - 2018-12-31 13:47:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:54 --> Helper loaded: form_helper
INFO - 2018-12-31 13:47:54 --> Form Validation Class Initialized
INFO - 2018-12-31 13:47:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:47:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:47:54 --> Config Class Initialized
INFO - 2018-12-31 13:47:54 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:47:54 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:47:54 --> Utf8 Class Initialized
INFO - 2018-12-31 13:47:54 --> URI Class Initialized
DEBUG - 2018-12-31 13:47:54 --> No URI present. Default controller set.
INFO - 2018-12-31 13:47:54 --> Router Class Initialized
INFO - 2018-12-31 13:47:54 --> Output Class Initialized
INFO - 2018-12-31 13:47:54 --> Security Class Initialized
DEBUG - 2018-12-31 13:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:47:54 --> CSRF cookie sent
INFO - 2018-12-31 13:47:54 --> Input Class Initialized
INFO - 2018-12-31 13:47:54 --> Language Class Initialized
INFO - 2018-12-31 13:47:54 --> Loader Class Initialized
INFO - 2018-12-31 13:47:54 --> Helper loaded: url_helper
INFO - 2018-12-31 13:47:54 --> Helper loaded: file_helper
INFO - 2018-12-31 13:47:54 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:47:54 --> Helper loaded: util_helper
INFO - 2018-12-31 13:47:54 --> Database Driver Class Initialized
INFO - 2018-12-31 13:47:54 --> Email Class Initialized
DEBUG - 2018-12-31 13:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:47:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:47:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:47:54 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:47:54 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:47:54 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:47:54 --> Helper loaded: date_helper
INFO - 2018-12-31 13:47:54 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:47:54 --> Controller Class Initialized
INFO - 2018-12-31 13:47:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
ERROR - 2018-12-31 13:47:54 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\auth_helper.php 29
INFO - 2018-12-31 13:48:46 --> Config Class Initialized
INFO - 2018-12-31 13:48:46 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:48:46 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:48:46 --> Utf8 Class Initialized
INFO - 2018-12-31 13:48:46 --> URI Class Initialized
DEBUG - 2018-12-31 13:48:46 --> No URI present. Default controller set.
INFO - 2018-12-31 13:48:46 --> Router Class Initialized
INFO - 2018-12-31 13:48:46 --> Output Class Initialized
INFO - 2018-12-31 13:48:46 --> Security Class Initialized
DEBUG - 2018-12-31 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:48:46 --> CSRF cookie sent
INFO - 2018-12-31 13:48:46 --> Input Class Initialized
INFO - 2018-12-31 13:48:46 --> Language Class Initialized
INFO - 2018-12-31 13:48:46 --> Loader Class Initialized
INFO - 2018-12-31 13:48:46 --> Helper loaded: url_helper
INFO - 2018-12-31 13:48:46 --> Helper loaded: file_helper
INFO - 2018-12-31 13:48:46 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:48:46 --> Helper loaded: util_helper
INFO - 2018-12-31 13:48:46 --> Database Driver Class Initialized
INFO - 2018-12-31 13:48:46 --> Email Class Initialized
DEBUG - 2018-12-31 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:48:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:48:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:48:46 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:48:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:48:46 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:48:46 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:48:46 --> Helper loaded: date_helper
INFO - 2018-12-31 13:48:46 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:48:46 --> Controller Class Initialized
INFO - 2018-12-31 13:48:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:48:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:48:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:48:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:48:46 --> Final output sent to browser
DEBUG - 2018-12-31 13:48:46 --> Total execution time: 0.3544
INFO - 2018-12-31 13:50:17 --> Config Class Initialized
INFO - 2018-12-31 13:50:17 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:50:17 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:50:17 --> Utf8 Class Initialized
INFO - 2018-12-31 13:50:17 --> URI Class Initialized
DEBUG - 2018-12-31 13:50:17 --> No URI present. Default controller set.
INFO - 2018-12-31 13:50:17 --> Router Class Initialized
INFO - 2018-12-31 13:50:17 --> Output Class Initialized
INFO - 2018-12-31 13:50:17 --> Security Class Initialized
DEBUG - 2018-12-31 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:50:17 --> CSRF cookie sent
INFO - 2018-12-31 13:50:17 --> Input Class Initialized
INFO - 2018-12-31 13:50:17 --> Language Class Initialized
INFO - 2018-12-31 13:50:17 --> Loader Class Initialized
INFO - 2018-12-31 13:50:17 --> Helper loaded: url_helper
INFO - 2018-12-31 13:50:17 --> Helper loaded: file_helper
INFO - 2018-12-31 13:50:17 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:50:17 --> Helper loaded: util_helper
INFO - 2018-12-31 13:50:17 --> Database Driver Class Initialized
INFO - 2018-12-31 13:50:17 --> Email Class Initialized
DEBUG - 2018-12-31 13:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:50:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:50:17 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:50:17 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:50:17 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:50:17 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:17 --> Helper loaded: date_helper
INFO - 2018-12-31 13:50:17 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:50:17 --> Controller Class Initialized
INFO - 2018-12-31 13:50:17 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:50:17 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:50:17 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:50:17 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:50:17 --> Final output sent to browser
DEBUG - 2018-12-31 13:50:17 --> Total execution time: 0.3702
INFO - 2018-12-31 13:50:26 --> Config Class Initialized
INFO - 2018-12-31 13:50:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:50:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:50:26 --> Utf8 Class Initialized
INFO - 2018-12-31 13:50:26 --> URI Class Initialized
INFO - 2018-12-31 13:50:26 --> Router Class Initialized
INFO - 2018-12-31 13:50:26 --> Output Class Initialized
INFO - 2018-12-31 13:50:26 --> Security Class Initialized
DEBUG - 2018-12-31 13:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:50:26 --> CSRF cookie sent
INFO - 2018-12-31 13:50:26 --> Input Class Initialized
INFO - 2018-12-31 13:50:26 --> Language Class Initialized
INFO - 2018-12-31 13:50:26 --> Loader Class Initialized
INFO - 2018-12-31 13:50:26 --> Helper loaded: url_helper
INFO - 2018-12-31 13:50:26 --> Helper loaded: file_helper
INFO - 2018-12-31 13:50:26 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:50:26 --> Helper loaded: util_helper
INFO - 2018-12-31 13:50:26 --> Database Driver Class Initialized
INFO - 2018-12-31 13:50:26 --> Email Class Initialized
DEBUG - 2018-12-31 13:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:50:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:50:26 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:50:26 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:50:26 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:50:26 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:26 --> Helper loaded: date_helper
INFO - 2018-12-31 13:50:26 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:50:26 --> Controller Class Initialized
DEBUG - 2018-12-31 13:50:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:26 --> Helper loaded: form_helper
INFO - 2018-12-31 13:50:26 --> Form Validation Class Initialized
INFO - 2018-12-31 13:50:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:50:26 --> Config Class Initialized
INFO - 2018-12-31 13:50:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:50:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:50:27 --> Utf8 Class Initialized
INFO - 2018-12-31 13:50:27 --> URI Class Initialized
INFO - 2018-12-31 13:50:27 --> Router Class Initialized
INFO - 2018-12-31 13:50:27 --> Output Class Initialized
INFO - 2018-12-31 13:50:27 --> Security Class Initialized
DEBUG - 2018-12-31 13:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:50:27 --> CSRF cookie sent
INFO - 2018-12-31 13:50:27 --> Input Class Initialized
INFO - 2018-12-31 13:50:27 --> Language Class Initialized
INFO - 2018-12-31 13:50:27 --> Loader Class Initialized
INFO - 2018-12-31 13:50:27 --> Helper loaded: url_helper
INFO - 2018-12-31 13:50:27 --> Helper loaded: file_helper
INFO - 2018-12-31 13:50:27 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:50:27 --> Helper loaded: util_helper
INFO - 2018-12-31 13:50:27 --> Database Driver Class Initialized
INFO - 2018-12-31 13:50:27 --> Email Class Initialized
DEBUG - 2018-12-31 13:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:50:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:50:27 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:50:27 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:50:27 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:50:27 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:27 --> Helper loaded: date_helper
INFO - 2018-12-31 13:50:27 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:50:27 --> Controller Class Initialized
DEBUG - 2018-12-31 13:50:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:27 --> Helper loaded: form_helper
INFO - 2018-12-31 13:50:27 --> Form Validation Class Initialized
INFO - 2018-12-31 13:50:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:50:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:50:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:50:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:50:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:50:27 --> Final output sent to browser
DEBUG - 2018-12-31 13:50:27 --> Total execution time: 0.4099
INFO - 2018-12-31 13:50:51 --> Config Class Initialized
INFO - 2018-12-31 13:50:51 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:50:51 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:50:51 --> Utf8 Class Initialized
INFO - 2018-12-31 13:50:51 --> URI Class Initialized
DEBUG - 2018-12-31 13:50:51 --> No URI present. Default controller set.
INFO - 2018-12-31 13:50:51 --> Router Class Initialized
INFO - 2018-12-31 13:50:51 --> Output Class Initialized
INFO - 2018-12-31 13:50:51 --> Security Class Initialized
DEBUG - 2018-12-31 13:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:50:51 --> CSRF cookie sent
INFO - 2018-12-31 13:50:51 --> Input Class Initialized
INFO - 2018-12-31 13:50:51 --> Language Class Initialized
INFO - 2018-12-31 13:50:51 --> Loader Class Initialized
INFO - 2018-12-31 13:50:51 --> Helper loaded: url_helper
INFO - 2018-12-31 13:50:51 --> Helper loaded: file_helper
INFO - 2018-12-31 13:50:51 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:50:51 --> Helper loaded: util_helper
INFO - 2018-12-31 13:50:51 --> Database Driver Class Initialized
INFO - 2018-12-31 13:50:51 --> Email Class Initialized
DEBUG - 2018-12-31 13:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:50:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:50:51 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:50:51 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:50:52 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:50:52 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:52 --> Helper loaded: date_helper
INFO - 2018-12-31 13:50:52 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:50:52 --> Controller Class Initialized
INFO - 2018-12-31 13:50:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:50:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:50:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:50:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:50:52 --> Final output sent to browser
DEBUG - 2018-12-31 13:50:52 --> Total execution time: 0.3815
INFO - 2018-12-31 13:50:54 --> Config Class Initialized
INFO - 2018-12-31 13:50:54 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:50:54 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:50:54 --> Utf8 Class Initialized
INFO - 2018-12-31 13:50:54 --> URI Class Initialized
INFO - 2018-12-31 13:50:54 --> Router Class Initialized
INFO - 2018-12-31 13:50:54 --> Output Class Initialized
INFO - 2018-12-31 13:50:54 --> Security Class Initialized
DEBUG - 2018-12-31 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:50:54 --> CSRF cookie sent
INFO - 2018-12-31 13:50:54 --> Input Class Initialized
INFO - 2018-12-31 13:50:54 --> Language Class Initialized
INFO - 2018-12-31 13:50:54 --> Loader Class Initialized
INFO - 2018-12-31 13:50:54 --> Helper loaded: url_helper
INFO - 2018-12-31 13:50:54 --> Helper loaded: file_helper
INFO - 2018-12-31 13:50:54 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:50:54 --> Helper loaded: util_helper
INFO - 2018-12-31 13:50:54 --> Database Driver Class Initialized
INFO - 2018-12-31 13:50:54 --> Email Class Initialized
DEBUG - 2018-12-31 13:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:50:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:50:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:50:54 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:50:54 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:50:54 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:54 --> Helper loaded: date_helper
INFO - 2018-12-31 13:50:54 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:50:54 --> Controller Class Initialized
DEBUG - 2018-12-31 13:50:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:50:54 --> Helper loaded: form_helper
INFO - 2018-12-31 13:50:54 --> Form Validation Class Initialized
INFO - 2018-12-31 13:50:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:50:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:50:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:50:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:50:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:50:54 --> Final output sent to browser
DEBUG - 2018-12-31 13:50:54 --> Total execution time: 0.4245
INFO - 2018-12-31 13:52:26 --> Config Class Initialized
INFO - 2018-12-31 13:52:26 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:52:26 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:52:26 --> Utf8 Class Initialized
INFO - 2018-12-31 13:52:26 --> URI Class Initialized
INFO - 2018-12-31 13:52:26 --> Router Class Initialized
INFO - 2018-12-31 13:52:26 --> Output Class Initialized
INFO - 2018-12-31 13:52:26 --> Security Class Initialized
DEBUG - 2018-12-31 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:52:26 --> CSRF cookie sent
INFO - 2018-12-31 13:52:26 --> Input Class Initialized
INFO - 2018-12-31 13:52:26 --> Language Class Initialized
INFO - 2018-12-31 13:52:26 --> Loader Class Initialized
INFO - 2018-12-31 13:52:26 --> Helper loaded: url_helper
INFO - 2018-12-31 13:52:26 --> Helper loaded: file_helper
INFO - 2018-12-31 13:52:26 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:52:26 --> Helper loaded: util_helper
INFO - 2018-12-31 13:52:26 --> Database Driver Class Initialized
INFO - 2018-12-31 13:52:26 --> Email Class Initialized
DEBUG - 2018-12-31 13:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:52:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:52:26 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:52:26 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:52:26 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:52:26 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:26 --> Helper loaded: date_helper
INFO - 2018-12-31 13:52:26 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:52:26 --> Controller Class Initialized
DEBUG - 2018-12-31 13:52:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:26 --> Helper loaded: form_helper
INFO - 2018-12-31 13:52:26 --> Form Validation Class Initialized
INFO - 2018-12-31 13:52:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:52:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:52:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:52:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:52:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:52:26 --> Final output sent to browser
DEBUG - 2018-12-31 13:52:26 --> Total execution time: 0.3391
INFO - 2018-12-31 13:52:31 --> Config Class Initialized
INFO - 2018-12-31 13:52:31 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:52:31 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:52:31 --> Utf8 Class Initialized
INFO - 2018-12-31 13:52:31 --> URI Class Initialized
INFO - 2018-12-31 13:52:31 --> Router Class Initialized
INFO - 2018-12-31 13:52:31 --> Output Class Initialized
INFO - 2018-12-31 13:52:31 --> Security Class Initialized
DEBUG - 2018-12-31 13:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:52:31 --> CSRF cookie sent
INFO - 2018-12-31 13:52:31 --> Input Class Initialized
INFO - 2018-12-31 13:52:31 --> Language Class Initialized
INFO - 2018-12-31 13:52:31 --> Loader Class Initialized
INFO - 2018-12-31 13:52:31 --> Helper loaded: url_helper
INFO - 2018-12-31 13:52:31 --> Helper loaded: file_helper
INFO - 2018-12-31 13:52:31 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:52:31 --> Helper loaded: util_helper
INFO - 2018-12-31 13:52:32 --> Database Driver Class Initialized
INFO - 2018-12-31 13:52:32 --> Email Class Initialized
DEBUG - 2018-12-31 13:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:52:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:52:32 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:52:32 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:52:32 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:52:32 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:32 --> Helper loaded: date_helper
INFO - 2018-12-31 13:52:32 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:52:32 --> Controller Class Initialized
DEBUG - 2018-12-31 13:52:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:32 --> Helper loaded: form_helper
INFO - 2018-12-31 13:52:32 --> Form Validation Class Initialized
INFO - 2018-12-31 13:52:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:52:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:52:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:52:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:52:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:52:32 --> Final output sent to browser
DEBUG - 2018-12-31 13:52:32 --> Total execution time: 0.3690
INFO - 2018-12-31 13:52:38 --> Config Class Initialized
INFO - 2018-12-31 13:52:38 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:52:38 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:52:38 --> Utf8 Class Initialized
INFO - 2018-12-31 13:52:38 --> URI Class Initialized
INFO - 2018-12-31 13:52:38 --> Router Class Initialized
INFO - 2018-12-31 13:52:38 --> Output Class Initialized
INFO - 2018-12-31 13:52:38 --> Security Class Initialized
DEBUG - 2018-12-31 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:52:38 --> CSRF cookie sent
INFO - 2018-12-31 13:52:38 --> Input Class Initialized
INFO - 2018-12-31 13:52:38 --> Language Class Initialized
INFO - 2018-12-31 13:52:38 --> Loader Class Initialized
INFO - 2018-12-31 13:52:38 --> Helper loaded: url_helper
INFO - 2018-12-31 13:52:38 --> Helper loaded: file_helper
INFO - 2018-12-31 13:52:39 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:52:39 --> Helper loaded: util_helper
INFO - 2018-12-31 13:52:39 --> Database Driver Class Initialized
INFO - 2018-12-31 13:52:39 --> Email Class Initialized
DEBUG - 2018-12-31 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:52:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:52:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:52:39 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:52:39 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:52:39 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:39 --> Helper loaded: date_helper
INFO - 2018-12-31 13:52:39 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:52:39 --> Controller Class Initialized
DEBUG - 2018-12-31 13:52:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:52:39 --> Helper loaded: form_helper
INFO - 2018-12-31 13:52:39 --> Form Validation Class Initialized
INFO - 2018-12-31 13:52:39 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:52:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:52:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:52:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:52:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:52:39 --> Final output sent to browser
DEBUG - 2018-12-31 13:52:39 --> Total execution time: 0.3766
INFO - 2018-12-31 13:53:39 --> Config Class Initialized
INFO - 2018-12-31 13:53:39 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:53:39 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:53:39 --> Utf8 Class Initialized
INFO - 2018-12-31 13:53:39 --> URI Class Initialized
INFO - 2018-12-31 13:53:39 --> Router Class Initialized
INFO - 2018-12-31 13:53:39 --> Output Class Initialized
INFO - 2018-12-31 13:53:39 --> Security Class Initialized
DEBUG - 2018-12-31 13:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:53:39 --> CSRF cookie sent
INFO - 2018-12-31 13:53:39 --> Input Class Initialized
INFO - 2018-12-31 13:53:39 --> Language Class Initialized
INFO - 2018-12-31 13:53:39 --> Loader Class Initialized
INFO - 2018-12-31 13:53:39 --> Helper loaded: url_helper
INFO - 2018-12-31 13:53:39 --> Helper loaded: file_helper
INFO - 2018-12-31 13:53:40 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:53:40 --> Helper loaded: util_helper
INFO - 2018-12-31 13:53:40 --> Database Driver Class Initialized
INFO - 2018-12-31 13:53:40 --> Email Class Initialized
DEBUG - 2018-12-31 13:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:53:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:53:40 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:53:40 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:53:40 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:53:40 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:40 --> Helper loaded: date_helper
INFO - 2018-12-31 13:53:40 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:53:40 --> Controller Class Initialized
DEBUG - 2018-12-31 13:53:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:40 --> Helper loaded: form_helper
INFO - 2018-12-31 13:53:40 --> Form Validation Class Initialized
INFO - 2018-12-31 13:53:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:53:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:53:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:53:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:53:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:53:40 --> Final output sent to browser
DEBUG - 2018-12-31 13:53:40 --> Total execution time: 0.3459
INFO - 2018-12-31 13:53:45 --> Config Class Initialized
INFO - 2018-12-31 13:53:45 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:53:45 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:53:45 --> Utf8 Class Initialized
INFO - 2018-12-31 13:53:45 --> URI Class Initialized
INFO - 2018-12-31 13:53:45 --> Router Class Initialized
INFO - 2018-12-31 13:53:45 --> Output Class Initialized
INFO - 2018-12-31 13:53:45 --> Security Class Initialized
DEBUG - 2018-12-31 13:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:53:45 --> CSRF cookie sent
INFO - 2018-12-31 13:53:45 --> Input Class Initialized
INFO - 2018-12-31 13:53:45 --> Language Class Initialized
INFO - 2018-12-31 13:53:45 --> Loader Class Initialized
INFO - 2018-12-31 13:53:45 --> Helper loaded: url_helper
INFO - 2018-12-31 13:53:45 --> Helper loaded: file_helper
INFO - 2018-12-31 13:53:45 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:53:45 --> Helper loaded: util_helper
INFO - 2018-12-31 13:53:45 --> Database Driver Class Initialized
INFO - 2018-12-31 13:53:45 --> Email Class Initialized
DEBUG - 2018-12-31 13:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:53:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:53:45 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:53:45 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:53:45 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:53:45 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:45 --> Helper loaded: date_helper
INFO - 2018-12-31 13:53:45 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:53:45 --> Controller Class Initialized
DEBUG - 2018-12-31 13:53:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:45 --> Helper loaded: form_helper
INFO - 2018-12-31 13:53:45 --> Form Validation Class Initialized
INFO - 2018-12-31 13:53:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:53:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:53:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:53:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:53:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:53:45 --> Final output sent to browser
DEBUG - 2018-12-31 13:53:45 --> Total execution time: 0.3844
INFO - 2018-12-31 13:53:54 --> Config Class Initialized
INFO - 2018-12-31 13:53:54 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:53:54 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:53:54 --> Utf8 Class Initialized
INFO - 2018-12-31 13:53:54 --> URI Class Initialized
DEBUG - 2018-12-31 13:53:54 --> No URI present. Default controller set.
INFO - 2018-12-31 13:53:54 --> Router Class Initialized
INFO - 2018-12-31 13:53:54 --> Output Class Initialized
INFO - 2018-12-31 13:53:54 --> Security Class Initialized
DEBUG - 2018-12-31 13:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:53:54 --> CSRF cookie sent
INFO - 2018-12-31 13:53:54 --> Input Class Initialized
INFO - 2018-12-31 13:53:54 --> Language Class Initialized
INFO - 2018-12-31 13:53:54 --> Loader Class Initialized
INFO - 2018-12-31 13:53:54 --> Helper loaded: url_helper
INFO - 2018-12-31 13:53:54 --> Helper loaded: file_helper
INFO - 2018-12-31 13:53:54 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:53:54 --> Helper loaded: util_helper
INFO - 2018-12-31 13:53:54 --> Database Driver Class Initialized
INFO - 2018-12-31 13:53:54 --> Email Class Initialized
DEBUG - 2018-12-31 13:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:53:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:53:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:53:54 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:53:54 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:53:54 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:53:54 --> Helper loaded: date_helper
INFO - 2018-12-31 13:53:54 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:53:54 --> Controller Class Initialized
INFO - 2018-12-31 13:53:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:53:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:53:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:53:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:53:54 --> Final output sent to browser
DEBUG - 2018-12-31 13:53:54 --> Total execution time: 0.3514
INFO - 2018-12-31 13:54:04 --> Config Class Initialized
INFO - 2018-12-31 13:54:04 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:54:04 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:54:04 --> Utf8 Class Initialized
INFO - 2018-12-31 13:54:04 --> URI Class Initialized
DEBUG - 2018-12-31 13:54:04 --> No URI present. Default controller set.
INFO - 2018-12-31 13:54:04 --> Router Class Initialized
INFO - 2018-12-31 13:54:04 --> Output Class Initialized
INFO - 2018-12-31 13:54:04 --> Security Class Initialized
DEBUG - 2018-12-31 13:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:54:04 --> CSRF cookie sent
INFO - 2018-12-31 13:54:04 --> Input Class Initialized
INFO - 2018-12-31 13:54:04 --> Language Class Initialized
INFO - 2018-12-31 13:54:04 --> Loader Class Initialized
INFO - 2018-12-31 13:54:04 --> Helper loaded: url_helper
INFO - 2018-12-31 13:54:04 --> Helper loaded: file_helper
INFO - 2018-12-31 13:54:04 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:54:04 --> Helper loaded: util_helper
INFO - 2018-12-31 13:54:04 --> Database Driver Class Initialized
INFO - 2018-12-31 13:54:04 --> Email Class Initialized
DEBUG - 2018-12-31 13:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:54:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:54:04 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:54:04 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:54:04 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:54:04 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:04 --> Helper loaded: date_helper
INFO - 2018-12-31 13:54:04 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:54:05 --> Controller Class Initialized
INFO - 2018-12-31 13:54:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:54:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:54:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:54:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:54:05 --> Final output sent to browser
DEBUG - 2018-12-31 13:54:05 --> Total execution time: 0.3384
INFO - 2018-12-31 13:54:07 --> Config Class Initialized
INFO - 2018-12-31 13:54:07 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:54:07 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:54:07 --> Utf8 Class Initialized
INFO - 2018-12-31 13:54:07 --> URI Class Initialized
INFO - 2018-12-31 13:54:07 --> Router Class Initialized
INFO - 2018-12-31 13:54:07 --> Output Class Initialized
INFO - 2018-12-31 13:54:07 --> Security Class Initialized
DEBUG - 2018-12-31 13:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:54:07 --> CSRF cookie sent
INFO - 2018-12-31 13:54:07 --> Input Class Initialized
INFO - 2018-12-31 13:54:07 --> Language Class Initialized
INFO - 2018-12-31 13:54:07 --> Loader Class Initialized
INFO - 2018-12-31 13:54:07 --> Helper loaded: url_helper
INFO - 2018-12-31 13:54:07 --> Helper loaded: file_helper
INFO - 2018-12-31 13:54:07 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:54:07 --> Helper loaded: util_helper
INFO - 2018-12-31 13:54:07 --> Database Driver Class Initialized
INFO - 2018-12-31 13:54:07 --> Email Class Initialized
DEBUG - 2018-12-31 13:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:54:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:54:07 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:54:07 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:54:07 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:54:07 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:07 --> Helper loaded: date_helper
INFO - 2018-12-31 13:54:07 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:54:07 --> Controller Class Initialized
DEBUG - 2018-12-31 13:54:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:07 --> Helper loaded: form_helper
INFO - 2018-12-31 13:54:07 --> Form Validation Class Initialized
INFO - 2018-12-31 13:54:07 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:54:07 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:54:07 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:54:07 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:54:07 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:54:07 --> Final output sent to browser
DEBUG - 2018-12-31 13:54:07 --> Total execution time: 0.3900
INFO - 2018-12-31 13:54:09 --> Config Class Initialized
INFO - 2018-12-31 13:54:09 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:54:09 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:54:09 --> Utf8 Class Initialized
INFO - 2018-12-31 13:54:09 --> URI Class Initialized
INFO - 2018-12-31 13:54:09 --> Router Class Initialized
INFO - 2018-12-31 13:54:09 --> Output Class Initialized
INFO - 2018-12-31 13:54:09 --> Security Class Initialized
DEBUG - 2018-12-31 13:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:54:09 --> CSRF cookie sent
INFO - 2018-12-31 13:54:09 --> Input Class Initialized
INFO - 2018-12-31 13:54:09 --> Language Class Initialized
INFO - 2018-12-31 13:54:09 --> Loader Class Initialized
INFO - 2018-12-31 13:54:09 --> Helper loaded: url_helper
INFO - 2018-12-31 13:54:09 --> Helper loaded: file_helper
INFO - 2018-12-31 13:54:09 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:54:09 --> Helper loaded: util_helper
INFO - 2018-12-31 13:54:09 --> Database Driver Class Initialized
INFO - 2018-12-31 13:54:09 --> Email Class Initialized
DEBUG - 2018-12-31 13:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:54:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:54:09 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:54:09 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:54:09 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:54:09 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:09 --> Helper loaded: date_helper
INFO - 2018-12-31 13:54:09 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:54:09 --> Controller Class Initialized
DEBUG - 2018-12-31 13:54:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:09 --> Helper loaded: form_helper
INFO - 2018-12-31 13:54:09 --> Form Validation Class Initialized
INFO - 2018-12-31 13:54:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:54:09 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:54:09 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:54:09 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:54:09 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:54:09 --> Final output sent to browser
DEBUG - 2018-12-31 13:54:09 --> Total execution time: 0.3624
INFO - 2018-12-31 13:54:25 --> Config Class Initialized
INFO - 2018-12-31 13:54:25 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:54:25 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:54:25 --> Utf8 Class Initialized
INFO - 2018-12-31 13:54:25 --> URI Class Initialized
INFO - 2018-12-31 13:54:25 --> Router Class Initialized
INFO - 2018-12-31 13:54:25 --> Output Class Initialized
INFO - 2018-12-31 13:54:25 --> Security Class Initialized
DEBUG - 2018-12-31 13:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:54:25 --> CSRF cookie sent
INFO - 2018-12-31 13:54:25 --> CSRF token verified
INFO - 2018-12-31 13:54:25 --> Input Class Initialized
INFO - 2018-12-31 13:54:25 --> Language Class Initialized
INFO - 2018-12-31 13:54:25 --> Loader Class Initialized
INFO - 2018-12-31 13:54:25 --> Helper loaded: url_helper
INFO - 2018-12-31 13:54:25 --> Helper loaded: file_helper
INFO - 2018-12-31 13:54:25 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:54:25 --> Helper loaded: util_helper
INFO - 2018-12-31 13:54:25 --> Database Driver Class Initialized
INFO - 2018-12-31 13:54:25 --> Email Class Initialized
DEBUG - 2018-12-31 13:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:54:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:54:25 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:54:25 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:54:25 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:54:25 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:25 --> Helper loaded: date_helper
INFO - 2018-12-31 13:54:26 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:54:26 --> Controller Class Initialized
DEBUG - 2018-12-31 13:54:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:54:26 --> Helper loaded: form_helper
INFO - 2018-12-31 13:54:26 --> Form Validation Class Initialized
INFO - 2018-12-31 13:54:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:54:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:54:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:54:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:54:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:54:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:54:26 --> Final output sent to browser
DEBUG - 2018-12-31 13:54:26 --> Total execution time: 0.4569
INFO - 2018-12-31 13:57:35 --> Config Class Initialized
INFO - 2018-12-31 13:57:35 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:57:35 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:57:35 --> Utf8 Class Initialized
INFO - 2018-12-31 13:57:35 --> URI Class Initialized
INFO - 2018-12-31 13:57:36 --> Router Class Initialized
INFO - 2018-12-31 13:57:36 --> Output Class Initialized
INFO - 2018-12-31 13:57:36 --> Security Class Initialized
DEBUG - 2018-12-31 13:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:57:36 --> CSRF cookie sent
INFO - 2018-12-31 13:57:36 --> Input Class Initialized
INFO - 2018-12-31 13:57:36 --> Language Class Initialized
INFO - 2018-12-31 13:57:36 --> Loader Class Initialized
INFO - 2018-12-31 13:57:36 --> Helper loaded: url_helper
INFO - 2018-12-31 13:57:36 --> Helper loaded: file_helper
INFO - 2018-12-31 13:57:36 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:57:36 --> Helper loaded: util_helper
INFO - 2018-12-31 13:57:36 --> Database Driver Class Initialized
INFO - 2018-12-31 13:57:36 --> Email Class Initialized
DEBUG - 2018-12-31 13:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:57:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:57:36 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:57:36 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:57:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:57:36 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:57:36 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:57:36 --> Helper loaded: date_helper
INFO - 2018-12-31 13:57:36 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:57:36 --> Controller Class Initialized
DEBUG - 2018-12-31 13:57:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:57:36 --> Helper loaded: form_helper
INFO - 2018-12-31 13:57:36 --> Form Validation Class Initialized
INFO - 2018-12-31 13:57:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:57:36 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:57:36 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:57:36 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:57:36 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:57:36 --> Final output sent to browser
DEBUG - 2018-12-31 13:57:36 --> Total execution time: 0.4230
INFO - 2018-12-31 13:57:45 --> Config Class Initialized
INFO - 2018-12-31 13:57:45 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:57:45 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:57:45 --> Utf8 Class Initialized
INFO - 2018-12-31 13:57:45 --> URI Class Initialized
INFO - 2018-12-31 13:57:45 --> Router Class Initialized
INFO - 2018-12-31 13:57:45 --> Output Class Initialized
INFO - 2018-12-31 13:57:45 --> Security Class Initialized
DEBUG - 2018-12-31 13:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:57:45 --> CSRF cookie sent
INFO - 2018-12-31 13:57:45 --> Input Class Initialized
INFO - 2018-12-31 13:57:45 --> Language Class Initialized
INFO - 2018-12-31 13:57:45 --> Loader Class Initialized
INFO - 2018-12-31 13:57:45 --> Helper loaded: url_helper
INFO - 2018-12-31 13:57:45 --> Helper loaded: file_helper
INFO - 2018-12-31 13:57:45 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:57:45 --> Helper loaded: util_helper
INFO - 2018-12-31 13:57:45 --> Database Driver Class Initialized
INFO - 2018-12-31 13:57:45 --> Email Class Initialized
DEBUG - 2018-12-31 13:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:57:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:57:45 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:57:45 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:57:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:57:45 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:57:45 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:57:45 --> Helper loaded: date_helper
INFO - 2018-12-31 13:57:45 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:57:45 --> Controller Class Initialized
DEBUG - 2018-12-31 13:57:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:57:45 --> Helper loaded: form_helper
INFO - 2018-12-31 13:57:45 --> Form Validation Class Initialized
INFO - 2018-12-31 13:57:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:57:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:57:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:57:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:57:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 13:57:45 --> Final output sent to browser
DEBUG - 2018-12-31 13:57:45 --> Total execution time: 0.4021
INFO - 2018-12-31 13:59:28 --> Config Class Initialized
INFO - 2018-12-31 13:59:28 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:59:28 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:59:28 --> Utf8 Class Initialized
INFO - 2018-12-31 13:59:28 --> URI Class Initialized
INFO - 2018-12-31 13:59:28 --> Router Class Initialized
INFO - 2018-12-31 13:59:28 --> Output Class Initialized
INFO - 2018-12-31 13:59:28 --> Security Class Initialized
DEBUG - 2018-12-31 13:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:59:28 --> CSRF cookie sent
INFO - 2018-12-31 13:59:28 --> CSRF token verified
INFO - 2018-12-31 13:59:28 --> Input Class Initialized
INFO - 2018-12-31 13:59:28 --> Language Class Initialized
INFO - 2018-12-31 13:59:28 --> Loader Class Initialized
INFO - 2018-12-31 13:59:28 --> Helper loaded: url_helper
INFO - 2018-12-31 13:59:28 --> Helper loaded: file_helper
INFO - 2018-12-31 13:59:28 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:59:28 --> Helper loaded: util_helper
INFO - 2018-12-31 13:59:28 --> Database Driver Class Initialized
INFO - 2018-12-31 13:59:28 --> Email Class Initialized
DEBUG - 2018-12-31 13:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:59:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:59:28 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:59:28 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:59:28 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:59:28 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:28 --> Helper loaded: date_helper
INFO - 2018-12-31 13:59:28 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:59:28 --> Controller Class Initialized
DEBUG - 2018-12-31 13:59:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:28 --> Helper loaded: form_helper
INFO - 2018-12-31 13:59:28 --> Form Validation Class Initialized
INFO - 2018-12-31 13:59:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:59:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:59:29 --> Config Class Initialized
INFO - 2018-12-31 13:59:29 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:59:29 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:59:29 --> Utf8 Class Initialized
INFO - 2018-12-31 13:59:29 --> URI Class Initialized
INFO - 2018-12-31 13:59:29 --> Router Class Initialized
INFO - 2018-12-31 13:59:29 --> Output Class Initialized
INFO - 2018-12-31 13:59:29 --> Security Class Initialized
DEBUG - 2018-12-31 13:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:59:29 --> CSRF cookie sent
INFO - 2018-12-31 13:59:29 --> Input Class Initialized
INFO - 2018-12-31 13:59:29 --> Language Class Initialized
INFO - 2018-12-31 13:59:29 --> Loader Class Initialized
INFO - 2018-12-31 13:59:29 --> Helper loaded: url_helper
INFO - 2018-12-31 13:59:29 --> Helper loaded: file_helper
INFO - 2018-12-31 13:59:29 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:59:29 --> Helper loaded: util_helper
INFO - 2018-12-31 13:59:29 --> Database Driver Class Initialized
INFO - 2018-12-31 13:59:29 --> Email Class Initialized
DEBUG - 2018-12-31 13:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:59:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:59:29 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:59:29 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:59:29 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:59:29 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:29 --> Helper loaded: date_helper
INFO - 2018-12-31 13:59:29 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:59:29 --> Controller Class Initialized
DEBUG - 2018-12-31 13:59:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:29 --> Helper loaded: form_helper
INFO - 2018-12-31 13:59:29 --> Form Validation Class Initialized
INFO - 2018-12-31 13:59:29 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:59:30 --> Config Class Initialized
INFO - 2018-12-31 13:59:30 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:59:30 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:59:30 --> Utf8 Class Initialized
INFO - 2018-12-31 13:59:30 --> URI Class Initialized
INFO - 2018-12-31 13:59:30 --> Router Class Initialized
INFO - 2018-12-31 13:59:30 --> Output Class Initialized
INFO - 2018-12-31 13:59:30 --> Security Class Initialized
DEBUG - 2018-12-31 13:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:59:30 --> CSRF cookie sent
INFO - 2018-12-31 13:59:30 --> Input Class Initialized
INFO - 2018-12-31 13:59:30 --> Language Class Initialized
INFO - 2018-12-31 13:59:30 --> Loader Class Initialized
INFO - 2018-12-31 13:59:30 --> Helper loaded: url_helper
INFO - 2018-12-31 13:59:30 --> Helper loaded: file_helper
INFO - 2018-12-31 13:59:30 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:59:30 --> Helper loaded: util_helper
INFO - 2018-12-31 13:59:30 --> Database Driver Class Initialized
INFO - 2018-12-31 13:59:30 --> Email Class Initialized
DEBUG - 2018-12-31 13:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:59:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:59:30 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:59:30 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:59:30 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:59:30 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:30 --> Helper loaded: date_helper
INFO - 2018-12-31 13:59:30 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:59:30 --> Controller Class Initialized
DEBUG - 2018-12-31 13:59:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:30 --> Helper loaded: form_helper
INFO - 2018-12-31 13:59:30 --> Form Validation Class Initialized
INFO - 2018-12-31 13:59:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:59:30 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:59:30 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:59:30 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:59:30 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:59:30 --> Final output sent to browser
DEBUG - 2018-12-31 13:59:30 --> Total execution time: 0.3984
INFO - 2018-12-31 13:59:43 --> Config Class Initialized
INFO - 2018-12-31 13:59:43 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:59:43 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:59:43 --> Utf8 Class Initialized
INFO - 2018-12-31 13:59:43 --> URI Class Initialized
INFO - 2018-12-31 13:59:43 --> Router Class Initialized
INFO - 2018-12-31 13:59:43 --> Output Class Initialized
INFO - 2018-12-31 13:59:43 --> Security Class Initialized
DEBUG - 2018-12-31 13:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:59:43 --> CSRF cookie sent
INFO - 2018-12-31 13:59:43 --> CSRF token verified
INFO - 2018-12-31 13:59:43 --> Input Class Initialized
INFO - 2018-12-31 13:59:43 --> Language Class Initialized
INFO - 2018-12-31 13:59:43 --> Loader Class Initialized
INFO - 2018-12-31 13:59:43 --> Helper loaded: url_helper
INFO - 2018-12-31 13:59:43 --> Helper loaded: file_helper
INFO - 2018-12-31 13:59:43 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:59:43 --> Helper loaded: util_helper
INFO - 2018-12-31 13:59:43 --> Database Driver Class Initialized
INFO - 2018-12-31 13:59:43 --> Email Class Initialized
DEBUG - 2018-12-31 13:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:59:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:59:43 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:59:43 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:59:43 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:59:43 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:43 --> Helper loaded: date_helper
INFO - 2018-12-31 13:59:43 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:59:43 --> Controller Class Initialized
DEBUG - 2018-12-31 13:59:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:43 --> Helper loaded: form_helper
INFO - 2018-12-31 13:59:43 --> Form Validation Class Initialized
INFO - 2018-12-31 13:59:43 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:59:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 13:59:44 --> Config Class Initialized
INFO - 2018-12-31 13:59:44 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:59:44 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:59:44 --> Utf8 Class Initialized
INFO - 2018-12-31 13:59:44 --> URI Class Initialized
DEBUG - 2018-12-31 13:59:44 --> No URI present. Default controller set.
INFO - 2018-12-31 13:59:44 --> Router Class Initialized
INFO - 2018-12-31 13:59:44 --> Output Class Initialized
INFO - 2018-12-31 13:59:44 --> Security Class Initialized
DEBUG - 2018-12-31 13:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:59:44 --> CSRF cookie sent
INFO - 2018-12-31 13:59:44 --> Input Class Initialized
INFO - 2018-12-31 13:59:44 --> Language Class Initialized
INFO - 2018-12-31 13:59:44 --> Loader Class Initialized
INFO - 2018-12-31 13:59:44 --> Helper loaded: url_helper
INFO - 2018-12-31 13:59:44 --> Helper loaded: file_helper
INFO - 2018-12-31 13:59:44 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:59:44 --> Helper loaded: util_helper
INFO - 2018-12-31 13:59:44 --> Database Driver Class Initialized
INFO - 2018-12-31 13:59:44 --> Email Class Initialized
DEBUG - 2018-12-31 13:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:59:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:59:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:59:44 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:59:44 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:59:44 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:44 --> Helper loaded: date_helper
INFO - 2018-12-31 13:59:44 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:59:44 --> Controller Class Initialized
INFO - 2018-12-31 13:59:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:59:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:59:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:59:44 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 13:59:44 --> Final output sent to browser
DEBUG - 2018-12-31 13:59:44 --> Total execution time: 0.3320
INFO - 2018-12-31 13:59:47 --> Config Class Initialized
INFO - 2018-12-31 13:59:47 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:59:47 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:59:47 --> Utf8 Class Initialized
INFO - 2018-12-31 13:59:47 --> URI Class Initialized
INFO - 2018-12-31 13:59:47 --> Router Class Initialized
INFO - 2018-12-31 13:59:47 --> Output Class Initialized
INFO - 2018-12-31 13:59:47 --> Security Class Initialized
DEBUG - 2018-12-31 13:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:59:47 --> CSRF cookie sent
INFO - 2018-12-31 13:59:47 --> Input Class Initialized
INFO - 2018-12-31 13:59:47 --> Language Class Initialized
INFO - 2018-12-31 13:59:47 --> Loader Class Initialized
INFO - 2018-12-31 13:59:47 --> Helper loaded: url_helper
INFO - 2018-12-31 13:59:47 --> Helper loaded: file_helper
INFO - 2018-12-31 13:59:47 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:59:47 --> Helper loaded: util_helper
INFO - 2018-12-31 13:59:47 --> Database Driver Class Initialized
INFO - 2018-12-31 13:59:47 --> Email Class Initialized
DEBUG - 2018-12-31 13:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:59:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:59:48 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:59:48 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:59:48 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:59:48 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:48 --> Helper loaded: date_helper
INFO - 2018-12-31 13:59:48 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:59:48 --> Controller Class Initialized
DEBUG - 2018-12-31 13:59:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:48 --> Helper loaded: form_helper
INFO - 2018-12-31 13:59:48 --> Form Validation Class Initialized
INFO - 2018-12-31 13:59:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:59:48 --> Config Class Initialized
INFO - 2018-12-31 13:59:48 --> Hooks Class Initialized
DEBUG - 2018-12-31 13:59:48 --> UTF-8 Support Enabled
INFO - 2018-12-31 13:59:48 --> Utf8 Class Initialized
INFO - 2018-12-31 13:59:48 --> URI Class Initialized
INFO - 2018-12-31 13:59:48 --> Router Class Initialized
INFO - 2018-12-31 13:59:48 --> Output Class Initialized
INFO - 2018-12-31 13:59:48 --> Security Class Initialized
DEBUG - 2018-12-31 13:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 13:59:48 --> CSRF cookie sent
INFO - 2018-12-31 13:59:48 --> Input Class Initialized
INFO - 2018-12-31 13:59:48 --> Language Class Initialized
INFO - 2018-12-31 13:59:48 --> Loader Class Initialized
INFO - 2018-12-31 13:59:48 --> Helper loaded: url_helper
INFO - 2018-12-31 13:59:48 --> Helper loaded: file_helper
INFO - 2018-12-31 13:59:48 --> Helper loaded: auth_helper
INFO - 2018-12-31 13:59:48 --> Helper loaded: util_helper
INFO - 2018-12-31 13:59:48 --> Database Driver Class Initialized
INFO - 2018-12-31 13:59:48 --> Email Class Initialized
DEBUG - 2018-12-31 13:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 13:59:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 13:59:48 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 13:59:48 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 13:59:48 --> Helper loaded: cookie_helper
INFO - 2018-12-31 13:59:48 --> Helper loaded: language_helper
DEBUG - 2018-12-31 13:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:48 --> Helper loaded: date_helper
INFO - 2018-12-31 13:59:48 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 13:59:48 --> Controller Class Initialized
DEBUG - 2018-12-31 13:59:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 13:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 13:59:48 --> Helper loaded: form_helper
INFO - 2018-12-31 13:59:48 --> Form Validation Class Initialized
INFO - 2018-12-31 13:59:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 13:59:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 13:59:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 13:59:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 13:59:48 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 13:59:48 --> Final output sent to browser
DEBUG - 2018-12-31 13:59:48 --> Total execution time: 0.3615
INFO - 2018-12-31 14:00:33 --> Config Class Initialized
INFO - 2018-12-31 14:00:33 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:00:33 --> Utf8 Class Initialized
INFO - 2018-12-31 14:00:33 --> URI Class Initialized
INFO - 2018-12-31 14:00:33 --> Router Class Initialized
INFO - 2018-12-31 14:00:33 --> Output Class Initialized
INFO - 2018-12-31 14:00:33 --> Security Class Initialized
DEBUG - 2018-12-31 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:00:33 --> CSRF cookie sent
INFO - 2018-12-31 14:00:33 --> CSRF token verified
INFO - 2018-12-31 14:00:33 --> Input Class Initialized
INFO - 2018-12-31 14:00:33 --> Language Class Initialized
INFO - 2018-12-31 14:00:33 --> Loader Class Initialized
INFO - 2018-12-31 14:00:33 --> Helper loaded: url_helper
INFO - 2018-12-31 14:00:33 --> Helper loaded: file_helper
INFO - 2018-12-31 14:00:33 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:00:33 --> Helper loaded: util_helper
INFO - 2018-12-31 14:00:33 --> Database Driver Class Initialized
INFO - 2018-12-31 14:00:33 --> Email Class Initialized
DEBUG - 2018-12-31 14:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:00:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:00:33 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:00:33 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:00:33 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:00:33 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:33 --> Helper loaded: date_helper
INFO - 2018-12-31 14:00:33 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:00:33 --> Controller Class Initialized
DEBUG - 2018-12-31 14:00:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:34 --> Helper loaded: form_helper
INFO - 2018-12-31 14:00:34 --> Form Validation Class Initialized
INFO - 2018-12-31 14:00:34 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:00:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 14:00:34 --> Config Class Initialized
INFO - 2018-12-31 14:00:34 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:00:34 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:00:34 --> Utf8 Class Initialized
INFO - 2018-12-31 14:00:34 --> URI Class Initialized
DEBUG - 2018-12-31 14:00:34 --> No URI present. Default controller set.
INFO - 2018-12-31 14:00:34 --> Router Class Initialized
INFO - 2018-12-31 14:00:34 --> Output Class Initialized
INFO - 2018-12-31 14:00:34 --> Security Class Initialized
DEBUG - 2018-12-31 14:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:00:34 --> CSRF cookie sent
INFO - 2018-12-31 14:00:34 --> Input Class Initialized
INFO - 2018-12-31 14:00:34 --> Language Class Initialized
INFO - 2018-12-31 14:00:34 --> Loader Class Initialized
INFO - 2018-12-31 14:00:34 --> Helper loaded: url_helper
INFO - 2018-12-31 14:00:34 --> Helper loaded: file_helper
INFO - 2018-12-31 14:00:34 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:00:34 --> Helper loaded: util_helper
INFO - 2018-12-31 14:00:34 --> Database Driver Class Initialized
INFO - 2018-12-31 14:00:34 --> Email Class Initialized
DEBUG - 2018-12-31 14:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:00:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:00:34 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:00:34 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:00:34 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:00:34 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:34 --> Helper loaded: date_helper
INFO - 2018-12-31 14:00:34 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:00:34 --> Controller Class Initialized
INFO - 2018-12-31 14:00:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:00:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:00:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:00:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 14:00:34 --> Final output sent to browser
DEBUG - 2018-12-31 14:00:35 --> Total execution time: 0.3498
INFO - 2018-12-31 14:00:36 --> Config Class Initialized
INFO - 2018-12-31 14:00:36 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:00:36 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:00:36 --> Utf8 Class Initialized
INFO - 2018-12-31 14:00:36 --> URI Class Initialized
INFO - 2018-12-31 14:00:36 --> Router Class Initialized
INFO - 2018-12-31 14:00:36 --> Output Class Initialized
INFO - 2018-12-31 14:00:36 --> Security Class Initialized
DEBUG - 2018-12-31 14:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:00:36 --> CSRF cookie sent
INFO - 2018-12-31 14:00:36 --> Input Class Initialized
INFO - 2018-12-31 14:00:36 --> Language Class Initialized
INFO - 2018-12-31 14:00:36 --> Loader Class Initialized
INFO - 2018-12-31 14:00:36 --> Helper loaded: url_helper
INFO - 2018-12-31 14:00:36 --> Helper loaded: file_helper
INFO - 2018-12-31 14:00:36 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:00:36 --> Helper loaded: util_helper
INFO - 2018-12-31 14:00:36 --> Database Driver Class Initialized
INFO - 2018-12-31 14:00:37 --> Email Class Initialized
DEBUG - 2018-12-31 14:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:00:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:00:37 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:00:37 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:00:37 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:00:37 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:37 --> Helper loaded: date_helper
INFO - 2018-12-31 14:00:37 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:00:37 --> Controller Class Initialized
DEBUG - 2018-12-31 14:00:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:37 --> Helper loaded: form_helper
INFO - 2018-12-31 14:00:37 --> Form Validation Class Initialized
INFO - 2018-12-31 14:00:37 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:00:37 --> Config Class Initialized
INFO - 2018-12-31 14:00:37 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:00:37 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:00:37 --> Utf8 Class Initialized
INFO - 2018-12-31 14:00:37 --> URI Class Initialized
DEBUG - 2018-12-31 14:00:37 --> No URI present. Default controller set.
INFO - 2018-12-31 14:00:37 --> Router Class Initialized
INFO - 2018-12-31 14:00:37 --> Output Class Initialized
INFO - 2018-12-31 14:00:37 --> Security Class Initialized
DEBUG - 2018-12-31 14:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:00:37 --> CSRF cookie sent
INFO - 2018-12-31 14:00:37 --> Input Class Initialized
INFO - 2018-12-31 14:00:37 --> Language Class Initialized
INFO - 2018-12-31 14:00:37 --> Loader Class Initialized
INFO - 2018-12-31 14:00:37 --> Helper loaded: url_helper
INFO - 2018-12-31 14:00:37 --> Helper loaded: file_helper
INFO - 2018-12-31 14:00:37 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:00:37 --> Helper loaded: util_helper
INFO - 2018-12-31 14:00:37 --> Database Driver Class Initialized
INFO - 2018-12-31 14:00:37 --> Email Class Initialized
DEBUG - 2018-12-31 14:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:00:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:00:37 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:00:37 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:00:37 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:00:37 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:00:37 --> Helper loaded: date_helper
INFO - 2018-12-31 14:00:37 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:00:37 --> Controller Class Initialized
INFO - 2018-12-31 14:00:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:00:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:00:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:00:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 14:00:37 --> Final output sent to browser
DEBUG - 2018-12-31 14:00:37 --> Total execution time: 0.3082
INFO - 2018-12-31 14:03:27 --> Config Class Initialized
INFO - 2018-12-31 14:03:27 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:27 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:27 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:27 --> URI Class Initialized
DEBUG - 2018-12-31 14:03:27 --> No URI present. Default controller set.
INFO - 2018-12-31 14:03:27 --> Router Class Initialized
INFO - 2018-12-31 14:03:27 --> Output Class Initialized
INFO - 2018-12-31 14:03:28 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:28 --> CSRF cookie sent
INFO - 2018-12-31 14:03:28 --> Input Class Initialized
INFO - 2018-12-31 14:03:28 --> Language Class Initialized
INFO - 2018-12-31 14:03:28 --> Loader Class Initialized
INFO - 2018-12-31 14:03:28 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:28 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:28 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:28 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:28 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:28 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:28 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:28 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:28 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:28 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:28 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:28 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:28 --> Controller Class Initialized
INFO - 2018-12-31 14:03:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 14:03:28 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:28 --> Total execution time: 0.3433
INFO - 2018-12-31 14:03:31 --> Config Class Initialized
INFO - 2018-12-31 14:03:31 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:31 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:31 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:31 --> URI Class Initialized
DEBUG - 2018-12-31 14:03:31 --> No URI present. Default controller set.
INFO - 2018-12-31 14:03:31 --> Router Class Initialized
INFO - 2018-12-31 14:03:31 --> Output Class Initialized
INFO - 2018-12-31 14:03:31 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:31 --> CSRF cookie sent
INFO - 2018-12-31 14:03:31 --> Input Class Initialized
INFO - 2018-12-31 14:03:31 --> Language Class Initialized
INFO - 2018-12-31 14:03:31 --> Loader Class Initialized
INFO - 2018-12-31 14:03:31 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:31 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:32 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:32 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:32 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:32 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:32 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:32 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:32 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:32 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:32 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:32 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:32 --> Controller Class Initialized
INFO - 2018-12-31 14:03:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:32 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 14:03:32 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:32 --> Total execution time: 0.3436
INFO - 2018-12-31 14:03:34 --> Config Class Initialized
INFO - 2018-12-31 14:03:34 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:34 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:34 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:34 --> URI Class Initialized
INFO - 2018-12-31 14:03:34 --> Router Class Initialized
INFO - 2018-12-31 14:03:34 --> Output Class Initialized
INFO - 2018-12-31 14:03:34 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:34 --> CSRF cookie sent
INFO - 2018-12-31 14:03:34 --> Input Class Initialized
INFO - 2018-12-31 14:03:34 --> Language Class Initialized
INFO - 2018-12-31 14:03:34 --> Loader Class Initialized
INFO - 2018-12-31 14:03:34 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:34 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:34 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:34 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:34 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:34 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:34 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:34 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:34 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:34 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:34 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:34 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:34 --> Controller Class Initialized
DEBUG - 2018-12-31 14:03:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:34 --> Helper loaded: form_helper
INFO - 2018-12-31 14:03:34 --> Form Validation Class Initialized
INFO - 2018-12-31 14:03:34 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:03:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 14:03:34 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:34 --> Total execution time: 0.3854
INFO - 2018-12-31 14:03:36 --> Config Class Initialized
INFO - 2018-12-31 14:03:36 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:36 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:36 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:36 --> URI Class Initialized
INFO - 2018-12-31 14:03:36 --> Router Class Initialized
INFO - 2018-12-31 14:03:36 --> Output Class Initialized
INFO - 2018-12-31 14:03:36 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:36 --> CSRF cookie sent
INFO - 2018-12-31 14:03:36 --> CSRF token verified
INFO - 2018-12-31 14:03:36 --> Input Class Initialized
INFO - 2018-12-31 14:03:36 --> Language Class Initialized
INFO - 2018-12-31 14:03:36 --> Loader Class Initialized
INFO - 2018-12-31 14:03:36 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:36 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:36 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:36 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:36 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:36 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:36 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:36 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:36 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:36 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:36 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:36 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:36 --> Controller Class Initialized
DEBUG - 2018-12-31 14:03:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:36 --> Helper loaded: form_helper
INFO - 2018-12-31 14:03:36 --> Form Validation Class Initialized
INFO - 2018-12-31 14:03:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:03:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 14:03:36 --> Config Class Initialized
INFO - 2018-12-31 14:03:36 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:36 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:36 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:36 --> URI Class Initialized
DEBUG - 2018-12-31 14:03:36 --> No URI present. Default controller set.
INFO - 2018-12-31 14:03:36 --> Router Class Initialized
INFO - 2018-12-31 14:03:36 --> Output Class Initialized
INFO - 2018-12-31 14:03:36 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:36 --> CSRF cookie sent
INFO - 2018-12-31 14:03:36 --> Input Class Initialized
INFO - 2018-12-31 14:03:36 --> Language Class Initialized
INFO - 2018-12-31 14:03:36 --> Loader Class Initialized
INFO - 2018-12-31 14:03:36 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:36 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:36 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:36 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:36 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:36 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:37 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:37 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:37 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:37 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:37 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:37 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:37 --> Controller Class Initialized
INFO - 2018-12-31 14:03:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:37 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 14:03:37 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:37 --> Total execution time: 0.3203
INFO - 2018-12-31 14:03:38 --> Config Class Initialized
INFO - 2018-12-31 14:03:38 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:38 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:38 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:38 --> URI Class Initialized
INFO - 2018-12-31 14:03:38 --> Router Class Initialized
INFO - 2018-12-31 14:03:38 --> Output Class Initialized
INFO - 2018-12-31 14:03:38 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:38 --> CSRF cookie sent
INFO - 2018-12-31 14:03:38 --> Input Class Initialized
INFO - 2018-12-31 14:03:38 --> Language Class Initialized
INFO - 2018-12-31 14:03:38 --> Loader Class Initialized
INFO - 2018-12-31 14:03:39 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:39 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:39 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:39 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:39 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:39 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:39 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:39 --> Controller Class Initialized
DEBUG - 2018-12-31 14:03:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:39 --> Helper loaded: form_helper
INFO - 2018-12-31 14:03:39 --> Form Validation Class Initialized
INFO - 2018-12-31 14:03:39 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:03:39 --> Config Class Initialized
INFO - 2018-12-31 14:03:39 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:39 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:39 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:39 --> URI Class Initialized
DEBUG - 2018-12-31 14:03:39 --> No URI present. Default controller set.
INFO - 2018-12-31 14:03:39 --> Router Class Initialized
INFO - 2018-12-31 14:03:39 --> Output Class Initialized
INFO - 2018-12-31 14:03:39 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:39 --> CSRF cookie sent
INFO - 2018-12-31 14:03:39 --> Input Class Initialized
INFO - 2018-12-31 14:03:39 --> Language Class Initialized
INFO - 2018-12-31 14:03:39 --> Loader Class Initialized
INFO - 2018-12-31 14:03:39 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:39 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:39 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:39 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:39 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:39 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:39 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:39 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:39 --> Controller Class Initialized
INFO - 2018-12-31 14:03:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2018-12-31 14:03:39 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:39 --> Total execution time: 0.3048
INFO - 2018-12-31 14:03:41 --> Config Class Initialized
INFO - 2018-12-31 14:03:41 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:41 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:41 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:41 --> URI Class Initialized
INFO - 2018-12-31 14:03:41 --> Router Class Initialized
INFO - 2018-12-31 14:03:41 --> Output Class Initialized
INFO - 2018-12-31 14:03:41 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:41 --> CSRF cookie sent
INFO - 2018-12-31 14:03:41 --> Input Class Initialized
INFO - 2018-12-31 14:03:41 --> Language Class Initialized
INFO - 2018-12-31 14:03:41 --> Loader Class Initialized
INFO - 2018-12-31 14:03:41 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:41 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:41 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:41 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:41 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:41 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:41 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:41 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:41 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:41 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:41 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:41 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:41 --> Controller Class Initialized
DEBUG - 2018-12-31 14:03:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:41 --> Helper loaded: form_helper
INFO - 2018-12-31 14:03:41 --> Form Validation Class Initialized
INFO - 2018-12-31 14:03:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:03:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 14:03:41 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:41 --> Total execution time: 0.4145
INFO - 2018-12-31 14:03:43 --> Config Class Initialized
INFO - 2018-12-31 14:03:43 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:43 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:43 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:43 --> URI Class Initialized
INFO - 2018-12-31 14:03:43 --> Router Class Initialized
INFO - 2018-12-31 14:03:43 --> Output Class Initialized
INFO - 2018-12-31 14:03:43 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:43 --> CSRF cookie sent
INFO - 2018-12-31 14:03:43 --> Input Class Initialized
INFO - 2018-12-31 14:03:43 --> Language Class Initialized
INFO - 2018-12-31 14:03:43 --> Loader Class Initialized
INFO - 2018-12-31 14:03:43 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:43 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:43 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:43 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:43 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:43 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:43 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:43 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:43 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:43 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:43 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:43 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:43 --> Controller Class Initialized
DEBUG - 2018-12-31 14:03:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:43 --> Helper loaded: form_helper
INFO - 2018-12-31 14:03:43 --> Form Validation Class Initialized
INFO - 2018-12-31 14:03:43 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:03:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:43 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 14:03:43 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:43 --> Total execution time: 0.3662
INFO - 2018-12-31 14:03:46 --> Config Class Initialized
INFO - 2018-12-31 14:03:46 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:46 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:46 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:46 --> URI Class Initialized
INFO - 2018-12-31 14:03:46 --> Router Class Initialized
INFO - 2018-12-31 14:03:46 --> Output Class Initialized
INFO - 2018-12-31 14:03:46 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:46 --> CSRF cookie sent
INFO - 2018-12-31 14:03:46 --> CSRF token verified
INFO - 2018-12-31 14:03:46 --> Input Class Initialized
INFO - 2018-12-31 14:03:46 --> Language Class Initialized
INFO - 2018-12-31 14:03:46 --> Loader Class Initialized
INFO - 2018-12-31 14:03:46 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:46 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:46 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:46 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:46 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:46 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:46 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:46 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:46 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:46 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:46 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:46 --> Controller Class Initialized
DEBUG - 2018-12-31 14:03:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:46 --> Helper loaded: form_helper
INFO - 2018-12-31 14:03:46 --> Form Validation Class Initialized
INFO - 2018-12-31 14:03:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:03:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 14:03:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2018-12-31 14:03:46 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:46 --> Total execution time: 0.3842
INFO - 2018-12-31 14:03:55 --> Config Class Initialized
INFO - 2018-12-31 14:03:55 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:03:55 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:03:55 --> Utf8 Class Initialized
INFO - 2018-12-31 14:03:55 --> URI Class Initialized
INFO - 2018-12-31 14:03:55 --> Router Class Initialized
INFO - 2018-12-31 14:03:55 --> Output Class Initialized
INFO - 2018-12-31 14:03:55 --> Security Class Initialized
DEBUG - 2018-12-31 14:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:03:55 --> CSRF cookie sent
INFO - 2018-12-31 14:03:55 --> Input Class Initialized
INFO - 2018-12-31 14:03:55 --> Language Class Initialized
INFO - 2018-12-31 14:03:55 --> Loader Class Initialized
INFO - 2018-12-31 14:03:55 --> Helper loaded: url_helper
INFO - 2018-12-31 14:03:55 --> Helper loaded: file_helper
INFO - 2018-12-31 14:03:55 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:03:55 --> Helper loaded: util_helper
INFO - 2018-12-31 14:03:55 --> Database Driver Class Initialized
INFO - 2018-12-31 14:03:55 --> Email Class Initialized
DEBUG - 2018-12-31 14:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:03:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:03:55 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:03:55 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:03:55 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:55 --> Helper loaded: date_helper
INFO - 2018-12-31 14:03:55 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:03:55 --> Controller Class Initialized
DEBUG - 2018-12-31 14:03:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:03:55 --> Helper loaded: form_helper
INFO - 2018-12-31 14:03:55 --> Form Validation Class Initialized
INFO - 2018-12-31 14:03:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:03:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:03:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:03:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:03:55 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 14:03:55 --> Final output sent to browser
DEBUG - 2018-12-31 14:03:55 --> Total execution time: 0.3628
INFO - 2018-12-31 14:04:02 --> Config Class Initialized
INFO - 2018-12-31 14:04:02 --> Hooks Class Initialized
DEBUG - 2018-12-31 14:04:02 --> UTF-8 Support Enabled
INFO - 2018-12-31 14:04:02 --> Utf8 Class Initialized
INFO - 2018-12-31 14:04:02 --> URI Class Initialized
INFO - 2018-12-31 14:04:02 --> Router Class Initialized
INFO - 2018-12-31 14:04:02 --> Output Class Initialized
INFO - 2018-12-31 14:04:02 --> Security Class Initialized
DEBUG - 2018-12-31 14:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-31 14:04:02 --> CSRF cookie sent
INFO - 2018-12-31 14:04:02 --> CSRF token verified
INFO - 2018-12-31 14:04:02 --> Input Class Initialized
INFO - 2018-12-31 14:04:02 --> Language Class Initialized
INFO - 2018-12-31 14:04:02 --> Loader Class Initialized
INFO - 2018-12-31 14:04:02 --> Helper loaded: url_helper
INFO - 2018-12-31 14:04:02 --> Helper loaded: file_helper
INFO - 2018-12-31 14:04:02 --> Helper loaded: auth_helper
INFO - 2018-12-31 14:04:02 --> Helper loaded: util_helper
INFO - 2018-12-31 14:04:02 --> Database Driver Class Initialized
INFO - 2018-12-31 14:04:02 --> Email Class Initialized
DEBUG - 2018-12-31 14:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-31 14:04:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-31 14:04:02 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2018-12-31 14:04:02 --> Email class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:04:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-12-31 14:04:02 --> Helper loaded: cookie_helper
INFO - 2018-12-31 14:04:02 --> Helper loaded: language_helper
DEBUG - 2018-12-31 14:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:04:02 --> Helper loaded: date_helper
INFO - 2018-12-31 14:04:02 --> Model "Ion_auth_model" initialized
INFO - 2018-12-31 14:04:02 --> Controller Class Initialized
DEBUG - 2018-12-31 14:04:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2018-12-31 14:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-12-31 14:04:02 --> Helper loaded: form_helper
INFO - 2018-12-31 14:04:02 --> Form Validation Class Initialized
INFO - 2018-12-31 14:04:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-12-31 14:04:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-31 14:04:02 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2018-12-31 14:04:02 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2018-12-31 14:04:02 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2018-12-31 14:04:02 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2018-12-31 14:04:02 --> Final output sent to browser
DEBUG - 2018-12-31 14:04:02 --> Total execution time: 0.3948
