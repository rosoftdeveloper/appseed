<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-01-01 06:58:42 --> Config Class Initialized
INFO - 2019-01-01 06:58:42 --> Hooks Class Initialized
DEBUG - 2019-01-01 06:58:42 --> UTF-8 Support Enabled
INFO - 2019-01-01 06:58:42 --> Utf8 Class Initialized
INFO - 2019-01-01 06:58:42 --> URI Class Initialized
DEBUG - 2019-01-01 06:58:42 --> No URI present. Default controller set.
INFO - 2019-01-01 06:58:42 --> Router Class Initialized
INFO - 2019-01-01 06:58:43 --> Output Class Initialized
INFO - 2019-01-01 06:58:43 --> Security Class Initialized
DEBUG - 2019-01-01 06:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 06:58:43 --> CSRF cookie sent
INFO - 2019-01-01 06:58:43 --> Input Class Initialized
INFO - 2019-01-01 06:58:43 --> Language Class Initialized
INFO - 2019-01-01 06:58:43 --> Loader Class Initialized
INFO - 2019-01-01 06:58:43 --> Helper loaded: url_helper
INFO - 2019-01-01 06:58:43 --> Helper loaded: file_helper
INFO - 2019-01-01 06:58:43 --> Helper loaded: auth_helper
INFO - 2019-01-01 06:58:43 --> Helper loaded: util_helper
INFO - 2019-01-01 06:58:44 --> Database Driver Class Initialized
INFO - 2019-01-01 06:58:44 --> Email Class Initialized
DEBUG - 2019-01-01 06:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 06:58:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 06:58:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 06:58:44 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 06:58:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 06:58:45 --> Helper loaded: cookie_helper
INFO - 2019-01-01 06:58:45 --> Helper loaded: language_helper
DEBUG - 2019-01-01 06:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 06:58:45 --> Helper loaded: date_helper
INFO - 2019-01-01 06:58:45 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 06:58:45 --> Controller Class Initialized
INFO - 2019-01-01 06:58:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 06:58:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 06:58:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 06:58:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 06:58:45 --> Final output sent to browser
DEBUG - 2019-01-01 06:58:45 --> Total execution time: 3.7545
INFO - 2019-01-01 07:15:45 --> Config Class Initialized
INFO - 2019-01-01 07:15:45 --> Hooks Class Initialized
DEBUG - 2019-01-01 07:15:46 --> UTF-8 Support Enabled
INFO - 2019-01-01 07:15:46 --> Utf8 Class Initialized
INFO - 2019-01-01 07:15:46 --> URI Class Initialized
INFO - 2019-01-01 07:15:46 --> Router Class Initialized
INFO - 2019-01-01 07:15:46 --> Output Class Initialized
INFO - 2019-01-01 07:15:46 --> Security Class Initialized
DEBUG - 2019-01-01 07:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 07:15:46 --> CSRF cookie sent
INFO - 2019-01-01 07:15:46 --> Input Class Initialized
INFO - 2019-01-01 07:15:46 --> Language Class Initialized
INFO - 2019-01-01 07:15:46 --> Loader Class Initialized
INFO - 2019-01-01 07:15:46 --> Helper loaded: url_helper
INFO - 2019-01-01 07:15:46 --> Helper loaded: file_helper
INFO - 2019-01-01 07:15:46 --> Helper loaded: auth_helper
INFO - 2019-01-01 07:15:46 --> Helper loaded: util_helper
INFO - 2019-01-01 07:15:46 --> Database Driver Class Initialized
INFO - 2019-01-01 07:15:46 --> Email Class Initialized
DEBUG - 2019-01-01 07:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 07:15:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 07:15:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 07:15:46 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 07:15:46 --> Helper loaded: cookie_helper
INFO - 2019-01-01 07:15:46 --> Helper loaded: language_helper
DEBUG - 2019-01-01 07:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:46 --> Helper loaded: date_helper
INFO - 2019-01-01 07:15:46 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 07:15:46 --> Controller Class Initialized
DEBUG - 2019-01-01 07:15:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 07:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:46 --> Helper loaded: form_helper
INFO - 2019-01-01 07:15:46 --> Form Validation Class Initialized
INFO - 2019-01-01 07:15:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 07:15:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 07:15:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 07:15:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 07:15:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2019-01-01 07:15:46 --> Final output sent to browser
DEBUG - 2019-01-01 07:15:46 --> Total execution time: 0.8596
INFO - 2019-01-01 07:15:51 --> Config Class Initialized
INFO - 2019-01-01 07:15:51 --> Hooks Class Initialized
DEBUG - 2019-01-01 07:15:51 --> UTF-8 Support Enabled
INFO - 2019-01-01 07:15:51 --> Utf8 Class Initialized
INFO - 2019-01-01 07:15:51 --> URI Class Initialized
INFO - 2019-01-01 07:15:51 --> Router Class Initialized
INFO - 2019-01-01 07:15:51 --> Output Class Initialized
INFO - 2019-01-01 07:15:51 --> Security Class Initialized
DEBUG - 2019-01-01 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 07:15:51 --> CSRF cookie sent
INFO - 2019-01-01 07:15:51 --> Input Class Initialized
INFO - 2019-01-01 07:15:51 --> Language Class Initialized
INFO - 2019-01-01 07:15:51 --> Loader Class Initialized
INFO - 2019-01-01 07:15:51 --> Helper loaded: url_helper
INFO - 2019-01-01 07:15:51 --> Helper loaded: file_helper
INFO - 2019-01-01 07:15:51 --> Helper loaded: auth_helper
INFO - 2019-01-01 07:15:51 --> Helper loaded: util_helper
INFO - 2019-01-01 07:15:52 --> Database Driver Class Initialized
INFO - 2019-01-01 07:15:52 --> Email Class Initialized
DEBUG - 2019-01-01 07:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 07:15:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 07:15:52 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 07:15:52 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 07:15:52 --> Helper loaded: cookie_helper
INFO - 2019-01-01 07:15:52 --> Helper loaded: language_helper
DEBUG - 2019-01-01 07:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:52 --> Helper loaded: date_helper
INFO - 2019-01-01 07:15:52 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 07:15:52 --> Controller Class Initialized
DEBUG - 2019-01-01 07:15:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 07:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:52 --> Helper loaded: form_helper
INFO - 2019-01-01 07:15:52 --> Form Validation Class Initialized
INFO - 2019-01-01 07:15:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2019-01-01 07:15:52 --> Final output sent to browser
DEBUG - 2019-01-01 07:15:52 --> Total execution time: 0.5247
INFO - 2019-01-01 07:15:52 --> Config Class Initialized
INFO - 2019-01-01 07:15:52 --> Hooks Class Initialized
DEBUG - 2019-01-01 07:15:52 --> UTF-8 Support Enabled
INFO - 2019-01-01 07:15:52 --> Utf8 Class Initialized
INFO - 2019-01-01 07:15:52 --> URI Class Initialized
INFO - 2019-01-01 07:15:52 --> Router Class Initialized
INFO - 2019-01-01 07:15:52 --> Output Class Initialized
INFO - 2019-01-01 07:15:52 --> Security Class Initialized
DEBUG - 2019-01-01 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 07:15:52 --> CSRF cookie sent
INFO - 2019-01-01 07:15:52 --> Input Class Initialized
INFO - 2019-01-01 07:15:52 --> Language Class Initialized
INFO - 2019-01-01 07:15:52 --> Loader Class Initialized
INFO - 2019-01-01 07:15:52 --> Helper loaded: url_helper
INFO - 2019-01-01 07:15:52 --> Helper loaded: file_helper
INFO - 2019-01-01 07:15:52 --> Helper loaded: auth_helper
INFO - 2019-01-01 07:15:52 --> Helper loaded: util_helper
INFO - 2019-01-01 07:15:52 --> Database Driver Class Initialized
INFO - 2019-01-01 07:15:52 --> Email Class Initialized
DEBUG - 2019-01-01 07:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 07:15:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 07:15:52 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 07:15:52 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 07:15:52 --> Helper loaded: cookie_helper
INFO - 2019-01-01 07:15:52 --> Helper loaded: language_helper
DEBUG - 2019-01-01 07:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:52 --> Helper loaded: date_helper
INFO - 2019-01-01 07:15:52 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 07:15:52 --> Controller Class Initialized
DEBUG - 2019-01-01 07:15:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 07:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:15:52 --> Helper loaded: form_helper
INFO - 2019-01-01 07:15:52 --> Form Validation Class Initialized
INFO - 2019-01-01 07:15:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 07:15:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2019-01-01 07:15:52 --> Final output sent to browser
DEBUG - 2019-01-01 07:15:52 --> Total execution time: 0.5090
INFO - 2019-01-01 07:16:31 --> Config Class Initialized
INFO - 2019-01-01 07:16:31 --> Hooks Class Initialized
DEBUG - 2019-01-01 07:16:31 --> UTF-8 Support Enabled
INFO - 2019-01-01 07:16:31 --> Utf8 Class Initialized
INFO - 2019-01-01 07:16:31 --> URI Class Initialized
INFO - 2019-01-01 07:16:31 --> Router Class Initialized
INFO - 2019-01-01 07:16:31 --> Output Class Initialized
INFO - 2019-01-01 07:16:31 --> Security Class Initialized
DEBUG - 2019-01-01 07:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 07:16:31 --> CSRF cookie sent
INFO - 2019-01-01 07:16:31 --> Input Class Initialized
INFO - 2019-01-01 07:16:31 --> Language Class Initialized
INFO - 2019-01-01 07:16:31 --> Loader Class Initialized
INFO - 2019-01-01 07:16:31 --> Helper loaded: url_helper
INFO - 2019-01-01 07:16:31 --> Helper loaded: file_helper
INFO - 2019-01-01 07:16:31 --> Helper loaded: auth_helper
INFO - 2019-01-01 07:16:31 --> Helper loaded: util_helper
INFO - 2019-01-01 07:16:31 --> Database Driver Class Initialized
INFO - 2019-01-01 07:16:31 --> Email Class Initialized
DEBUG - 2019-01-01 07:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 07:16:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 07:16:31 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 07:16:31 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:16:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 07:16:31 --> Helper loaded: cookie_helper
INFO - 2019-01-01 07:16:31 --> Helper loaded: language_helper
DEBUG - 2019-01-01 07:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:16:31 --> Helper loaded: date_helper
INFO - 2019-01-01 07:16:31 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 07:16:31 --> Controller Class Initialized
DEBUG - 2019-01-01 07:16:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 07:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 07:16:31 --> Helper loaded: form_helper
INFO - 2019-01-01 07:16:31 --> Form Validation Class Initialized
INFO - 2019-01-01 07:16:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 07:16:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 07:16:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 07:16:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 07:16:31 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2019-01-01 07:16:31 --> Final output sent to browser
DEBUG - 2019-01-01 07:16:31 --> Total execution time: 0.5403
INFO - 2019-01-01 08:39:04 --> Config Class Initialized
INFO - 2019-01-01 08:39:04 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:39:04 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:39:04 --> Utf8 Class Initialized
INFO - 2019-01-01 08:39:04 --> URI Class Initialized
DEBUG - 2019-01-01 08:39:04 --> No URI present. Default controller set.
INFO - 2019-01-01 08:39:04 --> Router Class Initialized
INFO - 2019-01-01 08:39:04 --> Output Class Initialized
INFO - 2019-01-01 08:39:04 --> Security Class Initialized
DEBUG - 2019-01-01 08:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:39:04 --> CSRF cookie sent
INFO - 2019-01-01 08:39:04 --> Input Class Initialized
INFO - 2019-01-01 08:39:04 --> Language Class Initialized
INFO - 2019-01-01 08:39:04 --> Loader Class Initialized
INFO - 2019-01-01 08:39:04 --> Helper loaded: url_helper
INFO - 2019-01-01 08:39:04 --> Helper loaded: file_helper
INFO - 2019-01-01 08:39:04 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:39:04 --> Helper loaded: util_helper
INFO - 2019-01-01 08:39:04 --> Database Driver Class Initialized
INFO - 2019-01-01 08:39:04 --> Email Class Initialized
DEBUG - 2019-01-01 08:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:39:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:39:04 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:39:04 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:39:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:39:04 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:39:04 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:39:04 --> Helper loaded: date_helper
INFO - 2019-01-01 08:39:04 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:39:04 --> Controller Class Initialized
INFO - 2019-01-01 08:39:04 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 08:39:04 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 08:39:04 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 08:39:04 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:39:04 --> Final output sent to browser
DEBUG - 2019-01-01 08:39:04 --> Total execution time: 0.5547
INFO - 2019-01-01 08:51:14 --> Config Class Initialized
INFO - 2019-01-01 08:51:14 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:51:14 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:51:14 --> Utf8 Class Initialized
INFO - 2019-01-01 08:51:14 --> URI Class Initialized
DEBUG - 2019-01-01 08:51:14 --> No URI present. Default controller set.
INFO - 2019-01-01 08:51:14 --> Router Class Initialized
INFO - 2019-01-01 08:51:14 --> Output Class Initialized
INFO - 2019-01-01 08:51:14 --> Security Class Initialized
DEBUG - 2019-01-01 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:51:14 --> CSRF cookie sent
INFO - 2019-01-01 08:51:14 --> Input Class Initialized
INFO - 2019-01-01 08:51:14 --> Language Class Initialized
INFO - 2019-01-01 08:51:14 --> Loader Class Initialized
INFO - 2019-01-01 08:51:14 --> Helper loaded: url_helper
INFO - 2019-01-01 08:51:14 --> Helper loaded: file_helper
INFO - 2019-01-01 08:51:14 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:51:14 --> Helper loaded: util_helper
INFO - 2019-01-01 08:51:14 --> Database Driver Class Initialized
INFO - 2019-01-01 08:51:14 --> Email Class Initialized
DEBUG - 2019-01-01 08:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:51:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:51:14 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:51:14 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:51:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:51:14 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:51:14 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:51:14 --> Helper loaded: date_helper
INFO - 2019-01-01 08:51:14 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:51:14 --> Controller Class Initialized
INFO - 2019-01-01 08:51:14 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:51:14 --> Final output sent to browser
DEBUG - 2019-01-01 08:51:14 --> Total execution time: 0.4888
INFO - 2019-01-01 08:52:52 --> Config Class Initialized
INFO - 2019-01-01 08:52:52 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:52:52 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:52:52 --> Utf8 Class Initialized
INFO - 2019-01-01 08:52:52 --> URI Class Initialized
DEBUG - 2019-01-01 08:52:52 --> No URI present. Default controller set.
INFO - 2019-01-01 08:52:52 --> Router Class Initialized
INFO - 2019-01-01 08:52:52 --> Output Class Initialized
INFO - 2019-01-01 08:52:52 --> Security Class Initialized
DEBUG - 2019-01-01 08:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:52:52 --> CSRF cookie sent
INFO - 2019-01-01 08:52:52 --> Input Class Initialized
INFO - 2019-01-01 08:52:52 --> Language Class Initialized
INFO - 2019-01-01 08:52:52 --> Loader Class Initialized
INFO - 2019-01-01 08:52:52 --> Helper loaded: url_helper
INFO - 2019-01-01 08:52:52 --> Helper loaded: file_helper
INFO - 2019-01-01 08:52:52 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:52:52 --> Helper loaded: util_helper
INFO - 2019-01-01 08:52:52 --> Database Driver Class Initialized
INFO - 2019-01-01 08:52:52 --> Email Class Initialized
DEBUG - 2019-01-01 08:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:52:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:52:52 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:52:52 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:52:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:52:52 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:52:52 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:52:52 --> Helper loaded: date_helper
INFO - 2019-01-01 08:52:52 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:52:52 --> Controller Class Initialized
INFO - 2019-01-01 08:52:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:52:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:52:52 --> Final output sent to browser
DEBUG - 2019-01-01 08:52:52 --> Total execution time: 0.4448
INFO - 2019-01-01 08:53:02 --> Config Class Initialized
INFO - 2019-01-01 08:53:02 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:53:02 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:53:02 --> Utf8 Class Initialized
INFO - 2019-01-01 08:53:02 --> URI Class Initialized
DEBUG - 2019-01-01 08:53:02 --> No URI present. Default controller set.
INFO - 2019-01-01 08:53:03 --> Router Class Initialized
INFO - 2019-01-01 08:53:03 --> Output Class Initialized
INFO - 2019-01-01 08:53:03 --> Security Class Initialized
DEBUG - 2019-01-01 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:53:03 --> CSRF cookie sent
INFO - 2019-01-01 08:53:03 --> Input Class Initialized
INFO - 2019-01-01 08:53:03 --> Language Class Initialized
INFO - 2019-01-01 08:53:03 --> Loader Class Initialized
INFO - 2019-01-01 08:53:03 --> Helper loaded: url_helper
INFO - 2019-01-01 08:53:03 --> Helper loaded: file_helper
INFO - 2019-01-01 08:53:03 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:53:03 --> Helper loaded: util_helper
INFO - 2019-01-01 08:53:03 --> Database Driver Class Initialized
INFO - 2019-01-01 08:53:03 --> Email Class Initialized
DEBUG - 2019-01-01 08:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:53:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:53:03 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:53:03 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:53:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:53:03 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:53:03 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:53:03 --> Helper loaded: date_helper
INFO - 2019-01-01 08:53:03 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:53:03 --> Controller Class Initialized
INFO - 2019-01-01 08:53:03 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:53:03 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:53:03 --> Final output sent to browser
DEBUG - 2019-01-01 08:53:03 --> Total execution time: 0.4470
INFO - 2019-01-01 08:53:20 --> Config Class Initialized
INFO - 2019-01-01 08:53:20 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:53:20 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:53:20 --> Utf8 Class Initialized
INFO - 2019-01-01 08:53:21 --> URI Class Initialized
DEBUG - 2019-01-01 08:53:21 --> No URI present. Default controller set.
INFO - 2019-01-01 08:53:21 --> Router Class Initialized
INFO - 2019-01-01 08:53:21 --> Output Class Initialized
INFO - 2019-01-01 08:53:21 --> Security Class Initialized
DEBUG - 2019-01-01 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:53:21 --> CSRF cookie sent
INFO - 2019-01-01 08:53:21 --> Input Class Initialized
INFO - 2019-01-01 08:53:21 --> Language Class Initialized
INFO - 2019-01-01 08:53:21 --> Loader Class Initialized
INFO - 2019-01-01 08:53:21 --> Helper loaded: url_helper
INFO - 2019-01-01 08:53:21 --> Helper loaded: file_helper
INFO - 2019-01-01 08:53:21 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:53:21 --> Helper loaded: util_helper
INFO - 2019-01-01 08:53:21 --> Database Driver Class Initialized
INFO - 2019-01-01 08:53:21 --> Email Class Initialized
DEBUG - 2019-01-01 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:53:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:53:21 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:53:21 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:53:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:53:21 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:53:21 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:53:21 --> Helper loaded: date_helper
INFO - 2019-01-01 08:53:21 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:53:21 --> Controller Class Initialized
INFO - 2019-01-01 08:53:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:53:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 08:53:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
ERROR - 2019-01-01 08:53:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes\argon-design-system\skeleton.php 16
INFO - 2019-01-01 08:53:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 08:53:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 08:53:21 --> Final output sent to browser
DEBUG - 2019-01-01 08:53:21 --> Total execution time: 0.6677
INFO - 2019-01-01 08:53:57 --> Config Class Initialized
INFO - 2019-01-01 08:53:57 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:53:57 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:53:57 --> Utf8 Class Initialized
INFO - 2019-01-01 08:53:57 --> URI Class Initialized
DEBUG - 2019-01-01 08:53:57 --> No URI present. Default controller set.
INFO - 2019-01-01 08:53:57 --> Router Class Initialized
INFO - 2019-01-01 08:53:57 --> Output Class Initialized
INFO - 2019-01-01 08:53:57 --> Security Class Initialized
DEBUG - 2019-01-01 08:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:53:57 --> CSRF cookie sent
INFO - 2019-01-01 08:53:57 --> Input Class Initialized
INFO - 2019-01-01 08:53:57 --> Language Class Initialized
INFO - 2019-01-01 08:53:57 --> Loader Class Initialized
INFO - 2019-01-01 08:53:57 --> Helper loaded: url_helper
INFO - 2019-01-01 08:53:57 --> Helper loaded: file_helper
INFO - 2019-01-01 08:53:57 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:53:57 --> Helper loaded: util_helper
INFO - 2019-01-01 08:53:57 --> Database Driver Class Initialized
INFO - 2019-01-01 08:53:57 --> Email Class Initialized
DEBUG - 2019-01-01 08:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:53:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:53:57 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:53:57 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:53:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:53:57 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:53:57 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:53:57 --> Helper loaded: date_helper
INFO - 2019-01-01 08:53:57 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:53:57 --> Controller Class Initialized
INFO - 2019-01-01 08:53:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 08:53:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 08:53:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 08:53:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 08:53:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 08:53:57 --> Final output sent to browser
DEBUG - 2019-01-01 08:53:57 --> Total execution time: 0.5524
INFO - 2019-01-01 08:56:20 --> Config Class Initialized
INFO - 2019-01-01 08:56:20 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:56:20 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:56:20 --> Utf8 Class Initialized
INFO - 2019-01-01 08:56:20 --> URI Class Initialized
INFO - 2019-01-01 08:56:20 --> Router Class Initialized
INFO - 2019-01-01 08:56:20 --> Output Class Initialized
INFO - 2019-01-01 08:56:20 --> Security Class Initialized
DEBUG - 2019-01-01 08:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:56:20 --> CSRF cookie sent
INFO - 2019-01-01 08:56:20 --> Input Class Initialized
INFO - 2019-01-01 08:56:20 --> Language Class Initialized
INFO - 2019-01-01 08:56:20 --> Loader Class Initialized
INFO - 2019-01-01 08:56:20 --> Helper loaded: url_helper
INFO - 2019-01-01 08:56:20 --> Helper loaded: file_helper
INFO - 2019-01-01 08:56:20 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:56:20 --> Helper loaded: util_helper
INFO - 2019-01-01 08:56:20 --> Database Driver Class Initialized
INFO - 2019-01-01 08:56:20 --> Email Class Initialized
DEBUG - 2019-01-01 08:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:56:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:56:21 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:56:21 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:56:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:56:21 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:56:21 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:56:21 --> Helper loaded: date_helper
INFO - 2019-01-01 08:56:21 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:56:21 --> Controller Class Initialized
DEBUG - 2019-01-01 08:56:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 08:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:56:21 --> Helper loaded: form_helper
INFO - 2019-01-01 08:56:21 --> Form Validation Class Initialized
INFO - 2019-01-01 08:56:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 08:56:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 08:56:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 08:56:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 08:56:21 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2019-01-01 08:56:21 --> Final output sent to browser
DEBUG - 2019-01-01 08:56:21 --> Total execution time: 0.7695
INFO - 2019-01-01 08:57:58 --> Config Class Initialized
INFO - 2019-01-01 08:57:58 --> Hooks Class Initialized
DEBUG - 2019-01-01 08:57:58 --> UTF-8 Support Enabled
INFO - 2019-01-01 08:57:58 --> Utf8 Class Initialized
INFO - 2019-01-01 08:57:58 --> URI Class Initialized
INFO - 2019-01-01 08:57:58 --> Router Class Initialized
INFO - 2019-01-01 08:57:58 --> Output Class Initialized
INFO - 2019-01-01 08:57:58 --> Security Class Initialized
DEBUG - 2019-01-01 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 08:57:58 --> CSRF cookie sent
INFO - 2019-01-01 08:57:58 --> Input Class Initialized
INFO - 2019-01-01 08:57:58 --> Language Class Initialized
INFO - 2019-01-01 08:57:58 --> Loader Class Initialized
INFO - 2019-01-01 08:57:58 --> Helper loaded: url_helper
INFO - 2019-01-01 08:57:58 --> Helper loaded: file_helper
INFO - 2019-01-01 08:57:58 --> Helper loaded: auth_helper
INFO - 2019-01-01 08:57:58 --> Helper loaded: util_helper
INFO - 2019-01-01 08:57:58 --> Database Driver Class Initialized
INFO - 2019-01-01 08:57:58 --> Email Class Initialized
DEBUG - 2019-01-01 08:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 08:57:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 08:57:58 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 08:57:58 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:57:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 08:57:58 --> Helper loaded: cookie_helper
INFO - 2019-01-01 08:57:58 --> Helper loaded: language_helper
DEBUG - 2019-01-01 08:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:57:58 --> Helper loaded: date_helper
INFO - 2019-01-01 08:57:58 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 08:57:58 --> Controller Class Initialized
DEBUG - 2019-01-01 08:57:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 08:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 08:57:58 --> Helper loaded: form_helper
INFO - 2019-01-01 08:57:58 --> Form Validation Class Initialized
INFO - 2019-01-01 08:57:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 08:57:58 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 08:57:58 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 08:57:58 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 08:57:58 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\login.php
INFO - 2019-01-01 08:57:58 --> Final output sent to browser
DEBUG - 2019-01-01 08:57:58 --> Total execution time: 0.5530
INFO - 2019-01-01 10:08:51 --> Config Class Initialized
INFO - 2019-01-01 10:08:51 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:08:51 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:08:51 --> Utf8 Class Initialized
INFO - 2019-01-01 10:08:51 --> URI Class Initialized
INFO - 2019-01-01 10:08:51 --> Router Class Initialized
INFO - 2019-01-01 10:08:51 --> Output Class Initialized
INFO - 2019-01-01 10:08:51 --> Security Class Initialized
DEBUG - 2019-01-01 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:08:51 --> CSRF cookie sent
INFO - 2019-01-01 10:08:51 --> Input Class Initialized
INFO - 2019-01-01 10:08:51 --> Language Class Initialized
INFO - 2019-01-01 10:08:51 --> Loader Class Initialized
INFO - 2019-01-01 10:08:51 --> Helper loaded: url_helper
INFO - 2019-01-01 10:08:51 --> Helper loaded: file_helper
INFO - 2019-01-01 10:08:51 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:08:51 --> Helper loaded: util_helper
INFO - 2019-01-01 10:08:51 --> Database Driver Class Initialized
INFO - 2019-01-01 10:08:51 --> Email Class Initialized
DEBUG - 2019-01-01 10:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:08:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:08:51 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:08:51 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:08:51 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:08:51 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:52 --> Helper loaded: date_helper
INFO - 2019-01-01 10:08:52 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:08:52 --> Controller Class Initialized
DEBUG - 2019-01-01 10:08:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:52 --> Helper loaded: form_helper
INFO - 2019-01-01 10:08:52 --> Form Validation Class Initialized
INFO - 2019-01-01 10:08:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:08:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/login.php
INFO - 2019-01-01 10:08:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:08:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:08:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:08:52 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:08:52 --> Final output sent to browser
DEBUG - 2019-01-01 10:08:52 --> Total execution time: 1.2720
INFO - 2019-01-01 10:08:55 --> Config Class Initialized
INFO - 2019-01-01 10:08:55 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:08:55 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:08:55 --> Utf8 Class Initialized
INFO - 2019-01-01 10:08:55 --> URI Class Initialized
INFO - 2019-01-01 10:08:55 --> Router Class Initialized
INFO - 2019-01-01 10:08:55 --> Output Class Initialized
INFO - 2019-01-01 10:08:55 --> Security Class Initialized
DEBUG - 2019-01-01 10:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:08:55 --> CSRF cookie sent
INFO - 2019-01-01 10:08:55 --> CSRF token verified
INFO - 2019-01-01 10:08:55 --> Input Class Initialized
INFO - 2019-01-01 10:08:55 --> Language Class Initialized
INFO - 2019-01-01 10:08:55 --> Loader Class Initialized
INFO - 2019-01-01 10:08:55 --> Helper loaded: url_helper
INFO - 2019-01-01 10:08:55 --> Helper loaded: file_helper
INFO - 2019-01-01 10:08:55 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:08:55 --> Helper loaded: util_helper
INFO - 2019-01-01 10:08:55 --> Database Driver Class Initialized
INFO - 2019-01-01 10:08:56 --> Email Class Initialized
DEBUG - 2019-01-01 10:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:08:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:08:56 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:08:56 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:08:56 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:08:56 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:56 --> Helper loaded: date_helper
INFO - 2019-01-01 10:08:56 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:08:56 --> Controller Class Initialized
DEBUG - 2019-01-01 10:08:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:56 --> Helper loaded: form_helper
INFO - 2019-01-01 10:08:56 --> Form Validation Class Initialized
INFO - 2019-01-01 10:08:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:08:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-01-01 10:08:56 --> Config Class Initialized
INFO - 2019-01-01 10:08:56 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:08:56 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:08:56 --> Utf8 Class Initialized
INFO - 2019-01-01 10:08:56 --> URI Class Initialized
INFO - 2019-01-01 10:08:56 --> Router Class Initialized
INFO - 2019-01-01 10:08:56 --> Output Class Initialized
INFO - 2019-01-01 10:08:56 --> Security Class Initialized
DEBUG - 2019-01-01 10:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:08:56 --> CSRF cookie sent
INFO - 2019-01-01 10:08:56 --> Input Class Initialized
INFO - 2019-01-01 10:08:56 --> Language Class Initialized
INFO - 2019-01-01 10:08:56 --> Loader Class Initialized
INFO - 2019-01-01 10:08:56 --> Helper loaded: url_helper
INFO - 2019-01-01 10:08:56 --> Helper loaded: file_helper
INFO - 2019-01-01 10:08:56 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:08:56 --> Helper loaded: util_helper
INFO - 2019-01-01 10:08:56 --> Database Driver Class Initialized
INFO - 2019-01-01 10:08:56 --> Email Class Initialized
DEBUG - 2019-01-01 10:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:08:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:08:56 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:08:56 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:08:56 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:08:56 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:56 --> Helper loaded: date_helper
INFO - 2019-01-01 10:08:56 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:08:56 --> Controller Class Initialized
DEBUG - 2019-01-01 10:08:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:08:57 --> Helper loaded: form_helper
INFO - 2019-01-01 10:08:57 --> Form Validation Class Initialized
INFO - 2019-01-01 10:08:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:08:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/login.php
INFO - 2019-01-01 10:08:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:08:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:08:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:08:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:08:57 --> Final output sent to browser
DEBUG - 2019-01-01 10:08:57 --> Total execution time: 0.5590
INFO - 2019-01-01 10:10:39 --> Config Class Initialized
INFO - 2019-01-01 10:10:39 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:10:39 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:10:39 --> Utf8 Class Initialized
INFO - 2019-01-01 10:10:39 --> URI Class Initialized
INFO - 2019-01-01 10:10:39 --> Router Class Initialized
INFO - 2019-01-01 10:10:39 --> Output Class Initialized
INFO - 2019-01-01 10:10:39 --> Security Class Initialized
DEBUG - 2019-01-01 10:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:10:39 --> CSRF cookie sent
INFO - 2019-01-01 10:10:39 --> Input Class Initialized
INFO - 2019-01-01 10:10:39 --> Language Class Initialized
INFO - 2019-01-01 10:10:39 --> Loader Class Initialized
INFO - 2019-01-01 10:10:39 --> Helper loaded: url_helper
INFO - 2019-01-01 10:10:39 --> Helper loaded: file_helper
INFO - 2019-01-01 10:10:39 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:10:39 --> Helper loaded: util_helper
INFO - 2019-01-01 10:10:39 --> Database Driver Class Initialized
INFO - 2019-01-01 10:10:39 --> Email Class Initialized
DEBUG - 2019-01-01 10:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:10:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:10:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:10:39 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:10:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:10:39 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:10:39 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:10:39 --> Helper loaded: date_helper
INFO - 2019-01-01 10:10:39 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:10:39 --> Controller Class Initialized
DEBUG - 2019-01-01 10:10:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:10:39 --> Helper loaded: form_helper
INFO - 2019-01-01 10:10:39 --> Form Validation Class Initialized
INFO - 2019-01-01 10:10:39 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:10:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/login.php
INFO - 2019-01-01 10:10:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:10:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:10:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:10:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:10:40 --> Final output sent to browser
DEBUG - 2019-01-01 10:10:40 --> Total execution time: 0.5539
INFO - 2019-01-01 10:11:05 --> Config Class Initialized
INFO - 2019-01-01 10:11:05 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:11:05 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:11:05 --> Utf8 Class Initialized
INFO - 2019-01-01 10:11:05 --> URI Class Initialized
INFO - 2019-01-01 10:11:05 --> Router Class Initialized
INFO - 2019-01-01 10:11:05 --> Output Class Initialized
INFO - 2019-01-01 10:11:05 --> Security Class Initialized
DEBUG - 2019-01-01 10:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:11:06 --> CSRF cookie sent
INFO - 2019-01-01 10:11:06 --> Input Class Initialized
INFO - 2019-01-01 10:11:06 --> Language Class Initialized
INFO - 2019-01-01 10:11:06 --> Loader Class Initialized
INFO - 2019-01-01 10:11:06 --> Helper loaded: url_helper
INFO - 2019-01-01 10:11:06 --> Helper loaded: file_helper
INFO - 2019-01-01 10:11:06 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:11:06 --> Helper loaded: util_helper
INFO - 2019-01-01 10:11:06 --> Database Driver Class Initialized
INFO - 2019-01-01 10:11:06 --> Email Class Initialized
DEBUG - 2019-01-01 10:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:11:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:11:06 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:11:06 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:11:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:11:06 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:11:06 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:11:06 --> Helper loaded: date_helper
INFO - 2019-01-01 10:11:06 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:11:06 --> Controller Class Initialized
DEBUG - 2019-01-01 10:11:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:11:06 --> Helper loaded: form_helper
INFO - 2019-01-01 10:11:06 --> Form Validation Class Initialized
INFO - 2019-01-01 10:11:06 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:11:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/login.php
INFO - 2019-01-01 10:11:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:11:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:11:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:11:06 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:11:06 --> Final output sent to browser
DEBUG - 2019-01-01 10:11:06 --> Total execution time: 0.5706
INFO - 2019-01-01 10:11:35 --> Config Class Initialized
INFO - 2019-01-01 10:11:35 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:11:35 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:11:35 --> Utf8 Class Initialized
INFO - 2019-01-01 10:11:35 --> URI Class Initialized
INFO - 2019-01-01 10:11:35 --> Router Class Initialized
INFO - 2019-01-01 10:11:35 --> Output Class Initialized
INFO - 2019-01-01 10:11:35 --> Security Class Initialized
DEBUG - 2019-01-01 10:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:11:35 --> CSRF cookie sent
INFO - 2019-01-01 10:11:35 --> Input Class Initialized
INFO - 2019-01-01 10:11:35 --> Language Class Initialized
INFO - 2019-01-01 10:11:36 --> Loader Class Initialized
INFO - 2019-01-01 10:11:36 --> Helper loaded: url_helper
INFO - 2019-01-01 10:11:36 --> Helper loaded: file_helper
INFO - 2019-01-01 10:11:36 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:11:36 --> Helper loaded: util_helper
INFO - 2019-01-01 10:11:36 --> Database Driver Class Initialized
INFO - 2019-01-01 10:11:36 --> Email Class Initialized
DEBUG - 2019-01-01 10:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:11:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:11:36 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:11:36 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:11:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:11:36 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:11:36 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:11:36 --> Helper loaded: date_helper
INFO - 2019-01-01 10:11:36 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:11:36 --> Controller Class Initialized
DEBUG - 2019-01-01 10:11:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:11:36 --> Helper loaded: form_helper
INFO - 2019-01-01 10:11:36 --> Form Validation Class Initialized
INFO - 2019-01-01 10:11:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:11:36 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\auth\create_user.php
INFO - 2019-01-01 10:11:36 --> Final output sent to browser
DEBUG - 2019-01-01 10:11:36 --> Total execution time: 0.5141
INFO - 2019-01-01 10:12:41 --> Config Class Initialized
INFO - 2019-01-01 10:12:41 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:12:41 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:12:41 --> Utf8 Class Initialized
INFO - 2019-01-01 10:12:41 --> URI Class Initialized
INFO - 2019-01-01 10:12:41 --> Router Class Initialized
INFO - 2019-01-01 10:12:41 --> Output Class Initialized
INFO - 2019-01-01 10:12:41 --> Security Class Initialized
DEBUG - 2019-01-01 10:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:12:41 --> CSRF cookie sent
INFO - 2019-01-01 10:12:41 --> Input Class Initialized
INFO - 2019-01-01 10:12:41 --> Language Class Initialized
INFO - 2019-01-01 10:12:41 --> Loader Class Initialized
INFO - 2019-01-01 10:12:41 --> Helper loaded: url_helper
INFO - 2019-01-01 10:12:41 --> Helper loaded: file_helper
INFO - 2019-01-01 10:12:41 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:12:41 --> Helper loaded: util_helper
INFO - 2019-01-01 10:12:41 --> Database Driver Class Initialized
INFO - 2019-01-01 10:12:41 --> Email Class Initialized
DEBUG - 2019-01-01 10:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:12:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:12:41 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:12:41 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:12:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:12:41 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:12:41 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:12:41 --> Helper loaded: date_helper
INFO - 2019-01-01 10:12:41 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:12:41 --> Controller Class Initialized
DEBUG - 2019-01-01 10:12:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:12:41 --> Helper loaded: form_helper
INFO - 2019-01-01 10:12:41 --> Form Validation Class Initialized
INFO - 2019-01-01 10:12:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:12:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/create_user.php
INFO - 2019-01-01 10:12:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:12:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:12:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:12:41 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:12:41 --> Final output sent to browser
DEBUG - 2019-01-01 10:12:41 --> Total execution time: 0.5655
INFO - 2019-01-01 10:12:54 --> Config Class Initialized
INFO - 2019-01-01 10:12:54 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:12:54 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:12:54 --> Utf8 Class Initialized
INFO - 2019-01-01 10:12:54 --> URI Class Initialized
INFO - 2019-01-01 10:12:54 --> Router Class Initialized
INFO - 2019-01-01 10:12:54 --> Output Class Initialized
INFO - 2019-01-01 10:12:54 --> Security Class Initialized
DEBUG - 2019-01-01 10:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:12:54 --> CSRF cookie sent
INFO - 2019-01-01 10:12:54 --> CSRF token verified
INFO - 2019-01-01 10:12:54 --> Input Class Initialized
INFO - 2019-01-01 10:12:54 --> Language Class Initialized
INFO - 2019-01-01 10:12:54 --> Loader Class Initialized
INFO - 2019-01-01 10:12:54 --> Helper loaded: url_helper
INFO - 2019-01-01 10:12:54 --> Helper loaded: file_helper
INFO - 2019-01-01 10:12:54 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:12:54 --> Helper loaded: util_helper
INFO - 2019-01-01 10:12:54 --> Database Driver Class Initialized
INFO - 2019-01-01 10:12:54 --> Email Class Initialized
DEBUG - 2019-01-01 10:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:12:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:12:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:12:54 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:12:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:12:54 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:12:54 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:12:54 --> Helper loaded: date_helper
INFO - 2019-01-01 10:12:54 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:12:54 --> Controller Class Initialized
DEBUG - 2019-01-01 10:12:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:12:54 --> Helper loaded: form_helper
INFO - 2019-01-01 10:12:54 --> Form Validation Class Initialized
INFO - 2019-01-01 10:12:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:12:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-01-01 10:12:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/create_user.php
INFO - 2019-01-01 10:12:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:12:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:12:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:12:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:12:54 --> Final output sent to browser
DEBUG - 2019-01-01 10:12:54 --> Total execution time: 0.6099
INFO - 2019-01-01 10:13:11 --> Config Class Initialized
INFO - 2019-01-01 10:13:11 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:13:11 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:13:11 --> Utf8 Class Initialized
INFO - 2019-01-01 10:13:11 --> URI Class Initialized
INFO - 2019-01-01 10:13:11 --> Router Class Initialized
INFO - 2019-01-01 10:13:11 --> Output Class Initialized
INFO - 2019-01-01 10:13:11 --> Security Class Initialized
DEBUG - 2019-01-01 10:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:13:11 --> CSRF cookie sent
INFO - 2019-01-01 10:13:11 --> CSRF token verified
INFO - 2019-01-01 10:13:11 --> Input Class Initialized
INFO - 2019-01-01 10:13:11 --> Language Class Initialized
INFO - 2019-01-01 10:13:11 --> Loader Class Initialized
INFO - 2019-01-01 10:13:11 --> Helper loaded: url_helper
INFO - 2019-01-01 10:13:11 --> Helper loaded: file_helper
INFO - 2019-01-01 10:13:11 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:13:11 --> Helper loaded: util_helper
INFO - 2019-01-01 10:13:11 --> Database Driver Class Initialized
INFO - 2019-01-01 10:13:11 --> Email Class Initialized
DEBUG - 2019-01-01 10:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:13:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:13:11 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:13:11 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:13:12 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:13:12 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:12 --> Helper loaded: date_helper
INFO - 2019-01-01 10:13:12 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:13:12 --> Controller Class Initialized
DEBUG - 2019-01-01 10:13:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:12 --> Helper loaded: form_helper
INFO - 2019-01-01 10:13:12 --> Form Validation Class Initialized
INFO - 2019-01-01 10:13:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:13:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-01-01 10:13:12 --> Config Class Initialized
INFO - 2019-01-01 10:13:12 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:13:12 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:13:12 --> Utf8 Class Initialized
INFO - 2019-01-01 10:13:12 --> URI Class Initialized
INFO - 2019-01-01 10:13:12 --> Router Class Initialized
INFO - 2019-01-01 10:13:12 --> Output Class Initialized
INFO - 2019-01-01 10:13:12 --> Security Class Initialized
DEBUG - 2019-01-01 10:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:13:12 --> CSRF cookie sent
INFO - 2019-01-01 10:13:12 --> Input Class Initialized
INFO - 2019-01-01 10:13:12 --> Language Class Initialized
INFO - 2019-01-01 10:13:13 --> Loader Class Initialized
INFO - 2019-01-01 10:13:13 --> Helper loaded: url_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: file_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: util_helper
INFO - 2019-01-01 10:13:13 --> Database Driver Class Initialized
INFO - 2019-01-01 10:13:13 --> Email Class Initialized
DEBUG - 2019-01-01 10:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:13:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:13:13 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:13:13 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:13:13 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:13 --> Helper loaded: date_helper
INFO - 2019-01-01 10:13:13 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:13:13 --> Controller Class Initialized
DEBUG - 2019-01-01 10:13:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:13 --> Helper loaded: form_helper
INFO - 2019-01-01 10:13:13 --> Form Validation Class Initialized
INFO - 2019-01-01 10:13:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:13:13 --> Config Class Initialized
INFO - 2019-01-01 10:13:13 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:13:13 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:13:13 --> Utf8 Class Initialized
INFO - 2019-01-01 10:13:13 --> URI Class Initialized
INFO - 2019-01-01 10:13:13 --> Router Class Initialized
INFO - 2019-01-01 10:13:13 --> Output Class Initialized
INFO - 2019-01-01 10:13:13 --> Security Class Initialized
DEBUG - 2019-01-01 10:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:13:13 --> CSRF cookie sent
INFO - 2019-01-01 10:13:13 --> Input Class Initialized
INFO - 2019-01-01 10:13:13 --> Language Class Initialized
INFO - 2019-01-01 10:13:13 --> Loader Class Initialized
INFO - 2019-01-01 10:13:13 --> Helper loaded: url_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: file_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: util_helper
INFO - 2019-01-01 10:13:13 --> Database Driver Class Initialized
INFO - 2019-01-01 10:13:13 --> Email Class Initialized
DEBUG - 2019-01-01 10:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:13:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:13:13 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:13:13 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:13:13 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:13:13 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:13 --> Helper loaded: date_helper
INFO - 2019-01-01 10:13:13 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:13:13 --> Controller Class Initialized
DEBUG - 2019-01-01 10:13:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:13 --> Helper loaded: form_helper
INFO - 2019-01-01 10:13:13 --> Form Validation Class Initialized
INFO - 2019-01-01 10:13:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:13:14 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/login.php
INFO - 2019-01-01 10:13:14 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:13:14 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:13:14 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:13:14 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:13:14 --> Final output sent to browser
DEBUG - 2019-01-01 10:13:14 --> Total execution time: 0.5747
INFO - 2019-01-01 10:13:28 --> Config Class Initialized
INFO - 2019-01-01 10:13:28 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:13:28 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:13:28 --> Utf8 Class Initialized
INFO - 2019-01-01 10:13:28 --> URI Class Initialized
INFO - 2019-01-01 10:13:28 --> Router Class Initialized
INFO - 2019-01-01 10:13:28 --> Output Class Initialized
INFO - 2019-01-01 10:13:28 --> Security Class Initialized
DEBUG - 2019-01-01 10:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:13:28 --> CSRF cookie sent
INFO - 2019-01-01 10:13:28 --> CSRF token verified
INFO - 2019-01-01 10:13:28 --> Input Class Initialized
INFO - 2019-01-01 10:13:28 --> Language Class Initialized
INFO - 2019-01-01 10:13:28 --> Loader Class Initialized
INFO - 2019-01-01 10:13:28 --> Helper loaded: url_helper
INFO - 2019-01-01 10:13:28 --> Helper loaded: file_helper
INFO - 2019-01-01 10:13:28 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:13:28 --> Helper loaded: util_helper
INFO - 2019-01-01 10:13:28 --> Database Driver Class Initialized
INFO - 2019-01-01 10:13:28 --> Email Class Initialized
DEBUG - 2019-01-01 10:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:13:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:13:28 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:13:28 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:13:28 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:13:28 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:28 --> Helper loaded: date_helper
INFO - 2019-01-01 10:13:28 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:13:28 --> Controller Class Initialized
DEBUG - 2019-01-01 10:13:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:28 --> Helper loaded: form_helper
INFO - 2019-01-01 10:13:28 --> Form Validation Class Initialized
INFO - 2019-01-01 10:13:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:13:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-01-01 10:13:29 --> Config Class Initialized
INFO - 2019-01-01 10:13:29 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:13:29 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:13:29 --> Utf8 Class Initialized
INFO - 2019-01-01 10:13:29 --> URI Class Initialized
DEBUG - 2019-01-01 10:13:29 --> No URI present. Default controller set.
INFO - 2019-01-01 10:13:29 --> Router Class Initialized
INFO - 2019-01-01 10:13:29 --> Output Class Initialized
INFO - 2019-01-01 10:13:29 --> Security Class Initialized
DEBUG - 2019-01-01 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:13:29 --> CSRF cookie sent
INFO - 2019-01-01 10:13:29 --> Input Class Initialized
INFO - 2019-01-01 10:13:29 --> Language Class Initialized
INFO - 2019-01-01 10:13:29 --> Loader Class Initialized
INFO - 2019-01-01 10:13:29 --> Helper loaded: url_helper
INFO - 2019-01-01 10:13:29 --> Helper loaded: file_helper
INFO - 2019-01-01 10:13:29 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:13:29 --> Helper loaded: util_helper
INFO - 2019-01-01 10:13:29 --> Database Driver Class Initialized
INFO - 2019-01-01 10:13:29 --> Email Class Initialized
DEBUG - 2019-01-01 10:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:13:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:13:29 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:13:29 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:13:29 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:13:29 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:29 --> Helper loaded: date_helper
INFO - 2019-01-01 10:13:29 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:13:29 --> Controller Class Initialized
INFO - 2019-01-01 10:13:29 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 10:13:29 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:13:29 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:13:29 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:13:29 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:13:29 --> Final output sent to browser
DEBUG - 2019-01-01 10:13:29 --> Total execution time: 0.5572
INFO - 2019-01-01 10:13:34 --> Config Class Initialized
INFO - 2019-01-01 10:13:34 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:13:34 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:13:34 --> Utf8 Class Initialized
INFO - 2019-01-01 10:13:34 --> URI Class Initialized
INFO - 2019-01-01 10:13:34 --> Router Class Initialized
INFO - 2019-01-01 10:13:34 --> Output Class Initialized
INFO - 2019-01-01 10:13:34 --> Security Class Initialized
DEBUG - 2019-01-01 10:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:13:34 --> CSRF cookie sent
INFO - 2019-01-01 10:13:34 --> Input Class Initialized
INFO - 2019-01-01 10:13:34 --> Language Class Initialized
INFO - 2019-01-01 10:13:34 --> Loader Class Initialized
INFO - 2019-01-01 10:13:34 --> Helper loaded: url_helper
INFO - 2019-01-01 10:13:34 --> Helper loaded: file_helper
INFO - 2019-01-01 10:13:34 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:13:34 --> Helper loaded: util_helper
INFO - 2019-01-01 10:13:34 --> Database Driver Class Initialized
INFO - 2019-01-01 10:13:34 --> Email Class Initialized
DEBUG - 2019-01-01 10:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:13:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:13:34 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:13:34 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:13:34 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:13:34 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:34 --> Helper loaded: date_helper
INFO - 2019-01-01 10:13:34 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:13:34 --> Controller Class Initialized
DEBUG - 2019-01-01 10:13:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 10:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:35 --> Helper loaded: form_helper
INFO - 2019-01-01 10:13:35 --> Form Validation Class Initialized
INFO - 2019-01-01 10:13:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 10:13:35 --> Config Class Initialized
INFO - 2019-01-01 10:13:35 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:13:35 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:13:35 --> Utf8 Class Initialized
INFO - 2019-01-01 10:13:35 --> URI Class Initialized
DEBUG - 2019-01-01 10:13:35 --> No URI present. Default controller set.
INFO - 2019-01-01 10:13:35 --> Router Class Initialized
INFO - 2019-01-01 10:13:35 --> Output Class Initialized
INFO - 2019-01-01 10:13:35 --> Security Class Initialized
DEBUG - 2019-01-01 10:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:13:35 --> CSRF cookie sent
INFO - 2019-01-01 10:13:35 --> Input Class Initialized
INFO - 2019-01-01 10:13:35 --> Language Class Initialized
INFO - 2019-01-01 10:13:35 --> Loader Class Initialized
INFO - 2019-01-01 10:13:35 --> Helper loaded: url_helper
INFO - 2019-01-01 10:13:35 --> Helper loaded: file_helper
INFO - 2019-01-01 10:13:35 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:13:35 --> Helper loaded: util_helper
INFO - 2019-01-01 10:13:35 --> Database Driver Class Initialized
INFO - 2019-01-01 10:13:35 --> Email Class Initialized
DEBUG - 2019-01-01 10:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:13:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:13:35 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:13:35 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:13:35 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:13:35 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:13:35 --> Helper loaded: date_helper
INFO - 2019-01-01 10:13:35 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:13:35 --> Controller Class Initialized
INFO - 2019-01-01 10:13:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 10:13:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:13:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:13:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:13:35 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:13:35 --> Final output sent to browser
DEBUG - 2019-01-01 10:13:35 --> Total execution time: 0.5573
INFO - 2019-01-01 10:44:18 --> Config Class Initialized
INFO - 2019-01-01 10:44:18 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:44:18 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:44:18 --> Utf8 Class Initialized
INFO - 2019-01-01 10:44:18 --> URI Class Initialized
DEBUG - 2019-01-01 10:44:18 --> No URI present. Default controller set.
INFO - 2019-01-01 10:44:18 --> Router Class Initialized
INFO - 2019-01-01 10:44:18 --> Output Class Initialized
INFO - 2019-01-01 10:44:18 --> Security Class Initialized
DEBUG - 2019-01-01 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:44:18 --> CSRF cookie sent
INFO - 2019-01-01 10:44:18 --> Input Class Initialized
INFO - 2019-01-01 10:44:18 --> Language Class Initialized
INFO - 2019-01-01 10:44:18 --> Loader Class Initialized
INFO - 2019-01-01 10:44:18 --> Helper loaded: url_helper
INFO - 2019-01-01 10:44:18 --> Helper loaded: file_helper
INFO - 2019-01-01 10:44:18 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:44:18 --> Helper loaded: util_helper
INFO - 2019-01-01 10:44:18 --> Database Driver Class Initialized
INFO - 2019-01-01 10:44:18 --> Email Class Initialized
DEBUG - 2019-01-01 10:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:44:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:44:19 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:44:19 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:44:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:44:19 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:44:19 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:44:19 --> Helper loaded: date_helper
INFO - 2019-01-01 10:44:19 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:44:19 --> Controller Class Initialized
INFO - 2019-01-01 10:44:19 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 10:44:19 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
ERROR - 2019-01-01 10:44:19 --> Severity: Warning --> First parameter must either be an object or the name of an existing class C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\util_helper.php 193
INFO - 2019-01-01 10:44:19 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:44:19 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:44:19 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:44:19 --> Final output sent to browser
DEBUG - 2019-01-01 10:44:19 --> Total execution time: 0.6888
INFO - 2019-01-01 10:48:24 --> Config Class Initialized
INFO - 2019-01-01 10:48:24 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:48:24 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:48:24 --> Utf8 Class Initialized
INFO - 2019-01-01 10:48:24 --> URI Class Initialized
DEBUG - 2019-01-01 10:48:24 --> No URI present. Default controller set.
INFO - 2019-01-01 10:48:24 --> Router Class Initialized
INFO - 2019-01-01 10:48:24 --> Output Class Initialized
INFO - 2019-01-01 10:48:24 --> Security Class Initialized
DEBUG - 2019-01-01 10:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:48:24 --> CSRF cookie sent
INFO - 2019-01-01 10:48:24 --> Input Class Initialized
INFO - 2019-01-01 10:48:25 --> Language Class Initialized
INFO - 2019-01-01 10:48:25 --> Loader Class Initialized
INFO - 2019-01-01 10:48:25 --> Helper loaded: url_helper
INFO - 2019-01-01 10:48:25 --> Helper loaded: file_helper
INFO - 2019-01-01 10:48:25 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:48:25 --> Helper loaded: util_helper
INFO - 2019-01-01 10:48:25 --> Database Driver Class Initialized
INFO - 2019-01-01 10:48:25 --> Email Class Initialized
DEBUG - 2019-01-01 10:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:48:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:48:25 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:48:25 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:48:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:48:25 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:48:25 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:48:25 --> Helper loaded: date_helper
INFO - 2019-01-01 10:48:25 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:48:25 --> Controller Class Initialized
ERROR - 2019-01-01 10:48:25 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\helpers\util_helper.php 188
INFO - 2019-01-01 10:49:21 --> Config Class Initialized
INFO - 2019-01-01 10:49:21 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:49:21 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:49:21 --> Utf8 Class Initialized
INFO - 2019-01-01 10:49:21 --> URI Class Initialized
DEBUG - 2019-01-01 10:49:21 --> No URI present. Default controller set.
INFO - 2019-01-01 10:49:21 --> Router Class Initialized
INFO - 2019-01-01 10:49:21 --> Output Class Initialized
INFO - 2019-01-01 10:49:21 --> Security Class Initialized
DEBUG - 2019-01-01 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:49:21 --> CSRF cookie sent
INFO - 2019-01-01 10:49:21 --> Input Class Initialized
INFO - 2019-01-01 10:49:21 --> Language Class Initialized
INFO - 2019-01-01 10:49:21 --> Loader Class Initialized
DEBUG - 2019-01-01 10:49:21 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 10:49:21 --> Helper loaded: url_helper
INFO - 2019-01-01 10:49:21 --> Helper loaded: file_helper
INFO - 2019-01-01 10:49:21 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:49:21 --> Helper loaded: util_helper
INFO - 2019-01-01 10:49:21 --> Database Driver Class Initialized
INFO - 2019-01-01 10:49:21 --> Email Class Initialized
DEBUG - 2019-01-01 10:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:49:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:49:21 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:49:21 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:49:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:49:21 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:49:21 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:49:21 --> Helper loaded: date_helper
INFO - 2019-01-01 10:49:21 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:49:21 --> Controller Class Initialized
INFO - 2019-01-01 10:50:11 --> Config Class Initialized
INFO - 2019-01-01 10:50:11 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:50:11 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:50:11 --> Utf8 Class Initialized
INFO - 2019-01-01 10:50:11 --> URI Class Initialized
DEBUG - 2019-01-01 10:50:11 --> No URI present. Default controller set.
INFO - 2019-01-01 10:50:11 --> Router Class Initialized
INFO - 2019-01-01 10:50:11 --> Output Class Initialized
INFO - 2019-01-01 10:50:11 --> Security Class Initialized
DEBUG - 2019-01-01 10:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:50:11 --> CSRF cookie sent
INFO - 2019-01-01 10:50:11 --> Input Class Initialized
INFO - 2019-01-01 10:50:11 --> Language Class Initialized
INFO - 2019-01-01 10:50:11 --> Loader Class Initialized
INFO - 2019-01-01 10:50:34 --> Config Class Initialized
INFO - 2019-01-01 10:50:34 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:50:34 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:50:34 --> Utf8 Class Initialized
INFO - 2019-01-01 10:50:34 --> URI Class Initialized
DEBUG - 2019-01-01 10:50:34 --> No URI present. Default controller set.
INFO - 2019-01-01 10:50:34 --> Router Class Initialized
INFO - 2019-01-01 10:50:34 --> Output Class Initialized
INFO - 2019-01-01 10:50:34 --> Security Class Initialized
DEBUG - 2019-01-01 10:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:50:34 --> CSRF cookie sent
INFO - 2019-01-01 10:50:34 --> Input Class Initialized
INFO - 2019-01-01 10:50:34 --> Language Class Initialized
INFO - 2019-01-01 10:50:34 --> Loader Class Initialized
DEBUG - 2019-01-01 10:50:34 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 10:50:34 --> Helper loaded: url_helper
INFO - 2019-01-01 10:50:34 --> Helper loaded: file_helper
INFO - 2019-01-01 10:50:34 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:50:34 --> Helper loaded: util_helper
INFO - 2019-01-01 10:50:34 --> Database Driver Class Initialized
INFO - 2019-01-01 10:50:34 --> Email Class Initialized
DEBUG - 2019-01-01 10:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:50:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:50:34 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:50:34 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:50:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:50:34 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:50:34 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:50:34 --> Helper loaded: date_helper
INFO - 2019-01-01 10:50:34 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:50:34 --> Controller Class Initialized
INFO - 2019-01-01 10:50:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 10:50:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:50:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:50:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:50:34 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:50:34 --> Final output sent to browser
DEBUG - 2019-01-01 10:50:35 --> Total execution time: 0.5784
INFO - 2019-01-01 10:50:49 --> Config Class Initialized
INFO - 2019-01-01 10:50:49 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:50:49 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:50:49 --> Utf8 Class Initialized
INFO - 2019-01-01 10:50:49 --> URI Class Initialized
DEBUG - 2019-01-01 10:50:49 --> No URI present. Default controller set.
INFO - 2019-01-01 10:50:49 --> Router Class Initialized
INFO - 2019-01-01 10:50:49 --> Output Class Initialized
INFO - 2019-01-01 10:50:49 --> Security Class Initialized
DEBUG - 2019-01-01 10:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:50:49 --> CSRF cookie sent
INFO - 2019-01-01 10:50:49 --> Input Class Initialized
INFO - 2019-01-01 10:50:49 --> Language Class Initialized
INFO - 2019-01-01 10:50:49 --> Loader Class Initialized
DEBUG - 2019-01-01 10:50:49 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 10:50:49 --> Helper loaded: url_helper
INFO - 2019-01-01 10:50:49 --> Helper loaded: file_helper
INFO - 2019-01-01 10:50:49 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:50:49 --> Helper loaded: util_helper
INFO - 2019-01-01 10:50:49 --> Database Driver Class Initialized
INFO - 2019-01-01 10:50:49 --> Email Class Initialized
DEBUG - 2019-01-01 10:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:50:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:50:49 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:50:49 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:50:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:50:49 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:50:49 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:50:49 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:50:49 --> Helper loaded: date_helper
INFO - 2019-01-01 10:50:49 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:50:49 --> Controller Class Initialized
INFO - 2019-01-01 10:50:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 10:50:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:50:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:50:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:50:49 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:50:49 --> Final output sent to browser
DEBUG - 2019-01-01 10:50:49 --> Total execution time: 0.6611
INFO - 2019-01-01 10:58:05 --> Config Class Initialized
INFO - 2019-01-01 10:58:05 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:58:05 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:58:05 --> Utf8 Class Initialized
INFO - 2019-01-01 10:58:05 --> URI Class Initialized
DEBUG - 2019-01-01 10:58:05 --> No URI present. Default controller set.
INFO - 2019-01-01 10:58:05 --> Router Class Initialized
INFO - 2019-01-01 10:58:05 --> Output Class Initialized
INFO - 2019-01-01 10:58:05 --> Security Class Initialized
DEBUG - 2019-01-01 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:58:05 --> CSRF cookie sent
INFO - 2019-01-01 10:58:05 --> Input Class Initialized
INFO - 2019-01-01 10:58:05 --> Language Class Initialized
INFO - 2019-01-01 10:58:05 --> Loader Class Initialized
DEBUG - 2019-01-01 10:58:05 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 10:58:05 --> Helper loaded: url_helper
INFO - 2019-01-01 10:58:05 --> Helper loaded: file_helper
INFO - 2019-01-01 10:58:05 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:58:05 --> Helper loaded: util_helper
INFO - 2019-01-01 10:58:05 --> Database Driver Class Initialized
INFO - 2019-01-01 10:58:05 --> Email Class Initialized
DEBUG - 2019-01-01 10:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:58:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:58:05 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:58:05 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:58:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:58:05 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:58:05 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:58:05 --> Helper loaded: date_helper
INFO - 2019-01-01 10:58:05 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:58:05 --> Controller Class Initialized
INFO - 2019-01-01 10:58:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 10:58:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
ERROR - 2019-01-01 10:58:05 --> Severity: Notice --> Undefined variable: GOOGLE_ANALYTICS C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common\google_analytics.php 2
ERROR - 2019-01-01 10:58:05 --> Severity: Notice --> Undefined variable: GOOGLE_ANALYTICS C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common\google_analytics.php 8
INFO - 2019-01-01 10:58:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 10:58:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:58:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:58:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:58:05 --> Final output sent to browser
DEBUG - 2019-01-01 10:58:05 --> Total execution time: 0.6226
INFO - 2019-01-01 10:59:12 --> Config Class Initialized
INFO - 2019-01-01 10:59:12 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:59:12 --> UTF-8 Support Enabled
INFO - 2019-01-01 10:59:12 --> Utf8 Class Initialized
INFO - 2019-01-01 10:59:12 --> URI Class Initialized
DEBUG - 2019-01-01 10:59:12 --> No URI present. Default controller set.
INFO - 2019-01-01 10:59:13 --> Router Class Initialized
INFO - 2019-01-01 10:59:13 --> Output Class Initialized
INFO - 2019-01-01 10:59:13 --> Security Class Initialized
DEBUG - 2019-01-01 10:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 10:59:13 --> CSRF cookie sent
INFO - 2019-01-01 10:59:13 --> Input Class Initialized
INFO - 2019-01-01 10:59:13 --> Language Class Initialized
INFO - 2019-01-01 10:59:13 --> Loader Class Initialized
DEBUG - 2019-01-01 10:59:13 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 10:59:13 --> Helper loaded: url_helper
INFO - 2019-01-01 10:59:13 --> Helper loaded: file_helper
INFO - 2019-01-01 10:59:13 --> Helper loaded: auth_helper
INFO - 2019-01-01 10:59:13 --> Helper loaded: util_helper
INFO - 2019-01-01 10:59:13 --> Database Driver Class Initialized
INFO - 2019-01-01 10:59:13 --> Email Class Initialized
DEBUG - 2019-01-01 10:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 10:59:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 10:59:13 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 10:59:13 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:59:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 10:59:13 --> Helper loaded: cookie_helper
INFO - 2019-01-01 10:59:13 --> Helper loaded: language_helper
DEBUG - 2019-01-01 10:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 10:59:13 --> Helper loaded: date_helper
INFO - 2019-01-01 10:59:13 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 10:59:13 --> Controller Class Initialized
INFO - 2019-01-01 10:59:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 10:59:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 10:59:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 10:59:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 10:59:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 10:59:13 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 10:59:13 --> Final output sent to browser
DEBUG - 2019-01-01 10:59:13 --> Total execution time: 0.5832
INFO - 2019-01-01 11:12:26 --> Config Class Initialized
INFO - 2019-01-01 11:12:26 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:12:26 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:12:26 --> Utf8 Class Initialized
INFO - 2019-01-01 11:12:26 --> URI Class Initialized
DEBUG - 2019-01-01 11:12:26 --> No URI present. Default controller set.
INFO - 2019-01-01 11:12:26 --> Router Class Initialized
INFO - 2019-01-01 11:12:26 --> Output Class Initialized
INFO - 2019-01-01 11:12:26 --> Security Class Initialized
DEBUG - 2019-01-01 11:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:12:26 --> CSRF cookie sent
INFO - 2019-01-01 11:12:26 --> Input Class Initialized
INFO - 2019-01-01 11:12:26 --> Language Class Initialized
INFO - 2019-01-01 11:12:26 --> Loader Class Initialized
DEBUG - 2019-01-01 11:12:26 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:12:26 --> Helper loaded: url_helper
INFO - 2019-01-01 11:12:26 --> Helper loaded: file_helper
INFO - 2019-01-01 11:12:26 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:12:26 --> Helper loaded: util_helper
INFO - 2019-01-01 11:12:26 --> Database Driver Class Initialized
INFO - 2019-01-01 11:12:26 --> Email Class Initialized
DEBUG - 2019-01-01 11:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:12:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:12:26 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:12:26 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:12:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:12:26 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:12:26 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:12:26 --> Helper loaded: date_helper
INFO - 2019-01-01 11:12:26 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:12:26 --> Controller Class Initialized
INFO - 2019-01-01 11:12:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:12:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:12:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 11:12:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:12:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:12:26 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:12:26 --> Final output sent to browser
DEBUG - 2019-01-01 11:12:26 --> Total execution time: 0.6086
INFO - 2019-01-01 11:12:56 --> Config Class Initialized
INFO - 2019-01-01 11:12:56 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:12:56 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:12:56 --> Utf8 Class Initialized
INFO - 2019-01-01 11:12:56 --> URI Class Initialized
INFO - 2019-01-01 11:12:56 --> Router Class Initialized
INFO - 2019-01-01 11:12:56 --> Output Class Initialized
INFO - 2019-01-01 11:12:56 --> Security Class Initialized
DEBUG - 2019-01-01 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:12:56 --> CSRF cookie sent
INFO - 2019-01-01 11:12:56 --> Input Class Initialized
INFO - 2019-01-01 11:12:56 --> Language Class Initialized
INFO - 2019-01-01 11:12:56 --> Loader Class Initialized
DEBUG - 2019-01-01 11:12:57 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:12:57 --> Helper loaded: url_helper
INFO - 2019-01-01 11:12:57 --> Helper loaded: file_helper
INFO - 2019-01-01 11:12:57 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:12:57 --> Helper loaded: util_helper
INFO - 2019-01-01 11:12:57 --> Database Driver Class Initialized
INFO - 2019-01-01 11:12:57 --> Email Class Initialized
DEBUG - 2019-01-01 11:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:12:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:12:57 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:12:57 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:12:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:12:57 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:12:57 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:12:57 --> Helper loaded: date_helper
INFO - 2019-01-01 11:12:57 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:12:57 --> Controller Class Initialized
DEBUG - 2019-01-01 11:12:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 11:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:12:57 --> Helper loaded: form_helper
INFO - 2019-01-01 11:12:57 --> Form Validation Class Initialized
INFO - 2019-01-01 11:12:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 11:12:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/login.php
INFO - 2019-01-01 11:12:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:12:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 11:12:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:12:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:12:57 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:12:57 --> Final output sent to browser
DEBUG - 2019-01-01 11:12:57 --> Total execution time: 0.7186
INFO - 2019-01-01 11:13:01 --> Config Class Initialized
INFO - 2019-01-01 11:13:01 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:13:01 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:13:01 --> Utf8 Class Initialized
INFO - 2019-01-01 11:13:01 --> URI Class Initialized
INFO - 2019-01-01 11:13:01 --> Router Class Initialized
INFO - 2019-01-01 11:13:01 --> Output Class Initialized
INFO - 2019-01-01 11:13:01 --> Security Class Initialized
DEBUG - 2019-01-01 11:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:13:01 --> CSRF cookie sent
INFO - 2019-01-01 11:13:01 --> Input Class Initialized
INFO - 2019-01-01 11:13:01 --> Language Class Initialized
INFO - 2019-01-01 11:13:01 --> Loader Class Initialized
DEBUG - 2019-01-01 11:13:01 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:13:01 --> Helper loaded: url_helper
INFO - 2019-01-01 11:13:01 --> Helper loaded: file_helper
INFO - 2019-01-01 11:13:01 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:13:01 --> Helper loaded: util_helper
INFO - 2019-01-01 11:13:01 --> Database Driver Class Initialized
INFO - 2019-01-01 11:13:01 --> Email Class Initialized
DEBUG - 2019-01-01 11:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:13:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:13:01 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:13:01 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:13:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:13:01 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:13:01 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:13:01 --> Helper loaded: date_helper
INFO - 2019-01-01 11:13:01 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:13:01 --> Controller Class Initialized
DEBUG - 2019-01-01 11:13:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 11:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:13:01 --> Helper loaded: form_helper
INFO - 2019-01-01 11:13:01 --> Form Validation Class Initialized
INFO - 2019-01-01 11:13:01 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 11:13:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/create_user.php
INFO - 2019-01-01 11:13:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:13:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 11:13:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:13:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:13:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:13:01 --> Final output sent to browser
DEBUG - 2019-01-01 11:13:01 --> Total execution time: 0.6516
INFO - 2019-01-01 11:13:17 --> Config Class Initialized
INFO - 2019-01-01 11:13:17 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:13:17 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:13:17 --> Utf8 Class Initialized
INFO - 2019-01-01 11:13:17 --> URI Class Initialized
DEBUG - 2019-01-01 11:13:17 --> No URI present. Default controller set.
INFO - 2019-01-01 11:13:17 --> Router Class Initialized
INFO - 2019-01-01 11:13:17 --> Output Class Initialized
INFO - 2019-01-01 11:13:17 --> Security Class Initialized
DEBUG - 2019-01-01 11:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:13:17 --> CSRF cookie sent
INFO - 2019-01-01 11:13:17 --> Input Class Initialized
INFO - 2019-01-01 11:13:17 --> Language Class Initialized
INFO - 2019-01-01 11:13:17 --> Loader Class Initialized
DEBUG - 2019-01-01 11:13:17 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:13:17 --> Helper loaded: url_helper
INFO - 2019-01-01 11:13:17 --> Helper loaded: file_helper
INFO - 2019-01-01 11:13:17 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:13:17 --> Helper loaded: util_helper
INFO - 2019-01-01 11:13:17 --> Database Driver Class Initialized
INFO - 2019-01-01 11:13:17 --> Email Class Initialized
DEBUG - 2019-01-01 11:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:13:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:13:17 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:13:17 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:13:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:13:17 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:13:17 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:13:18 --> Helper loaded: date_helper
INFO - 2019-01-01 11:13:18 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:13:18 --> Controller Class Initialized
INFO - 2019-01-01 11:13:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:13:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:13:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 11:13:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:13:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:13:18 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:13:18 --> Final output sent to browser
DEBUG - 2019-01-01 11:13:18 --> Total execution time: 0.7007
INFO - 2019-01-01 11:14:53 --> Config Class Initialized
INFO - 2019-01-01 11:14:53 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:14:53 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:14:53 --> Utf8 Class Initialized
INFO - 2019-01-01 11:14:53 --> URI Class Initialized
INFO - 2019-01-01 11:14:53 --> Router Class Initialized
INFO - 2019-01-01 11:14:53 --> Output Class Initialized
INFO - 2019-01-01 11:14:53 --> Security Class Initialized
DEBUG - 2019-01-01 11:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:14:53 --> CSRF cookie sent
INFO - 2019-01-01 11:14:53 --> Input Class Initialized
INFO - 2019-01-01 11:14:53 --> Language Class Initialized
INFO - 2019-01-01 11:14:53 --> Loader Class Initialized
DEBUG - 2019-01-01 11:14:53 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:14:53 --> Helper loaded: url_helper
INFO - 2019-01-01 11:14:53 --> Helper loaded: file_helper
INFO - 2019-01-01 11:14:53 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:14:53 --> Helper loaded: util_helper
INFO - 2019-01-01 11:14:53 --> Database Driver Class Initialized
INFO - 2019-01-01 11:14:53 --> Email Class Initialized
DEBUG - 2019-01-01 11:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:14:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:14:54 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:14:54 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:14:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:14:54 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:14:54 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:14:54 --> Helper loaded: date_helper
INFO - 2019-01-01 11:14:54 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:14:54 --> Controller Class Initialized
DEBUG - 2019-01-01 11:14:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2019-01-01 11:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:14:54 --> Helper loaded: form_helper
INFO - 2019-01-01 11:14:54 --> Form Validation Class Initialized
INFO - 2019-01-01 11:14:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-01-01 11:14:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/login.php
INFO - 2019-01-01 11:14:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:14:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 11:14:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:14:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:14:54 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:14:54 --> Final output sent to browser
DEBUG - 2019-01-01 11:14:54 --> Total execution time: 0.7103
INFO - 2019-01-01 11:14:59 --> Config Class Initialized
INFO - 2019-01-01 11:14:59 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:14:59 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:14:59 --> Utf8 Class Initialized
INFO - 2019-01-01 11:14:59 --> URI Class Initialized
DEBUG - 2019-01-01 11:14:59 --> No URI present. Default controller set.
INFO - 2019-01-01 11:14:59 --> Router Class Initialized
INFO - 2019-01-01 11:14:59 --> Output Class Initialized
INFO - 2019-01-01 11:14:59 --> Security Class Initialized
DEBUG - 2019-01-01 11:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:14:59 --> CSRF cookie sent
INFO - 2019-01-01 11:14:59 --> Input Class Initialized
INFO - 2019-01-01 11:14:59 --> Language Class Initialized
INFO - 2019-01-01 11:14:59 --> Loader Class Initialized
DEBUG - 2019-01-01 11:14:59 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:14:59 --> Helper loaded: url_helper
INFO - 2019-01-01 11:14:59 --> Helper loaded: file_helper
INFO - 2019-01-01 11:14:59 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:14:59 --> Helper loaded: util_helper
INFO - 2019-01-01 11:15:00 --> Database Driver Class Initialized
INFO - 2019-01-01 11:15:00 --> Email Class Initialized
DEBUG - 2019-01-01 11:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:15:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:15:00 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:15:00 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:15:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:15:00 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:15:00 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:15:00 --> Helper loaded: date_helper
INFO - 2019-01-01 11:15:00 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:15:00 --> Controller Class Initialized
INFO - 2019-01-01 11:15:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:15:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:15:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\common/google_analytics.php
INFO - 2019-01-01 11:15:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:15:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:15:00 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:15:00 --> Final output sent to browser
DEBUG - 2019-01-01 11:15:00 --> Total execution time: 0.6091
INFO - 2019-01-01 11:30:38 --> Config Class Initialized
INFO - 2019-01-01 11:30:38 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:30:38 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:30:38 --> Utf8 Class Initialized
INFO - 2019-01-01 11:30:38 --> URI Class Initialized
DEBUG - 2019-01-01 11:30:39 --> No URI present. Default controller set.
INFO - 2019-01-01 11:30:39 --> Router Class Initialized
INFO - 2019-01-01 11:30:39 --> Output Class Initialized
INFO - 2019-01-01 11:30:39 --> Security Class Initialized
DEBUG - 2019-01-01 11:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:30:39 --> CSRF cookie sent
INFO - 2019-01-01 11:30:39 --> Input Class Initialized
INFO - 2019-01-01 11:30:39 --> Language Class Initialized
INFO - 2019-01-01 11:30:39 --> Loader Class Initialized
DEBUG - 2019-01-01 11:30:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:30:39 --> Helper loaded: url_helper
INFO - 2019-01-01 11:30:39 --> Helper loaded: file_helper
INFO - 2019-01-01 11:30:39 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:30:39 --> Helper loaded: util_helper
INFO - 2019-01-01 11:30:39 --> Database Driver Class Initialized
INFO - 2019-01-01 11:30:39 --> Email Class Initialized
DEBUG - 2019-01-01 11:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:30:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:30:39 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:30:39 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:30:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:30:39 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:30:39 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:30:39 --> Helper loaded: date_helper
INFO - 2019-01-01 11:30:39 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:30:39 --> Controller Class Initialized
INFO - 2019-01-01 11:30:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:30:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:30:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:30:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:30:39 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:30:39 --> Final output sent to browser
DEBUG - 2019-01-01 11:30:39 --> Total execution time: 0.6931
INFO - 2019-01-01 11:37:44 --> Config Class Initialized
INFO - 2019-01-01 11:37:44 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:37:44 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:37:44 --> Utf8 Class Initialized
INFO - 2019-01-01 11:37:44 --> URI Class Initialized
DEBUG - 2019-01-01 11:37:44 --> No URI present. Default controller set.
INFO - 2019-01-01 11:37:44 --> Router Class Initialized
INFO - 2019-01-01 11:37:44 --> Output Class Initialized
INFO - 2019-01-01 11:37:44 --> Security Class Initialized
DEBUG - 2019-01-01 11:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:37:44 --> CSRF cookie sent
INFO - 2019-01-01 11:37:44 --> Input Class Initialized
INFO - 2019-01-01 11:37:44 --> Language Class Initialized
INFO - 2019-01-01 11:37:44 --> Loader Class Initialized
DEBUG - 2019-01-01 11:37:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:37:44 --> Helper loaded: url_helper
INFO - 2019-01-01 11:37:44 --> Helper loaded: file_helper
INFO - 2019-01-01 11:37:44 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:37:44 --> Helper loaded: util_helper
INFO - 2019-01-01 11:37:44 --> Database Driver Class Initialized
INFO - 2019-01-01 11:37:44 --> Email Class Initialized
DEBUG - 2019-01-01 11:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:37:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:37:44 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:37:44 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:37:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:37:44 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:37:44 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:37:44 --> Helper loaded: date_helper
INFO - 2019-01-01 11:37:44 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:37:45 --> Controller Class Initialized
INFO - 2019-01-01 11:37:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:37:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:37:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:37:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:37:45 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:37:45 --> Final output sent to browser
DEBUG - 2019-01-01 11:37:45 --> Total execution time: 0.6668
INFO - 2019-01-01 11:38:22 --> Config Class Initialized
INFO - 2019-01-01 11:38:22 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:38:22 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:38:22 --> Utf8 Class Initialized
INFO - 2019-01-01 11:38:22 --> URI Class Initialized
DEBUG - 2019-01-01 11:38:22 --> No URI present. Default controller set.
INFO - 2019-01-01 11:38:22 --> Router Class Initialized
INFO - 2019-01-01 11:38:22 --> Output Class Initialized
INFO - 2019-01-01 11:38:22 --> Security Class Initialized
DEBUG - 2019-01-01 11:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:38:22 --> CSRF cookie sent
INFO - 2019-01-01 11:38:22 --> Input Class Initialized
INFO - 2019-01-01 11:38:22 --> Language Class Initialized
INFO - 2019-01-01 11:38:22 --> Loader Class Initialized
DEBUG - 2019-01-01 11:38:22 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:38:22 --> Helper loaded: url_helper
INFO - 2019-01-01 11:38:22 --> Helper loaded: file_helper
INFO - 2019-01-01 11:38:22 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:38:22 --> Helper loaded: util_helper
INFO - 2019-01-01 11:38:23 --> Database Driver Class Initialized
INFO - 2019-01-01 11:38:23 --> Email Class Initialized
DEBUG - 2019-01-01 11:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:38:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:38:23 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:38:23 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:38:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:38:23 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:38:23 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:38:23 --> Helper loaded: date_helper
INFO - 2019-01-01 11:38:23 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:38:23 --> Controller Class Initialized
INFO - 2019-01-01 11:38:23 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:38:23 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:38:23 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:38:23 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:38:23 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:38:23 --> Final output sent to browser
DEBUG - 2019-01-01 11:38:23 --> Total execution time: 0.6423
INFO - 2019-01-01 11:39:46 --> Config Class Initialized
INFO - 2019-01-01 11:39:46 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:39:46 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:39:46 --> Utf8 Class Initialized
INFO - 2019-01-01 11:39:46 --> URI Class Initialized
DEBUG - 2019-01-01 11:39:46 --> No URI present. Default controller set.
INFO - 2019-01-01 11:39:46 --> Router Class Initialized
INFO - 2019-01-01 11:39:46 --> Output Class Initialized
INFO - 2019-01-01 11:39:46 --> Security Class Initialized
DEBUG - 2019-01-01 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:39:46 --> CSRF cookie sent
INFO - 2019-01-01 11:39:46 --> Input Class Initialized
INFO - 2019-01-01 11:39:46 --> Language Class Initialized
INFO - 2019-01-01 11:39:46 --> Loader Class Initialized
DEBUG - 2019-01-01 11:39:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:39:46 --> Helper loaded: url_helper
INFO - 2019-01-01 11:39:46 --> Helper loaded: file_helper
INFO - 2019-01-01 11:39:46 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:39:46 --> Helper loaded: util_helper
INFO - 2019-01-01 11:39:46 --> Database Driver Class Initialized
INFO - 2019-01-01 11:39:46 --> Email Class Initialized
DEBUG - 2019-01-01 11:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:39:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:39:46 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:39:46 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:39:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:39:46 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:39:46 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:39:46 --> Helper loaded: date_helper
INFO - 2019-01-01 11:39:46 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:39:46 --> Controller Class Initialized
INFO - 2019-01-01 11:39:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:39:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:39:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:39:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:39:46 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:39:46 --> Final output sent to browser
DEBUG - 2019-01-01 11:39:46 --> Total execution time: 0.6343
INFO - 2019-01-01 11:52:00 --> Config Class Initialized
INFO - 2019-01-01 11:52:00 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:52:00 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:52:00 --> Utf8 Class Initialized
INFO - 2019-01-01 11:52:00 --> URI Class Initialized
DEBUG - 2019-01-01 11:52:00 --> No URI present. Default controller set.
INFO - 2019-01-01 11:52:00 --> Router Class Initialized
INFO - 2019-01-01 11:52:00 --> Output Class Initialized
INFO - 2019-01-01 11:52:00 --> Security Class Initialized
DEBUG - 2019-01-01 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:52:01 --> CSRF cookie sent
INFO - 2019-01-01 11:52:01 --> Input Class Initialized
INFO - 2019-01-01 11:52:01 --> Language Class Initialized
INFO - 2019-01-01 11:52:01 --> Loader Class Initialized
DEBUG - 2019-01-01 11:52:01 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:52:01 --> Helper loaded: url_helper
INFO - 2019-01-01 11:52:01 --> Helper loaded: file_helper
INFO - 2019-01-01 11:52:01 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:52:01 --> Helper loaded: util_helper
INFO - 2019-01-01 11:52:01 --> Database Driver Class Initialized
INFO - 2019-01-01 11:52:01 --> Email Class Initialized
DEBUG - 2019-01-01 11:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:52:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:52:01 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:52:01 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:52:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:52:01 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:52:01 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:52:01 --> Helper loaded: date_helper
INFO - 2019-01-01 11:52:01 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:52:01 --> Controller Class Initialized
INFO - 2019-01-01 11:52:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:52:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:52:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:52:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:52:01 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:52:01 --> Final output sent to browser
DEBUG - 2019-01-01 11:52:01 --> Total execution time: 0.6662
INFO - 2019-01-01 11:53:27 --> Config Class Initialized
INFO - 2019-01-01 11:53:27 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:53:27 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:53:27 --> Utf8 Class Initialized
INFO - 2019-01-01 11:53:27 --> URI Class Initialized
DEBUG - 2019-01-01 11:53:27 --> No URI present. Default controller set.
INFO - 2019-01-01 11:53:27 --> Router Class Initialized
INFO - 2019-01-01 11:53:27 --> Output Class Initialized
INFO - 2019-01-01 11:53:27 --> Security Class Initialized
DEBUG - 2019-01-01 11:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:53:27 --> CSRF cookie sent
INFO - 2019-01-01 11:53:27 --> Input Class Initialized
INFO - 2019-01-01 11:53:27 --> Language Class Initialized
INFO - 2019-01-01 11:53:27 --> Loader Class Initialized
DEBUG - 2019-01-01 11:53:27 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:53:27 --> Helper loaded: url_helper
INFO - 2019-01-01 11:53:27 --> Helper loaded: file_helper
INFO - 2019-01-01 11:53:27 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:53:27 --> Helper loaded: util_helper
INFO - 2019-01-01 11:53:27 --> Database Driver Class Initialized
INFO - 2019-01-01 11:53:27 --> Email Class Initialized
DEBUG - 2019-01-01 11:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:53:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:53:27 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:53:27 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:53:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:53:27 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:53:27 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:53:27 --> Helper loaded: date_helper
INFO - 2019-01-01 11:53:27 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:53:27 --> Controller Class Initialized
INFO - 2019-01-01 11:53:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:53:27 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:53:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:53:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:53:28 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:53:28 --> Final output sent to browser
DEBUG - 2019-01-01 11:53:28 --> Total execution time: 0.6617
INFO - 2019-01-01 11:54:39 --> Config Class Initialized
INFO - 2019-01-01 11:54:39 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:54:39 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:54:39 --> Utf8 Class Initialized
INFO - 2019-01-01 11:54:39 --> URI Class Initialized
DEBUG - 2019-01-01 11:54:40 --> No URI present. Default controller set.
INFO - 2019-01-01 11:54:40 --> Router Class Initialized
INFO - 2019-01-01 11:54:40 --> Output Class Initialized
INFO - 2019-01-01 11:54:40 --> Security Class Initialized
DEBUG - 2019-01-01 11:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:54:40 --> CSRF cookie sent
INFO - 2019-01-01 11:54:40 --> Input Class Initialized
INFO - 2019-01-01 11:54:40 --> Language Class Initialized
INFO - 2019-01-01 11:54:40 --> Loader Class Initialized
DEBUG - 2019-01-01 11:54:40 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:54:40 --> Helper loaded: url_helper
INFO - 2019-01-01 11:54:40 --> Helper loaded: file_helper
INFO - 2019-01-01 11:54:40 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:54:40 --> Helper loaded: util_helper
INFO - 2019-01-01 11:54:40 --> Database Driver Class Initialized
INFO - 2019-01-01 11:54:40 --> Email Class Initialized
DEBUG - 2019-01-01 11:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:54:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:54:40 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:54:40 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:54:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:54:40 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:54:40 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:54:40 --> Helper loaded: date_helper
INFO - 2019-01-01 11:54:40 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:54:40 --> Controller Class Initialized
INFO - 2019-01-01 11:54:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:54:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:54:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:54:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:54:40 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:54:40 --> Final output sent to browser
DEBUG - 2019-01-01 11:54:40 --> Total execution time: 0.6203
INFO - 2019-01-01 11:59:11 --> Config Class Initialized
INFO - 2019-01-01 11:59:11 --> Hooks Class Initialized
DEBUG - 2019-01-01 11:59:11 --> UTF-8 Support Enabled
INFO - 2019-01-01 11:59:11 --> Utf8 Class Initialized
INFO - 2019-01-01 11:59:11 --> URI Class Initialized
DEBUG - 2019-01-01 11:59:11 --> No URI present. Default controller set.
INFO - 2019-01-01 11:59:11 --> Router Class Initialized
INFO - 2019-01-01 11:59:11 --> Output Class Initialized
INFO - 2019-01-01 11:59:11 --> Security Class Initialized
DEBUG - 2019-01-01 11:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 11:59:12 --> CSRF cookie sent
INFO - 2019-01-01 11:59:12 --> Input Class Initialized
INFO - 2019-01-01 11:59:12 --> Language Class Initialized
INFO - 2019-01-01 11:59:12 --> Loader Class Initialized
DEBUG - 2019-01-01 11:59:12 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 11:59:12 --> Helper loaded: url_helper
INFO - 2019-01-01 11:59:12 --> Helper loaded: file_helper
INFO - 2019-01-01 11:59:12 --> Helper loaded: auth_helper
INFO - 2019-01-01 11:59:12 --> Helper loaded: util_helper
INFO - 2019-01-01 11:59:12 --> Database Driver Class Initialized
INFO - 2019-01-01 11:59:12 --> Email Class Initialized
DEBUG - 2019-01-01 11:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 11:59:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 11:59:12 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 11:59:12 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:59:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 11:59:12 --> Helper loaded: cookie_helper
INFO - 2019-01-01 11:59:12 --> Helper loaded: language_helper
DEBUG - 2019-01-01 11:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 11:59:12 --> Helper loaded: date_helper
INFO - 2019-01-01 11:59:12 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 11:59:12 --> Controller Class Initialized
INFO - 2019-01-01 11:59:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 11:59:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 11:59:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 11:59:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 11:59:12 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 11:59:12 --> Final output sent to browser
DEBUG - 2019-01-01 11:59:12 --> Total execution time: 0.6112
INFO - 2019-01-01 12:06:04 --> Config Class Initialized
INFO - 2019-01-01 12:06:04 --> Hooks Class Initialized
DEBUG - 2019-01-01 12:06:04 --> UTF-8 Support Enabled
INFO - 2019-01-01 12:06:04 --> Utf8 Class Initialized
INFO - 2019-01-01 12:06:04 --> URI Class Initialized
DEBUG - 2019-01-01 12:06:04 --> No URI present. Default controller set.
INFO - 2019-01-01 12:06:04 --> Router Class Initialized
INFO - 2019-01-01 12:06:04 --> Output Class Initialized
INFO - 2019-01-01 12:06:04 --> Security Class Initialized
DEBUG - 2019-01-01 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 12:06:04 --> CSRF cookie sent
INFO - 2019-01-01 12:06:04 --> Input Class Initialized
INFO - 2019-01-01 12:06:04 --> Language Class Initialized
INFO - 2019-01-01 12:06:04 --> Loader Class Initialized
DEBUG - 2019-01-01 12:06:04 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 12:06:04 --> Helper loaded: url_helper
INFO - 2019-01-01 12:06:04 --> Helper loaded: file_helper
INFO - 2019-01-01 12:06:04 --> Helper loaded: auth_helper
INFO - 2019-01-01 12:06:04 --> Helper loaded: util_helper
INFO - 2019-01-01 12:06:04 --> Database Driver Class Initialized
ERROR - 2019-01-01 12:06:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'appseed_codedapp'@'localhost' (using password: YES) C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-01 12:06:04 --> Unable to connect to the database
INFO - 2019-01-01 12:06:04 --> Language file loaded: language/english/db_lang.php
INFO - 2019-01-01 12:06:58 --> Config Class Initialized
INFO - 2019-01-01 12:06:58 --> Hooks Class Initialized
DEBUG - 2019-01-01 12:06:58 --> UTF-8 Support Enabled
INFO - 2019-01-01 12:06:58 --> Utf8 Class Initialized
INFO - 2019-01-01 12:06:58 --> URI Class Initialized
DEBUG - 2019-01-01 12:06:58 --> No URI present. Default controller set.
INFO - 2019-01-01 12:06:58 --> Router Class Initialized
INFO - 2019-01-01 12:06:58 --> Output Class Initialized
INFO - 2019-01-01 12:06:58 --> Security Class Initialized
DEBUG - 2019-01-01 12:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 12:06:58 --> CSRF cookie sent
INFO - 2019-01-01 12:06:58 --> Input Class Initialized
INFO - 2019-01-01 12:06:58 --> Language Class Initialized
INFO - 2019-01-01 12:06:58 --> Loader Class Initialized
DEBUG - 2019-01-01 12:06:58 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 12:06:58 --> Helper loaded: url_helper
INFO - 2019-01-01 12:06:58 --> Helper loaded: file_helper
INFO - 2019-01-01 12:06:58 --> Helper loaded: auth_helper
INFO - 2019-01-01 12:06:58 --> Helper loaded: util_helper
INFO - 2019-01-01 12:06:58 --> Database Driver Class Initialized
ERROR - 2019-01-01 12:06:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'appseed_codedapp'@'localhost' (using password: YES) C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-01 12:06:58 --> Unable to connect to the database
INFO - 2019-01-01 12:06:58 --> Language file loaded: language/english/db_lang.php
INFO - 2019-01-01 12:12:04 --> Config Class Initialized
INFO - 2019-01-01 12:12:04 --> Hooks Class Initialized
DEBUG - 2019-01-01 12:12:04 --> UTF-8 Support Enabled
INFO - 2019-01-01 12:12:04 --> Utf8 Class Initialized
INFO - 2019-01-01 12:12:04 --> URI Class Initialized
DEBUG - 2019-01-01 12:12:04 --> No URI present. Default controller set.
INFO - 2019-01-01 12:12:04 --> Router Class Initialized
INFO - 2019-01-01 12:12:04 --> Output Class Initialized
INFO - 2019-01-01 12:12:04 --> Security Class Initialized
DEBUG - 2019-01-01 12:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-01 12:12:05 --> CSRF cookie sent
INFO - 2019-01-01 12:12:05 --> Input Class Initialized
INFO - 2019-01-01 12:12:05 --> Language Class Initialized
INFO - 2019-01-01 12:12:05 --> Loader Class Initialized
DEBUG - 2019-01-01 12:12:05 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/assets.php
INFO - 2019-01-01 12:12:05 --> Helper loaded: url_helper
INFO - 2019-01-01 12:12:05 --> Helper loaded: file_helper
INFO - 2019-01-01 12:12:05 --> Helper loaded: auth_helper
INFO - 2019-01-01 12:12:05 --> Helper loaded: util_helper
INFO - 2019-01-01 12:12:05 --> Database Driver Class Initialized
INFO - 2019-01-01 12:12:05 --> Email Class Initialized
DEBUG - 2019-01-01 12:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-01 12:12:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-01 12:12:05 --> Config file loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\config/ion_auth.php
DEBUG - 2019-01-01 12:12:05 --> Email class already loaded. Second attempt ignored.
INFO - 2019-01-01 12:12:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-01-01 12:12:05 --> Helper loaded: cookie_helper
INFO - 2019-01-01 12:12:05 --> Helper loaded: language_helper
DEBUG - 2019-01-01 12:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2019-01-01 12:12:05 --> Helper loaded: date_helper
INFO - 2019-01-01 12:12:05 --> Model "Ion_auth_model" initialized
INFO - 2019-01-01 12:12:05 --> Controller Class Initialized
INFO - 2019-01-01 12:12:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/index.php
INFO - 2019-01-01 12:12:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/header.php
INFO - 2019-01-01 12:12:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/navigation.php
INFO - 2019-01-01 12:12:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/footer.php
INFO - 2019-01-01 12:12:05 --> File loaded: C:\wamp64\www\github-repos\appseed\coded-apps\php-ci-jq\application\views\themes/argon-design-system/skeleton.php
INFO - 2019-01-01 12:12:05 --> Final output sent to browser
DEBUG - 2019-01-01 12:12:05 --> Total execution time: 0.6448
